<?php 
$this->load->view('template/head');
$this->load->view('template/topbar_second');
$this->load->view('template/sidebar_second');
?>


<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Laporan Surat Keluar
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Laporan</a></li>
        <li class="active">Surat Keluar</li>
      </ol>
    </section>
    
    <br>

    <!-- Main content -->
    <section class="content">
        <form class="form-horizontal" action="<?php echo site_url('c_report/rptoutgoingletter/print_detail');?>" method="post">
      <div class="row">
        <div class="col-xs-6">
            <span style="font-size: 12pt; font-weight: bold">DARI</span>
            <br><br>
          <div class="box box-success">
            
            <div class="modal-body form">
                
                    <div class="form-body">
                        <div class="form-group">
                            <label class="control-label col-md-3">Tanggal</label>
                            <div class="col-md-7">
                                <input name="datefrom" id='datefrom' placeholder="Tanggal" class="form-control" type="date" required>
                                <span class="help-block"></span>
                            </div>
                        </div>
                        <div class="form-group">
                                <label class="control-label col-md-3">Jenis Surat</label>
                                <div class="col-md-7">
                                  <select class="form-control select2" style="width: 100%;" name='typeofletteridfrom' id="typeofletteridfrom">
                                    <option value='0'>Pilih Jenis Surat</option>
                                    <?php
                                         if (!empty($record)) {
                                         foreach ($record as $r) {
                                    echo "<option value=".$r->id.">".$r->typeofletter."</option>";
                                        }
                                     }
                                    ?>
                                  </select>
                                </div>
                        </div>

                        <div class="form-group">
                                <label class="control-label col-md-3">Klasifikasi Surat</label>
                                <div class="col-md-7">
                                  <select class="form-control select2" style="width: 100%;" name='classificationofletteridfrom' id="classificationofletteridfrom">
                                    <option value='0'>Pilih Klasifikasi Surat</option>
                                    <?php
                                         if (!empty($record2)) {
                                         foreach ($record2 as $r) {
                                    echo "<option value=".$r->id.">".$r->classificationofletter."</option>";
                                        }
                                     }
                                    ?>
                                  </select>
                                </div>
                        </div>
                        
                        <div class="form-group">
                            <label class="control-label col-md-3">Jenis Laporan</label>
                            <div class="col-md-7">
                                <select class="form-control" name="reporttype" id='reporttype' style="width: 100%">
                                    <option value="1">Detail</option>
                                    <option value="2">Group by Jenis Surat</option>
                                    <option value="3">Group by Klasifikasi Surat</option>
                                </select>
                            </div>
                        </div>
                    </div>
               
            </div>

            </div>
            <!-- /.box-body -->
        </div>
        <!-- /.col -->

            <div class="col-xs-6">
                <span style="font-size: 12pt; font-weight: bold">SAMPAI</span>
            <br><br>
          <div class="box box-success">
            
            <div class="modal-body form">
                    <div class="form-body">
                        <div class="form-group">
                            <label class="control-label col-md-3">Tanggal</label>
                            <div class="col-md-7">
                                <input name="dateto" id='dateto' placeholder="Tanggal" class="form-control" type="date" required>
                                <span class="help-block"></span>
                            </div>
                        </div>
                        <div class="form-group">
                                <label class="control-label col-md-3">Jenis Surat</label>
                                <div class="col-md-7">
                                  <select class="form-control select2" style="width: 100%;" name='typeofletteridto' id="typeofletteridto">
                                    <option value='0'>Pilih Jenis Surat</option>
                                    <?php
                                         if (!empty($record)) {
                                         foreach ($record as $r) {
                                    echo "<option value=".$r->id.">".$r->typeofletter."</option>";
                                        }
                                     }
                                    ?>
                                  </select>
                                </div>
                        </div>

                        <div class="form-group">
                                <label class="control-label col-md-3">Klasifikasi Surat</label>
                                <div class="col-md-7">
                                  <select class="form-control select2" style="width: 100%;" name='classificationofletteridto' id="classificationofletteridto">
                                    <option value='0'>Pilih Klasifikasi Surat</option>
                                    <?php
                                         if (!empty($record2)) {
                                         foreach ($record2 as $r) {
                                    echo "<option value=".$r->id.">".$r->classificationofletter."</option>";
                                        }
                                     }
                                    ?>
                                  </select>
                                </div>
                        </div>
                        
                        <div class="form-group" style="margin-bottom: 20px;">
                            <label class="control-label col-md-3">&nbsp</label>
                            <div class="col-md-6">
                                &nbsp
                            </div>
                        </div>
                    </div>
                
            </div>

            </div>
            <!-- /.box-body -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
      
      <div class="panel-footer">
        <button id="submit" class="btn btn-info" formtarget="_blank">Cetak</button>
        <a href="<?php echo site_url('dashboard'); ?>" class="btn btn-danger">Batal</a>
      </div>
      
      </form>

    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

<?php 
$this->load->view('template/foot');
?> 

<!-- jQuery 2.2.3 -->
<script src="<?php echo base_url('assets/plugins/jQuery/jquery-2.2.3.min.js') ?>"></script>
<!-- Bootstrap 3.3.6 -->
<script src="<?php echo base_url('assets/bootstrap/js/bootstrap.min.js') ?>"></script>
<!-- DataTables -->
<script src="<?php echo base_url('assets/plugins/datatables/jquery.dataTables.min.js') ?>"></script>
<script src="<?php echo base_url('assets/plugins/datatables/dataTables.bootstrap.min.js') ?>"></script>
<!-- Select2 -->
<script src="<?php echo base_url('assets/plugins/select2/select2.full.min.js') ?>"></script>
<!-- SlimScroll -->
<script src="<?php echo base_url('assets/plugins/slimScroll/jquery.slimscroll.min.js') ?>"></script>
<!-- FastClick -->
<script src="<?php echo base_url('assets/plugins/fastclick/fastclick.js') ?>"></script>
<!-- AdminLTE App -->
<script src="<?php echo base_url('assets/dist/js/app.min.js') ?>"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?php echo base_url('assets/dist/js/demo.js') ?>"></script>

<script>
    $(function () {
        //Initialize Select2 Elements
        $(".select2").select2();

    });

</script>

</body>
</html>