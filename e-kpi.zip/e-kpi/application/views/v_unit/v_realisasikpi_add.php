<?php 
$this->load->view('template/head');
$this->load->view('template/topbar_third');
$this->load->view('template/sidebar_head');
?>


<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Realisasi KPI
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Input KPI</a></li>
        <li class="active">Data Realisasi KPI</li>
      </ol>
    </section>
    
    <br>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box box-success">
            
            <div class="modal-body form">
                <form class="form-horizontal" action="<?php echo site_url('c_unit/realisasikpi/save');?>" method="post" enctype="multipart/form-data">
                    <div class="form-body">
                        
                        <div class="form-group">
                            <label class="control-label col-md-3">ID Realisasi</label>
                            <div class="col-md-5">
                                <input name="id_realisasi" id='id_realisasi' class="form-control" type="text" value="<?php echo $kodejadi;?>" disabled>
                                <span class="help-block"></span>
                            </div>
                        </div>
                        <div class="form-group">
                                <label class="control-label col-md-3">Karyawan</label>
                                <div class="col-md-5">
                                  <select class="form-control select2" style="width: 100%;" name='id_karyawan' id="id_karyawan">
                                    <option value='0'>Pilih Karyawan</option>
                                    <?php
                                         if (!empty($karyawan)) {
                                         foreach ($karyawan as $r) {
                                    echo "<option value=".$r->id_karyawan.">".$r->nama_karyawan."</option>";
                                        }
                                     }
                                    ?>
                                  </select>
                                </div>
                        </div>
                        <div class="form-group">
                                <label class="control-label col-md-3">Kategori</label>
                                <div class="col-md-5">
                                  <select class="form-control select2" style="width: 100%;" name='id_kategori' id="id_kategori">
                                    <option value='0'>Pilih Kategori</option>
                                    <?php
                                         if (!empty($kategori)) {
                                         foreach ($kategori as $r) {
                                    echo "<option value=".$r->id_kategori.">".$r->nama_kategori."</option>";
                                        }
                                     }
                                    ?>
                                  </select>
                                </div>
                        </div>
                        <div class="form-group">
                                <label class="control-label col-md-3">Bulan</label>
                                <div class="col-md-5">
                                  <select class="form-control select2" style="width: 100%;" name='id_bulan' id="id_bulan">
                                    <option value='0'>Pilih Bulan</option>
                                    <?php
                                         if (!empty($bulan)) {
                                         foreach ($bulan as $r) {
                                    echo "<option value=".$r->id_bulan.">".$r->nama_bulan."</option>";
                                        }
                                     }
                                    ?>
                                  </select>
                                </div>
                        </div>
                        <div class="form-group">
                                <label class="control-label col-md-3">Tahun</label>
                                <div class="col-md-5">
                                  <select class="form-control select2" style="width: 100%;" name='id_tahun' id="id_tahun">
                                    <option value='0'>Pilih Tahun</option>
                                    <?php
                                         if (!empty($tahun)) {
                                         foreach ($tahun as $r) {
                                    echo "<option value=".$r->id_tahun.">".$r->nama_tahun."</option>";
                                        }
                                     }
                                    ?>
                                  </select>
                                </div>
                        </div>
                        <div class="form-group">
                                <label class="control-label col-md-3">Supervisor</label>
                                <div class="col-md-5">
                                  <select class="form-control select2" style="width: 100%;" name='id_supervisor' id="id_supervisor">
                                    <option value='0'>Pilih Supervisor</option>
                                    <?php
                                         if (!empty($karyawan)) {
                                         foreach ($karyawan as $r) {
                                    echo "<option value=".$r->id_karyawan.">".$r->nama_karyawan."</option>";
                                        }
                                     }
                                    ?>
                                  </select>
                                </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-md-3">Skor Akhir</label>
                            <div class="col-md-5">
                                <input name="skor_akhir" id='skor_akhir' placeholder="Skor Akhir" class="form-control" type="text" required>
                                <span class="help-block"></span>
                            </div>
                        </div>
                       
                        <br>

                        <table id="table" class="table table-striped table-bordered" cellspacing="0" width="100%">
                            <thead>
                              <tr>
                                <th><center>KPI</center></th>
                                <th style="width:150px;"><center>Action</center></th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <th><input type="text" id="kpi_name" name="kpi_name" style="width: 100%; text-align: center;"></th>
                                <th style="width:150px;"><center><button id="addkpi" class="btn btn-sm btn-success"><i class="glyphicon glyphicon-plus"></i></button></center></th>
                            </tr>
                        </tbody>
                        </table>
                        <div id="viewKpi"></div>
                       
                    </div>
                
            

            <div class="panel-footer">
                <button class="btn btn-info">Simpan</button>
                <a href="<?php echo site_url('c_unit/realisasikpi'); ?>" class="btn btn-danger">Batal</a>
            </div>

            </form>

            </div>

            </div>
            <!-- /.box-body -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

<?php 
$this->load->view('template/foot');
?> 

<!-- jQuery 2.2.3 -->
<script src="<?php echo base_url('assets/plugins/jQuery/jquery-2.2.3.min.js') ?>"></script>
<!-- Bootstrap 3.3.6 -->
<script src="<?php echo base_url('assets/bootstrap/js/bootstrap.min.js') ?>"></script>
<!-- Select2 -->
<script src="<?php echo base_url('assets/plugins/select2/select2.full.min.js') ?>"></script>
<!-- DataTables -->
<script src="<?php echo base_url('assets/plugins/datatables/jquery.dataTables.min.js') ?>"></script>
<script src="<?php echo base_url('assets/plugins/datatables/dataTables.bootstrap.min.js') ?>"></script>
<!-- SlimScroll -->
<script src="<?php echo base_url('assets/plugins/slimScroll/jquery.slimscroll.min.js') ?>"></script>
<!-- FastClick -->
<script src="<?php echo base_url('assets/plugins/fastclick/fastclick.js') ?>"></script>
<!-- AdminLTE App -->
<script src="<?php echo base_url('assets/dist/js/app.min.js') ?>"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?php echo base_url('assets/dist/js/demo.js') ?>"></script>

<script type="text/javascript" src="<?=base_url();?>/assets/autocomplete/js/jquery-ui.js"></script>
<link rel="stylesheet" href="<?=base_url();?>/assets/autocomplete/css/jquery-autocomplete.css">

<script>
    $(function () {
        //Initialize Select2 Elements
        $(".select2").select2();

    });
</script>
<script>
 $(function(){
    $("#kpi_name").autocomplete({
  source: "<?php echo site_url('c_unit/realisasikpi/getKpi');?>" // path to the get_birds method
});
});

function loadDataTemp(args) {
  //code
  $("#viewKpi").load("<?php echo site_url('c_unit/realisasikpi/viewKpi');?>");
  $('#addkpi').attr('disabled',false); //set button enable
} 

function nullEmployeename(args) {
  //code
  $("#kpi_name").val('');
}

$("#addkpi").click(function(){
  var kpi_name=$("#kpi_name").val();

if (kpi_name=="") {
  //code
  alert("Nama KPI Harus Diisi");
  return false;
}else{
  $('#addkpi').attr('disabled',true); //set button disable 
  $.ajax({
    url:"<?php echo site_url('c_unit/realisasikpi/addKpi');?>",
    type:"POST",
    data:"kpi_name="+kpi_name,
    cache:false,
    success:function(html){
      loadDataTemp();
      nullEmployeename();
      $('#kpi_name').focus();
    },
    error:function (jqXHR, textStatus, errorThrown)
    {
    $('#addkpi').attr('disabled',false); //set button disable 
    }
  })    
}
})

$("#save").click(function(){
        var idincomingletter=$("#idincomingletter").val();

            $('#save').attr('disabled',true); //set button disable
            $.ajax({
                url:"<?php echo site_url('c_transaction/disposisi/save');?>",
                type:"POST",
                data:"idincomingletter="+idincomingletter,
                cache:false,
                success:function(html){
                    alert("Disposisi Berhasil disimpan");
                        //location.reload();
                        window.location = "<?php echo site_url('c_transaction/disposisi');?>";
                    }
                })

    })
</script>

</body>
</html>