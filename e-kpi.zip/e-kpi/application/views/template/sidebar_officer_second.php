<!-- Left side column. contains the logo and sidebar -->
  <aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
      <!-- sidebar menu: : style can be found in sidebar.less -->
      <ul class="sidebar-menu">
      <li class="treeview" >
          <ul class="treeview-menu" style="display: contents;">
           <li>
           <center><img src="<?php echo base_url('upload/'. $this->session->userdata("attachement"));?>" class="img-circle" alt="User Image" style="width: 150px; height: 150px; align-items: center;"/></center>
        <p><center>
          <?php echo $this->session->userdata("name"); ?> <br>
          <small><?php echo $this->session->userdata("jobdescription"); ?></small>
          </center>
        </p>
          </li>
            
          </ul>
        </li>
        
        <li class="treeview">
          <a href="<?php echo site_url('c_officer/berandaofficer'); ?>">
            <i class="fa fa-home"></i> <span>Beranda</span>
          </a>
        </li> 
        <li class="treeview">
          <a href="<?php echo site_url('c_officer/dashboardofficer'); ?>">
            <i class="fa fa-dashboard"></i> <span>Dashboard</span>
          </a>
        </li>
        <li class="treeview">
          <a href="#">
            <i class="fa fa-pie-chart"></i>
            <span>Input KPI</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?php echo site_url('c_officer/realisasikpi'); ?>"><i class="fa fa-circle-o text-yellow"></i> Realisasi KPI</a></li>
          </ul>
        </li>
    

        
       

       
      </ul>
    </section>
    <!-- /.sidebar -->
  </aside>