<!-- Left side column. contains the logo and sidebar -->
  <aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
      <!-- sidebar menu: : style can be found in sidebar.less -->
      <ul class="sidebar-menu">
        <li class="treeview" >
          <ul class="treeview-menu" style="display: contents;">
           <li>
            <center><img src="<?php echo base_url('upload/'. $this->session->userdata("attachement"));?>" class="img-circle" alt="User Image" style="width: 150px; height: 150px; align-items: center;"/></center>
            <p><center>
              <?php echo $this->session->userdata("name"); ?> <br>
              <small><?php echo $this->session->userdata("jobdescription"); ?></small>
              </center>
            </p>
          </li>
            
          </ul>
        </li>
        <li class="treeview">
          <a href="../dashboard">
            <i class="fa fa-dashboard"></i> 
            <span style="width: 250px;">Dashboard</span>
          </a>
        </li>

        <li class="treeview">
          <a href="#">
            <i class="fa fa-laptop"></i>
            <span style="width: 250px;">Master Data</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu" style="width: 250px;">
            <li><a href="../c_master/unit"><i class="fa fa-circle-o text-red"></i> Master Unit</a></li>
            <li><a href="../c_master/departemen"><i class="fa fa-circle-o text-red"></i> Master Department</a></li>
            <li><a href="../c_master/section"><i class="fa fa-circle-o text-red"></i> Master Section</a></li>
            <li><a href="../c_master/jabatan"><i class="fa fa-circle-o text-red"></i> Master Jabatan</a></li>
            <li><a href="../c_master/level"><i class="fa fa-circle-o text-red"></i> Master Level</a></li>
            <li><a href="../c_master/karyawan"><i class="fa fa-circle-o text-red"></i> Master Karyawan</a></li>
            <li><a href="../c_master/user"><i class="fa fa-circle-o text-red"></i> Master User</a></li>
            <li><a href="../c_master/pic"><i class="fa fa-circle-o text-red"></i> Master PIC</a></li>
            <li><a href="../c_master/penilaiankinerja"><i class="fa fa-circle-o text-red"></i> Master Penilaian Kinerja</a></li>
            <li><a href="../c_master/kpi"><i class="fa fa-circle-o text-red"></i> Master KPI</a></li>
            <li><a href="../c_master/kpikaryawan"><i class="fa fa-circle-o text-red"></i> Master KPI Karyawan</a></li>
            <li><a href="../c_master/tahun"><i class="fa fa-circle-o text-red"></i> Master Tahun</a></li>
            <li><a href="../c_master/bulan"><i class="fa fa-circle-o text-red"></i> Master Bulan</a></li>
            <li><a href="../c_master/kategori"><i class="fa fa-circle-o text-red"></i> Master Kategori</a></li>
            <li><a href="../c_master/parameter"><i class="fa fa-circle-o text-red"></i> Master Parameter</a></li>
            <li><a href="../c_master/subparameter"><i class="fa fa-circle-o text-red"></i> Master Sub Parameter</a></li>
          
          </ul>
        </li>

        <li class="treeview">
          <a href="#">
            <i class="fa fa-pie-chart"></i>
            <span style="width: 250px;">Input KPI</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu" style="width: 250px;">
            <!-- <li><a href="../c_transaction/incomingletter"><i class="fa fa-circle-o text-yellow"></i> Surat Masuk</a></li>
            <li><a href="../c_transaction/outgoingletter"><i class="fa fa-circle-o text-yellow"></i> Surat Keluar</a></li>
            <li><a href="../c_transaction/disposisi"><i class="fa fa-circle-o text-yellow"></i> Disposisi</a></li> -->
            <li><a href="../c_transaction/penilaiankinerja"><i class="fa fa-circle-o text-yellow"></i> Transaksi Penilaian Kinerja</a></li>
            <li><a href="../c_transaction/targetkpi"><i class="fa fa-circle-o text-yellow"></i> Target KPI</a></li>
            <li><a href="../c_transaction/bobotkpi"><i class="fa fa-circle-o text-yellow"></i> Bobot KPI</a></li>
            <li><a href="../c_transaction/realisasikpi"><i class="fa fa-circle-o text-yellow"></i> Realisasi KPI</a></li>
          </ul>
        </li>
        <li class="treeview">
          <a href="#">
            <i class="fa fa-book"></i> 
            <span style="width: 250px;">Laporan</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu" style="width: 250px;">
            <!-- <li><a href="../c_report/rptincomingletter"><i class="fa fa-circle-o text-aqua"></i> Rekap Surat Masuk</a></li>
            <li><a href="../c_report/rptoutgoingletter"><i class="fa fa-circle-o text-aqua"></i> Rekap Surat Keluar</a></li> -->
            <li><a href="../c_report/cetaklaporan"><i class="fa fa-circle-o text-aqua"></i> Cetak Laporan</a></li>
            <li><a href="../c_report/kinerjakeseluruhan"><i class="fa fa-circle-o text-aqua"></i> Laporan Kinerja Keseluruhan</a></li>
            <li><a href="../c_report/kinerjatiapkaryawan"><i class="fa fa-circle-o text-aqua"></i> Laporan Kinerja Tiap Karyawan</a></li>
            <li><a href="../c_report/kinerjaperbulan"><i class="fa fa-circle-o text-aqua"></i> Laporan Kinerja per Bulan</a></li>
          </ul>
        </li>
      </ul>
    </section>
    <!-- /.sidebar -->
  </aside>