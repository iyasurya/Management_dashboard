<!-- Left side column. contains the sidebar -->
<aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
        <!-- Sidebar user panel -->
        <div class="user-panel">
            <div class="pull-left image">
                 <img src="../../../../../../../../<?php echo $this->session->userdata("foto"); ?>" class="img-circle" alt="User Image Second" />
            </div>
            <div class="pull-left info">
                <h6><p><?php echo $this->session->userdata("nama"); ?></p></h6>
                <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
            </div>
        </div>
        <!-- search form 
        <form action="#" method="get" class="sidebar-form">
            <div class="input-group">
                <input type="text" name="q" class="form-control" placeholder="Search..."/>
                <span class="input-group-btn">
                    <button type='submit' name='seach' id='search-btn' class="btn btn-flat"><i class="fa fa-search"></i></button>
                </span>
            </div>
        </form>
        --><!-- /.search form -->
        <!-- sidebar menu: : style can be found in sidebar.less -->
        <ul class="sidebar-menu">
        <li class="treeview" >
          <ul class="treeview-menu" style="display: contents;">
           <li>
            <center><img src="<?php echo base_url('upload/'. $this->session->userdata("attachement"));?>" class="img-circle" alt="User Image" style="width: 150px; height: 150px; align-items: center;"/></center>
            <p><center>
              <?php echo $this->session->userdata("name"); ?> <br>
              <small><?php echo $this->session->userdata("jobdescription"); ?></small>
              </center>
            </p>
          </li>
            
          </ul>
        </li>
            <li class="treeview"><a href="<?php echo site_url('dashboard') ?>"><b>Dashboard</b></a></li>
        </ul>
    </section>
    <!-- /.sidebar -->
</aside>

<!-- =============================================== -->

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">