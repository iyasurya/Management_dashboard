<footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b>Version</b> 1.0
    </div>
    <!-- <marquee direction="down" scrollamount="1"><strong>Copyright &copy; 2023 <a href="https://citanusa.com/">Citanusa Group</a>.</strong> All rights
    reserved.</marquee> -->
    <strong>Copyright &copy; 2023 <a href="https://citanusa.com/">Citanusa Group</a>.</strong> All rights
    reserved.
  </footer>
</div>
<!-- ./wrapper -->