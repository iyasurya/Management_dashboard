<?php 
$this->load->view('template/head');
$this->load->view('template/topbar_third');
$this->load->view('template/sidebar_third');
?>


<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
       Tambah User
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#"> Master</a></li>
        <li class="active">Data Tambah User</li>
      </ol>
    </section>
    
    <br>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box box-success">
            
            <div class="modal-body form">
                <form class="form-horizontal" action="<?php echo site_url('c_master/user/save');?>" method="post" enctype="multipart/form-data">
                    <div class="form-body">
                    <div class="form-group">
                            <label class="control-label col-md-3">ID User</label>
                            <div class="col-md-5">
                                <input name="id_user" id='id_user' placeholder="ID User" class="form-control" type="text" required>
                                <span class="help-block"></span>
                            </div>
                        </div>
                        <div class="form-group">
                                <label class="control-label col-md-3">ID Karyawan</label>
                                <div class="col-md-5">
                                  <select class="form-control select2" style="width: 100%;" name='id_karyawan' id="id_karyawan">
                                    <option value='0'>Pilih Karyawan</option>
                                    <?php
                                         if (!empty($pic)) {
                                         foreach ($pic as $r) {
                                    echo "<option value=".$r->id_karyawan.">".$r->nama_karyawan."</option>";
                                        }
                                     }
                                    ?>
                                  </select>
                                </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-md-3">Nama</label>
                            <div class="col-md-5">
                                <input name="name" id='name' placeholder="Nama" class="form-control" type="text" required>
                                <span class="help-block"></span>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-md-3">Username</label>
                            <div class="col-md-5">
                                <input name="username" id='username' placeholder="Username" class="form-control" type="text" required>
                                <span class="help-block"></span>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-md-3">Password</label>
                            <div class="col-md-5">
                                <input name="password" id='password' placeholder="Password" class="form-control" type="text" required>
                                <span class="help-block"></span>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-md-3">Deskripsi Pekerjaan</label>
                            <div class="col-md-5">
                                <textarea name="jobdescription" id='jobdescription' placeholder="Deskripsi Pekerjaan" class="form-control" type="text" required></textarea>
                                <span class="help-block"></span>
                            </div>
                        </div>
                       /
                        <div class="form-group">
                            <label class="control-label col-md-3">Level</label>
                            <div class="col-md-5">
                                <select class="form-control" name="menu" id='menu' style="width: 240px">
                                    <option value="superadmin">Super Admin</option>
                                    <option value="admin">Admin</option>
                                    <option value="bod">BOD</option>
                                    <option value="unithead">Unit Head</option>
                                    <option value="depthead">Dept. Head</option>
                                    <option value="sectionhead">Section Head</option>
                                    <option value="officer">Officer</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-md-3">Key</label>
                            <div class="col-md-5">
                                <input name="key_id" id='key_id' placeholder="Key" class="form-control" type="text" required>
                                <span class="help-block"></span>
                            </div>
                        </div>
                      

                        <div class="form-group">
                                <label class="control-label col-md-3">Foto</label>
                                <div class="col-md-5">
                                    <input type="file" name="attachement" id="attachement"/>
                                </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-md-3">Status</label>
                            <div class="col-md-5">
                                <select class="form-control" name="enableflag" id='enableflag' style="width: 240px">
                                    <option value="0">Aktif</option>
                                    <option value="1">Tidak Aktif</option>
                                </select>
                            </div>
                        </div>
                    </div>
                
            

            <div class="panel-footer">
                <button class="btn btn-info">Simpan</button>
                <a href="<?php echo site_url('c_master/user'); ?>" class="btn btn-danger">Batal</a>
            </div>

            </form>

            </div>

            </div>
            <!-- /.box-body -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

<?php 
$this->load->view('template/foot');
?> 

<!-- jQuery 2.2.3 -->
<script src="<?php echo base_url('assets/plugins/jQuery/jquery-2.2.3.min.js') ?>"></script>
<!-- Bootstrap 3.3.6 -->
<script src="<?php echo base_url('assets/bootstrap/js/bootstrap.min.js') ?>"></script>
<!-- Select2 -->
<script src="<?php echo base_url('assets/plugins/select2/select2.full.min.js') ?>"></script>
<!-- DataTables -->
<script src="<?php echo base_url('assets/plugins/datatables/jquery.dataTables.min.js') ?>"></script>
<script src="<?php echo base_url('assets/plugins/datatables/dataTables.bootstrap.min.js') ?>"></script>
<!-- SlimScroll -->
<script src="<?php echo base_url('assets/plugins/slimScroll/jquery.slimscroll.min.js') ?>"></script>
<!-- FastClick -->
<script src="<?php echo base_url('assets/plugins/fastclick/fastclick.js') ?>"></script>
<!-- AdminLTE App -->
<script src="<?php echo base_url('assets/dist/js/app.min.js') ?>"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?php echo base_url('assets/dist/js/demo.js') ?>"></script>

<script>
    $(function () {
        //Initialize Select2 Elements
        $(".select2").select2();

    });
</script>

</body>
</html>