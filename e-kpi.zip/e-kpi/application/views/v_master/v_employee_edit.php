<?php 
$this->load->view('template/head');
$this->load->view('template/topbar_fourth');
$this->load->view('template/sidebar_fourth');
?>


<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Pegawai
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Master</a></li>
        <li class="active">Data Pegawai</li>
      </ol>
    </section>
    
    <br>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box box-success">
            
            <div class="modal-body form">
                <form class="form-horizontal" action="<?php echo site_url('employee/update');?>" method="post">
                    <div class="form-body">
                        <input type="hidden"  name="id" id="id" value="<?php echo $record['id'] ?>">
                        <div class="form-group">
                            <label class="control-label col-md-3">NIP</label>
                            <div class="col-md-5">
                                <input name="idemployee" id='idemployee' placeholder="NIP Pegawai" class="form-control" type="text" required value="<?php echo  $record['idemployee']?>">
                                <span class="help-block"></span>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-md-3">Nama Pegawai</label>
                            <div class="col-md-5">
                                <input name="employeename" id='employeename' placeholder="Nama Pegawai" class="form-control" type="text" required value="<?php echo  $record['employeename']?>">
                                <span class="help-block"></span>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-md-3">Email</label>
                            <div class="col-md-5">
                                <input name="email" id='email' placeholder="Email Pegawai" class="form-control" type="text" required value="<?php echo  $record['email']?>">
                                <span class="help-block"></span>
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label class="control-label col-md-3">Status</label>
                            <div class="col-md-5">
                                <select class="form-control" name="enableflag" id='enableflag' style="width: 240px">
                                    <option value="0" <?php if($record['enableflag']=="0") echo 'selected="selected"'; ?> >Aktif</option>
                                    <option value="1" <?php if($record['enableflag']=="1") echo 'selected="selected"'; ?> >Tidak Aktif</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </form>
            </div>

            <div class="panel-footer">
                <button id="update" class="btn btn-info">Update</button>
                <a href="<?php echo site_url('c_master/employee'); ?>" class="btn btn-danger">Batal</a>
            </div>

            </div>
            <!-- /.box-body -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

<?php 
$this->load->view('template/foot');
?> 

<!-- jQuery 2.2.3 -->
<script src="<?php echo base_url('assets/plugins/jQuery/jquery-2.2.3.min.js') ?>"></script>
<!-- Bootstrap 3.3.6 -->
<script src="<?php echo base_url('assets/bootstrap/js/bootstrap.min.js') ?>"></script>
<!-- DataTables -->
<script src="<?php echo base_url('assets/plugins/datatables/jquery.dataTables.min.js') ?>"></script>
<script src="<?php echo base_url('assets/plugins/datatables/dataTables.bootstrap.min.js') ?>"></script>
<!-- SlimScroll -->
<script src="<?php echo base_url('assets/plugins/slimScroll/jquery.slimscroll.min.js') ?>"></script>
<!-- FastClick -->
<script src="<?php echo base_url('assets/plugins/fastclick/fastclick.js') ?>"></script>
<!-- AdminLTE App -->
<script src="<?php echo base_url('assets/dist/js/app.min.js') ?>"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?php echo base_url('assets/dist/js/demo.js') ?>"></script>

<script>

    $("#update").click(function(){
        var idemployee=$("#idemployee").val();
        var employeename=$("#employeename").val();
        var email=$("#email").val();
        var enableflag=$("#enableflag").val();
        var id=$("#id").val();

        if (idemployee=="") {
            alert("NIP Pegawai Tidak Boleh Kosong");
            return false;
        }else if (employeename=="") {
            alert("Nama Pegawai Tidak Boleh Kosong");
            return false;
        }else if (email=="") {
            alert("Email Pegawai Tidak Boleh Kosong");
            return false;
        }else{
            $('#update').attr('disabled',true); //set button disable
            $.ajax({
                url:"<?php echo site_url('c_master/employee/update');?>",
                type:"POST",
                data:"idemployee="+idemployee+"&employeename="+employeename+"&email="+email+"&enableflag="+enableflag+"&id="+id,
                cache:false,
                success:function(html){
                    alert("Edit Pegawai Berhasil");
                        //location.reload();
                        window.location = "<?php echo site_url('c_master/employee');?>";
                    }
                })
        }

    })

</script>

</body>
</html>