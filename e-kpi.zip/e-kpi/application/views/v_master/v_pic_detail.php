<?php 
$this->load->view('template/head');
$this->load->view('template/topbar_fourth');
$this->load->view('template/sidebar_fourth');
?>


<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Detail PIC
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Master</a></li>
        <li class="active">Data Detail PIC</li>
      </ol>
    </section>
    
    <br>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box box-success">
            
            <div class="modal-body form">
                <form class="form-horizontal" action="<?php echo site_url('pic/update');?>" method="post">
                    <div class="form-body">
                        <input type="hidden"  name="id" id="id" value="<?php echo $record['id'] ?>" disabled>
                        <div class="form-group">
                            <label class="control-label col-md-3">ID PIC</label>
                            <div class="col-md-5">
                                <input name="id_pic" id='id_pic' placeholder="ID KPI" class="form-control" type="text" required value="<?php echo  $record['id_pic']?>" disabled>
                                <span class="help-block"></span>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-md-3">Karyawan</label>
                            <div class="col-md-5">
                                <select class="form-control select2" style="width: 100%;" name='id_karyawan' id="id_karyawan" disabled>
                                    <option value='0'>Pilih Karyawan</option>
                                    <?php
                                         if (!empty($pic)) {
                                            foreach ($pic as $r) {
                                              echo "<option value='$r->id_karyawan'";
                                              echo $record['id_karyawan'] == $r->id_karyawan ? 'selected' : '';
                                              echo">$r->nama_karyawan</option>";
                                            }
                                        }  
                                    ?>
                                  </select>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-md-3">Nama</label>
                            <div class="col-md-5">
                                <input name="nama_pic" id='nama_pic' placeholder="Nama PIC" class="form-control" type="text" required value="<?php echo  $record['nama_pic']?>" disabled>
                                <span class="help-block"></span>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-md-3">Status</label>
                            <div class="col-md-5">
                                <select class="form-control" name="enableflag" id='enableflag' style="width: 240px" disabled>
                                    <option value="0" <?php if($record['enableflag']=="0") echo 'selected="selected"'; ?> >Aktif</option>
                                    <option value="1" <?php if($record['enableflag']=="1") echo 'selected="selected"'; ?> >Tidak Aktif</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
            <div class="panel-footer">
                <!-- <button id="update" class="btn btn-info">Update</button> -->
                <a href="<?php echo site_url('c_master/pic'); ?>" class="btn btn-danger">Kembali</a>
            </div>

            </div>
            <!-- /.box-body -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

<?php 
$this->load->view('template/foot');
?> 

<!-- jQuery 2.2.3 -->
<script src="<?php echo base_url('assets/plugins/jQuery/jquery-2.2.3.min.js') ?>"></script>
<!-- Bootstrap 3.3.6 -->
<script src="<?php echo base_url('assets/bootstrap/js/bootstrap.min.js') ?>"></script>
<!-- DataTables -->
<script src="<?php echo base_url('assets/plugins/datatables/jquery.dataTables.min.js') ?>"></script>
<script src="<?php echo base_url('assets/plugins/datatables/dataTables.bootstrap.min.js') ?>"></script>
<!-- SlimScroll -->
<script src="<?php echo base_url('assets/plugins/slimScroll/jquery.slimscroll.min.js') ?>"></script>
<!-- FastClick -->
<script src="<?php echo base_url('assets/plugins/fastclick/fastclick.js') ?>"></script>
<!-- AdminLTE App -->
<script src="<?php echo base_url('assets/dist/js/app.min.js') ?>"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?php echo base_url('assets/dist/js/demo.js') ?>"></script>

<script>

    $("#update").click(function(){
        var id_pic=$("#id_pic").val();
        var id_karyawan=$("#id_karyawan").val();
        var nama_pic=$("#nama_pic").val();
        var enableflag=$("#enableflag").val();
        var id=$("#id").val();

        if (id_pic=="") {
            alert("ID PIC Tidak Boleh Kosong");
            return false;
        }else if (id_karyawan=="") {
            alert("Karyawan Tidak Boleh Kosong");
            return false;
        }else if (nama_pic=="") {
            alert("Nama Tidak Boleh Kosong");
            return false;
        }else{
            $('#update').attr('disabled',true); //set button disable
            $.ajax({
                url:"<?php echo site_url('c_master/pic/update');?>",
                type:"POST",
                data:"id_pic="+id_pic+"&id_karyawan="+id_karyawan+"&nama_pic="+nama_pic+
                "&enableflag="+enableflag+"&id="+id,
                cache:false,
                success:function(html){
                    alert("Edit PIC Berhasil");
                        //location.reload();
                        window.location = "<?php echo site_url('c_master/pic');?>";
                    }
                })
        }

    })

</script>

</body>
</html>