<?php
$this->load->view('template/head');
$this->load->view('template/topbar_second');
$this->load->view('template/sidebar_second');
?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Chart Prospect of New Customer
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Master</a></li>
        <li class="active">Chart</li>
      </ol>
    </section>

    <br>

    <!-- Main content -->

    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box box-success">
            <br>
            <!-- <div class="box-header">
             
              <br>
            </div> -->
            <!-- /.box-header -->
            <div class="box-body" style="overflow-x: auto;">
            <div id="columnchart_material" style="height: 500px;"></div>
            </div>
            <div class="panel-footer">
                <!-- <button id="update" class="btn btn-info">Update</button> -->
                <a href="<?php echo site_url('dashboard'); ?>" class="btn btn-danger">kembali</a>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  
<?php
$this->load->view('template/foot');
?> 

<!-- jQuery 2.2.3 -->
<script src="<?php echo base_url('assets/plugins/jQuery/jquery-2.2.3.min.js') ?>"></script>
<!-- Bootstrap 3.3.6 -->
<script src="<?php echo base_url('assets/bootstrap/js/bootstrap.min.js') ?>"></script>
<!-- DataTables -->
<script src="<?php echo base_url('assets/plugins/datatables/jquery.dataTables.min.js') ?>"></script>
<script src="<?php echo base_url('assets/plugins/datatables/dataTables.bootstrap.min.js') ?>"></script>
<!-- SlimScroll -->
<script src="<?php echo base_url('assets/plugins/slimScroll/jquery.slimscroll.min.js') ?>"></script>
<!-- FastClick -->
<script src="<?php echo base_url('assets/plugins/fastclick/fastclick.js') ?>"></script>
<!-- AdminLTE App -->
<script src="<?php echo base_url('assets/dist/js/app.min.js') ?>"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?php echo base_url('assets/dist/js/demo.js') ?>"></script>
<!-- page script -->
<script type="text/javascript">
var save_method; //for save method string
var table;
var base_url = '<?php echo base_url();?>';


</script>
<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
<script type="text/javascript">
      google.charts.load('current', {'packages':['corechart']});
      google.charts.setOnLoadCallback(drawVisualization);

      function drawVisualization() {
        // Some raw data (not necessarily accurate)
        var data = google.visualization.arrayToDataTable([
          ['Name','Drop Off', 'Prospect', 'On Progress'],
          ['Canvasing',  165,      938,         522],
          ['Data Marcom',  135,      1120,        599],
          ['FB Pribadi',  157,      1167,        587],
          ['IG Pribadi',  139,      1110,        615],
          ['Olx Pribadi',  136,      691,         629],
          ['Pameran',  136,      691,         629],
          ['Ref Customer',  136,      691,         629],
          ['Database HA',  136,      691,         629]
        ]);

        // var options = {
        //   title : 'Sales Acchievment',
        //   vAxis: {title: 'Millions'},
        //   hAxis: {title: 'Month'},
        //   seriesType: 'bars',
        //   series: {5: {type: 'line'}}
        // };
        var options = {
    title: 'Prospect Of New Customer',
    legend: { position: 'bottom', maxLines: 4 },
    seriesType: 'bars',
   
    colors: ['#C90404', '#FF9900', '#F5E612'],
    interpolateNulls: false,
        };

        var chart = new google.visualization.ComboChart(document.getElementById('columnchart_material'));
        chart.draw(data, options);
      }
    </script>

</body>
</html>