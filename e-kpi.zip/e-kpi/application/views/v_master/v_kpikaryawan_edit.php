<?php 
$this->load->view('template/head');
$this->load->view('template/topbar_fourth');
$this->load->view('template/sidebar_fourth');
?>


<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Kpi
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Master</a></li>
        <li class="active">Data Kpi</li>
      </ol>
    </section>
    
    <br>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box box-success">
            
            <div class="modal-body form">
                <form class="form-horizontal" action="<?php echo site_url('kpikaryawan/update');?>" method="post">
                    <div class="form-body">
                        <input type="hidden"  name="id" id="id" value="<?php echo $record['id'] ?>">
                        <div class="form-group">
                            <label class="control-label col-md-3">Karyawan</label>
                            <div class="col-md-5">
                                <select class="form-control select2" style="width: 100%;" name='id_karyawan' id="id_karyawan">
                                    <option value='0'>Pilih Karyawan</option>
                                    <?php
                                         if (!empty($karyawan)) {
                                            foreach ($karyawan as $r) {
                                              echo "<option value='$r->id_karyawan'";
                                              echo $record['id_karyawan'] == $r->id_karyawan ? 'selected' : '';
                                              echo">$r->nama_karyawan</option>";
                                            }
                                        }  
                                    ?>
                                  </select>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-md-3">KPI</label>
                            <div class="col-md-5">
                                <select class="form-control select2" style="width: 100%;" name='id_kpi' id="id_kpi">
                                    <option value='0'>Pilih KPI</option>
                                    <?php
                                         if (!empty($kpikaryawan)) {
                                            foreach ($kpikaryawan as $r) {
                                              echo "<option value='$r->id_kpi'";
                                              echo $record['id_kpi'] == $r->id_kpi ? 'selected' : '';
                                              echo">$r->nama_kpi</option>";
                                            }
                                        }  
                                    ?>
                                  </select>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-md-3">Unit</label>
                            <div class="col-md-5">
                                <select class="form-control select2" style="width: 100%;" name='id_unit' id="id_unit">
                                    <option value='0'>Pilih Unit</option>
                                    <?php
                                         if (!empty($unit)) {
                                            foreach ($unit as $r) {
                                              echo "<option value='$r->id_unit'";
                                              echo $record['id_unit'] == $r->id_unit ? 'selected' : '';
                                              echo">$r->nama_unit</option>";
                                            }
                                        }  
                                    ?>
                                  </select>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-md-3">Department</label>
                            <div class="col-md-5">
                                <select class="form-control select2" style="width: 100%;" name='id_departemen' id="id_departemen">
                                    <option value='0'>Pilih Departement</option>
                                    <?php
                                         if (!empty($departemen)) {
                                            foreach ($departemen as $r) {
                                              echo "<option value='$r->id_departemen'";
                                              echo $record['id_departemen'] == $r->id_departemen ? 'selected' : '';
                                              echo">$r->nama_departemen</option>";
                                            }
                                        }  
                                    ?>
                                  </select>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-md-3">Section</label>
                            <div class="col-md-5">
                                <select class="form-control select2" style="width: 100%;" name='id_section' id="id_section">
                                    <option value='0'>Pilih Section</option>
                                    <?php
                                         if (!empty($section)) {
                                            foreach ($section as $r) {
                                              echo "<option value='$r->id_section'";
                                              echo $record['id_section'] == $r->id_section ? 'selected' : '';
                                              echo">$r->nama_section</option>";
                                            }
                                        }  
                                    ?>
                                  </select>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-md-3">Jabatan</label>
                            <div class="col-md-5">
                                <select class="form-control select2" style="width: 100%;" name='id_jabatan' id="id_jabatan">
                                    <option value='0'>Pilih Jabatan</option>
                                    <?php
                                         if (!empty($jabatan)) {
                                            foreach ($jabatan as $r) {
                                              echo "<option value='$r->id_jabatan'";
                                              echo $record['id_jabatan'] == $r->id_jabatan ? 'selected' : '';
                                              echo">$r->nama_jabatan</option>";
                                            }
                                        }  
                                    ?>
                                  </select>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-md-3">Nama KPI</label>
                            <div class="col-md-5">
                                <input name="nama_kpi" id='nama_kpi' placeholder="Nama KPI" class="form-control" type="text" required value="<?php echo  $record['nama_kpi']?>">
                                <span class="help-block"></span>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-md-3">Bobot</label>
                            <div class="col-md-5">
                                <input name="bobot" id='bobot' placeholder="Bobot" class="form-control" type="text" required value="<?php echo  $record['bobot']?>">
                                <span class="help-block"></span>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-md-3">Perspective</label>
                            <div class="col-md-5">
                                <input name="perspective" id='perspective' placeholder="Perspective" class="form-control" type="text" required value="<?php echo  $record['perspective']?>">
                                <span class="help-block"></span>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-md-3">Sub KPI</label>
                            <div class="col-md-5">
                                <input name="subkpi" id='subkpi' placeholder="Sub KPI" class="form-control" type="text" required value="<?php echo  $record['subkpi']?>">
                                <span class="help-block"></span>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-md-3">Parameter</label>
                            <div class="col-md-5">
                                <textarea name='parameter' id="parameter" class="form-control "><?php echo  $record['parameter']?></textarea>
                                <span class="help-block"></span>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-md-3">Measurement</label>
                            <div class="col-md-5">
                                <textarea name='measurement' id="measurement" class="form-control "><?php echo  $record['measurement']?></textarea>
                                <span class="help-block"></span>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-md-3">Source Data</label>
                            <div class="col-md-5">
                                <textarea name='sourcesdata' id="sourcesdata" class="form-control "><?php echo  $record['sourcesdata']?></textarea>
                                <span class="help-block"></span>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-md-3">PIC</label>
                            <div class="col-md-5">
                                <select class="form-control select2" style="width: 100%;" name='pic' id="pic">
                                    <option value='0'>Pilih PIC</option>
                                    <?php
                                         if (!empty($pic)) {
                                            foreach ($pic as $r) {
                                              echo "<option value='$r->id_pic'";
                                              echo $record['pic'] == $r->id_pic ? 'selected' : '';
                                              echo">$r->nama_pic</option>";
                                            }
                                        }  
                                    ?>
                                  </select>
                            </div>
                        </div>
                       
                        <div class="form-group">
                            <label class="control-label col-md-3">Status</label>
                            <div class="col-md-5">
                                <select class="form-control" name="enableflag" id='enableflag' style="width: 240px">
                                    <option value="0" <?php if($record['enableflag']=="0") echo 'selected="selected"'; ?> >Aktif</option>
                                    <option value="1" <?php if($record['enableflag']=="1") echo 'selected="selected"'; ?> >Tidak Aktif</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </form>
            </div>

            <div class="panel-footer">
                <button id="update" class="btn btn-info">Update</button>
                <a href="<?php echo site_url('c_master/kpikaryawan'); ?>" class="btn btn-danger">Batal</a>
            </div>

            </div>
            <!-- /.box-body -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

<?php 
$this->load->view('template/foot');
?> 

<!-- jQuery 2.2.3 -->
<script src="<?php echo base_url('assets/plugins/jQuery/jquery-2.2.3.min.js') ?>"></script>
<!-- Bootstrap 3.3.6 -->
<script src="<?php echo base_url('assets/bootstrap/js/bootstrap.min.js') ?>"></script>
<!-- Select2 -->
<script src="<?php echo base_url('assets/plugins/select2/select2.full.min.js') ?>"></script>
<!-- DataTables -->
<script src="<?php echo base_url('assets/plugins/datatables/jquery.dataTables.min.js') ?>"></script>
<script src="<?php echo base_url('assets/plugins/datatables/dataTables.bootstrap.min.js') ?>"></script>
<!-- SlimScroll -->
<script src="<?php echo base_url('assets/plugins/slimScroll/jquery.slimscroll.min.js') ?>"></script>
<!-- FastClick -->
<script src="<?php echo base_url('assets/plugins/fastclick/fastclick.js') ?>"></script>
<!-- AdminLTE App -->
<script src="<?php echo base_url('assets/dist/js/app.min.js') ?>"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?php echo base_url('assets/dist/js/demo.js') ?>"></script>
<script>
    $(function () {
        //Initialize Select2 Elements
        $(".select2").select2();

    });
</script>

<script>

    $("#update").click(function(){
        var id_kpi=$("#id_kpi").val();
        var id_unit=$("#id_unit").val();
        var id_departemen=$("#id_departemen").val();
        var id_section=$("#id_section").val();
        var id_jabatan=$("#id_jabatan").val();
        var id_karyawan=$("#id_karyawan").val();
        var nama_kpi=$("#nama_kpi").val();
        var bobot=$("#bobot").val();
        var perspective=$("#perspective").val();
        var subkpi=$("#subkpi").val();
        var parameter=$("#parameter").val();
        var measurement=$("#measurement").val();
        var sourcesdata=$("#sourcesdata").val();
        var pic=$("#pic").val();
        var enableflag=$("#enableflag").val();
        var id=$("#id").val();

        if (id_kpi=="") {
            alert("ID KPI Tidak Boleh Kosong");
            return false;
        }else if (id_unit=="") {
            alert("Unit Tidak Boleh Kosong");
            return false;
        }else if (id_departemen=="") {
            alert("Departement Tidak Boleh Kosong");
            return false;  
        }else if (nama_kpi=="") {
            alert("Nama KPI Tidak Boleh Kosong");
            return false;
        }else if (bobot=="") {
            alert("Bobot Tidak Boleh Kosong");
            return false;    
        // }else if (perspective=="") {
        //     alert("Perspective Tidak Boleh Kosong");
        //     return false;
        // }else if (subkpi=="") {
        //     alert("Sub KPI Tidak Boleh Kosong");
        //     return false;
        // }else if (parameter=="") {
        //     alert("Parameter Tidak Boleh Kosong");
        //     return false;
        // }else if (measurement=="") {
        //     alert("Measurement Tidak Boleh Kosong");
        //     return false;
        // }else if (sourcesdata=="") {
        //     alert("Source Data Tidak Boleh Kosong");
        //     return false;    
        }else if (pic=="") {
            alert("PIC Tidak Boleh Kosong");
            return false;                            
        }else{
            $('#update').attr('disabled',true); //set button disable
            $.ajax({
                url:"<?php echo site_url('c_master/kpikaryawan/update');?>",
                type:"POST",
                data:"id_kpi="+id_kpi+"&id_unit="+id_unit+"&id_departemen="+id_departemen+"&id_section="+id_section+"&id_jabatan="+id_jabatan+
                "&id_karyawan="+id_karyawan+
                "&nama_kpi="+nama_kpi+"&bobot="+bobot+"&perspective="+perspective+"&subkpi="+subkpi+
                "&parameter="+parameter+"&measurement="+measurement+"&sourcesdata="+sourcesdata+"&pic="+pic+
                "&enableflag="+enableflag+"&id="+id,
                cache:false,
                success:function(html){
                    alert("Edit Kpi Berhasil");
                        //location.reload();
                        window.location = "<?php echo site_url('c_master/kpikaryawan');?>";
                    }
                })
        }

    })

</script>

</body>
</html>