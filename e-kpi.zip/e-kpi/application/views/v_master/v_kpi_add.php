<?php 
$this->load->view('template/head');
$this->load->view('template/topbar_third');
$this->load->view('template/sidebar_third');
?>


<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        KPI
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Master</a></li>
        <li class="active">Data KPI</li>
      </ol>
    </section>
    
    <br>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box box-success">
            
            <div class="modal-body form">
                <form class="form-horizontal" action="<?php echo site_url('kpi/save');?>" method="post">
                    <div class="form-body">
                        <div class="form-group">
                            <label class="control-label col-md-3">ID KPI</label>
                            <div class="col-md-5">
                                <input name="id_kpi" id='id_kpi' placeholder="ID KPI" class="form-control" type="text" required>
                                <span class="help-block"></span>
                            </div>
                        </div>
                        <div class="form-group">
                                <label class="control-label col-md-3">Unit</label>
                                <div class="col-md-5">
                                  <select class="form-control select2" style="width: 100%;" name='id_unit' id="id_unit">
                                    <option value='0'>Pilih Unit</option>
                                    <?php
                                         if (!empty($unit)) {
                                         foreach ($unit as $r) {
                                    echo "<option value=".$r->id_unit.">".$r->nama_unit."</option>";
                                        }
                                     }
                                    ?>
                                  </select>
                                </div>
                        </div>
                        <div class="form-group">
                                <label class="control-label col-md-3">Department</label>
                                <div class="col-md-5">
                                  <select class="form-control select2" style="width: 100%;" name='id_departemen' id="id_departemen">
                                    <option value='0'>Pilih Department</option>
                                    <?php
                                         if (!empty($departemen)) {
                                         foreach ($departemen as $r) {
                                    echo "<option value=".$r->id_departemen.">".$r->nama_departemen."</option>";
                                        }
                                     }
                                    ?>
                                  </select>
                                </div>
                        </div>
                        <div class="form-group">
                                <label class="control-label col-md-3">Section</label>
                                <div class="col-md-5">
                                  <select class="form-control select2" style="width: 100%;" name='id_section' id="id_section">
                                    <option value='0'>Pilih Section</option>
                                    <?php
                                         if (!empty($section)) {
                                         foreach ($section as $r) {
                                    echo "<option value=".$r->id_section.">".$r->nama_section."</option>";
                                        }
                                     }
                                    ?>
                                  </select>
                                </div>
                        </div>
                        <div class="form-group">
                                <label class="control-label col-md-3">Jabatan</label>
                                <div class="col-md-5">
                                  <select class="form-control select2" style="width: 100%;" name='id_jabatan' id="id_jabatan">
                                    <option value='0'>Pilih Jabatan</option>
                                    <?php
                                         if (!empty($jabatan)) {
                                         foreach ($jabatan as $r) {
                                    echo "<option value=".$r->id_jabatan.">".$r->nama_jabatan."</option>";
                                        }
                                     }
                                    ?>
                                  </select>
                                </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-md-3">Nama KPI</label>
                            <div class="col-md-5">
                                <input name="nama_kpi" id='nama_kpi' placeholder="Nama KPI" class="form-control" type="text" required>
                                <span class="help-block"></span>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-md-3">Perspective</label>
                            <div class="col-md-5">
                                <input name="perspective" id='perspective' placeholder="Perspective" class="form-control" type="text" required>
                                <span class="help-block"></span>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-md-3">Sub KPI</label>
                            <div class="col-md-5">
                                <input name="subkpi" id='subkpi' placeholder="Sub KPI" class="form-control" type="text" required>
                                <span class="help-block"></span>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-md-3">Parameter</label>
                            <div class="col-md-5">
                                <textarea name="parameter" id='parameter' placeholder="Parameter" class="form-control" type="text" required></textarea>
                                <span class="help-block"></span>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-md-3">Measurement</label>
                            <div class="col-md-5">
                                <textarea name="measurement" id='measurement' placeholder="Measurement" class="form-control" type="text" required></textarea>
                                <span class="help-block"></span>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-md-3">Source Data</label>
                            <div class="col-md-5">
                                <textarea name="sourcesdata" id='sourcesdata' placeholder="Source Data" class="form-control" type="text" required></textarea>
                                <span class="help-block"></span>
                            </div>
                        </div>
                        <div class="form-group">
                                <label class="control-label col-md-3">PIC</label>
                                <div class="col-md-5">
                                  <select class="form-control select2" style="width: 100%;" name='pic' id="pic">
                                    <option value='0'>Pilih PIC</option>
                                    <?php
                                         if (!empty($pic)) {
                                         foreach ($pic as $r) {
                                    echo "<option value=".$r->id_pic.">".$r->nama_pic."</option>";
                                        }
                                     }
                                    ?>
                                  </select>
                                </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-md-3">Status</label>
                            <div class="col-md-5">
                                <select class="form-control" name="enableflag" id='enableflag' style="width: 240px">
                                    <option value="0">Aktif</option>
                                    <option value="1">Tidak Aktif</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </form>
            </div>

            <div class="panel-footer">
                <button id="save" class="btn btn-info">Simpan</button>
                <a href="<?php echo site_url('c_master/kpi'); ?>" class="btn btn-danger">Batal</a>
            </div>

            </div>
            <!-- /.box-body -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

<?php 
$this->load->view('template/foot');
?> 

<!-- jQuery 2.2.3 -->
<script src="<?php echo base_url('assets/plugins/jQuery/jquery-2.2.3.min.js') ?>"></script>
<!-- Bootstrap 3.3.6 -->
<script src="<?php echo base_url('assets/bootstrap/js/bootstrap.min.js') ?>"></script>
<!-- Select2 -->
<script src="<?php echo base_url('assets/plugins/select2/select2.full.min.js') ?>"></script>
<!-- DataTables -->
<script src="<?php echo base_url('assets/plugins/datatables/jquery.dataTables.min.js') ?>"></script>
<script src="<?php echo base_url('assets/plugins/datatables/dataTables.bootstrap.min.js') ?>"></script>
<!-- SlimScroll -->
<script src="<?php echo base_url('assets/plugins/slimScroll/jquery.slimscroll.min.js') ?>"></script>
<!-- FastClick -->
<script src="<?php echo base_url('assets/plugins/fastclick/fastclick.js') ?>"></script>
<!-- AdminLTE App -->
<script src="<?php echo base_url('assets/dist/js/app.min.js') ?>"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?php echo base_url('assets/dist/js/demo.js') ?>"></script>
<script>
    $(function () {
        //Initialize Select2 Elements
        $(".select2").select2();

    });
</script>

<script>

    $("#save").click(function(){
        var id_kpi=$("#id_kpi").val();
        var id_unit=$("#id_unit").val();
        var id_departemen=$("#id_departemen").val();
        var id_jabatan=$("#id_jabatan").val();
        var nama_kpi=$("#nama_kpi").val();
        var perspective=$("#perspective").val();
        var subkpi=$("#subkpi").val();
        var parameter=$("#parameter").val();
        var measurement=$("#measurement").val();
        var sourcesdata=$("#sourcesdata").val();
        var pic=$("#pic").val();
        var enableflag=$("#enableflag").val();

        if (id_kpi=="") {
            alert("ID KPI Tidak Boleh Kosong");
            return false;
        }else if (id_unit=="") {
            alert("Unit Tidak Boleh Kosong");
            return false;
        }else if (id_departemen=="") {
            alert("Department Tidak Boleh Kosong");
            return false;
        }else if (nama_kpi=="") {
            alert("Nama KPI Tidak Boleh Kosong");
            return false;
        // }else if (perspective=="") {
        //     alert("Perspective Tidak Boleh Kosong");
        //     return false;
        // }else if (subkpi=="") {
        //     alert("Sub KPI Tidak Boleh Kosong");
        //     return false;
        // }else if (parameter=="") {
        //     alert("Parameter Tidak Boleh Kosong");
        //     return false;
        // }else if (measurement=="") {
        //     alert("Measurement Tidak Boleh Kosong");
        //     return false;
        // }else if (sourcesdata=="") {
        //     alert("Source Data Boleh Kosong");
        //     return false;    
        }else if (pic=="") {
            alert("PIC Tidak Boleh Kosong");
            return false;    
        }else{
            $('#save').attr('disabled',true); //set button disable
            $.ajax({
                url:"<?php echo site_url('c_master/kpi/save');?>",
                type:"POST",
                data:"id_kpi="+id_kpi+"&id_unit="+id_unit+"&id_departemen="+id_departemen+"&id_jabatan="+id_jabatan+
                     "&nama_kpi="+nama_kpi+"&perspective="+perspective+"&subkpi="+subkpi+
                     "&parameter="+parameter+"&measurement="+measurement+"&sourcesdata="+sourcesdata+"&pic="+pic+
                     "&enableflag="+enableflag,
                cache:false,
                success:function(html){
                    alert("Tambah KPI Berhasil");
                        //location.reload();
                        window.location = "<?php echo site_url('c_master/kpi');?>";
                    }
                })
        }

    })

</script>

</body>
</html>