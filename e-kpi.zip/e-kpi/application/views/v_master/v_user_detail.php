<?php 
$this->load->view('template/head');
$this->load->view('template/topbar_fourth');
$this->load->view('template/sidebar_fourth');
?>


<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Detail User
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Master</a></li>
        <li class="active">Data Detail User</li>
      </ol>
    </section>
    
    <br>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box box-success">
            
            <div class="modal-body form">
                <form class="form-horizontal" action="<?php echo site_url('user/update');?>" method="post">
                    <div class="form-body">
                        <input type="hidden"  name="id" id="id" value="<?php echo $record['id'] ?>">
                        <div class="form-group">
                            <label class="control-label col-md-3">ID User</label>
                            <div class="col-md-5">
                                <input name="id_user" id='id_user' placeholder="ID KPI" class="form-control" type="text" required value="<?php echo  $record['id_user']?>" disabled>
                                <span class="help-block"></span>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-md-3">Karyawan</label>
                            <div class="col-md-5">
                                <select class="form-control select2" style="width: 100%;" name='id_karyawan' id="id_karyawan" disabled>
                                    <option value='0'>Pilih Karyawan</option>
                                    <?php
                                         if (!empty($pic)) {
                                            foreach ($pic as $r) {
                                              echo "<option value='$r->id_karyawan'";
                                              echo $record['id_karyawan'] == $r->id_karyawan ? 'selected' : '';
                                              echo">$r->nama_karyawan</option>";
                                            }
                                        }  
                                    ?>
                                  </select>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-md-3">Nama</label>
                            <div class="col-md-5">
                                <input name="name" id='name' placeholder="Nama" class="form-control" type="text" required value="<?php echo  $record['name']?>" disabled>
                                <span class="help-block"></span>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-md-3">Username</label>
                            <div class="col-md-5">
                                <input name="username" id='username' placeholder="Username" class="form-control" type="text" required value="<?php echo  $record['username']?>" disabled>
                                <span class="help-block"></span>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-md-3">Password</label>
                            <div class="col-md-5">
                                <input name="password" id='password' placeholder="Password" class="form-control" type="text" required value="<?php echo  $record['password']?>" disabled>
                                <span class="help-block"></span>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-md-3">Deskripsi Pekerjaan</label>
                            <div class="col-md-5">
                                <textarea name='jobdescription' id="jobdescription" class="form-control " disabled><?php echo  $record['jobdescription']?></textarea>
                                <span class="help-block"></span>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-md-3">Level</label>
                            <div class="col-md-5">
                                <select class="form-control" name="menu" id='menu' style="width: 240px" disabled>
                                    <option value="superadmin" <?php if($record['menu']=="superadmin") echo 'selected="selected"'; ?> >Super Admin</option>
                                    <option value="admin" <?php if($record['menu']=="admin") echo 'selected="selected"'; ?> >Admin</option>
                                    <option value="bod" <?php if($record['menu']=="bod") echo 'selected="selected"'; ?> >BOD</option>
                                    <option value="unithead" <?php if($record['menu']=="unithead") echo 'selected="selected"'; ?> >Unit Head</option>
                                    <option value="depthead" <?php if($record['menu']=="depthead") echo 'selected="selected"'; ?> >Dept. Head</option>
                                    <option value="sectionhead" <?php if($record['menu']=="sectionhead") echo 'selected="selected"'; ?> >Section Head</option>
                                    <option value="officer" <?php if($record['menu']=="officer") echo 'selected="selected"'; ?> >Officer</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-md-3">Key</label>
                            <div class="col-md-5">
                                <input name="key_id" id='key_id' placeholder="Key" class="form-control" type="text" required value="<?php echo  $record['key_id']?>" disabled>
                                <span class="help-block"></span>
                            </div>
                        </div>
                      
                        <div class="form-group">
                            <label class="control-label col-md-3">Attachment</label>
                            <div class="col-md-5">
                                <input name="attachement" id='attachement' placeholder="Attachement" class="form-control" type="text" required value="<?php echo  $record['attachement']?>" disabled>
                                <img src="<?php echo base_url('upload/'. $record['attachement']);?>" />
                                <span class="help-block"></span>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-md-3">Status</label>
                            <div class="col-md-5">
                                <select class="form-control" name="enableflag" id='enableflag' style="width: 240px" disabled>
                                    <option value="0" <?php if($record['enableflag']=="0") echo 'selected="selected"'; ?> >Aktif</option>
                                    <option value="1" <?php if($record['enableflag']=="1") echo 'selected="selected"'; ?> >Tidak Aktif</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </form>
            </div>

            <div class="panel-footer">
                <!-- <button id="update" class="btn btn-info">Update</button> -->
                <a href="<?php echo site_url('c_master/user'); ?>" class="btn btn-danger">kembali</a>
            </div>

            </div>
            <!-- /.box-body -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

<?php 
$this->load->view('template/foot');
?> 

<!-- jQuery 2.2.3 -->
<script src="<?php echo base_url('assets/plugins/jQuery/jquery-2.2.3.min.js') ?>"></script>
<!-- Bootstrap 3.3.6 -->
<script src="<?php echo base_url('assets/bootstrap/js/bootstrap.min.js') ?>"></script>
<!-- DataTables -->
<script src="<?php echo base_url('assets/plugins/datatables/jquery.dataTables.min.js') ?>"></script>
<script src="<?php echo base_url('assets/plugins/datatables/dataTables.bootstrap.min.js') ?>"></script>
<!-- SlimScroll -->
<script src="<?php echo base_url('assets/plugins/slimScroll/jquery.slimscroll.min.js') ?>"></script>
<!-- FastClick -->
<script src="<?php echo base_url('assets/plugins/fastclick/fastclick.js') ?>"></script>
<!-- AdminLTE App -->
<script src="<?php echo base_url('assets/dist/js/app.min.js') ?>"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?php echo base_url('assets/dist/js/demo.js') ?>"></script>

<script>

    $("#update").click(function(){
        var id_user=$("#id_user").val();
        var id_karyawan=$("#id_karyawan").val();
        var name=$("#name").val();
        var username=$("#username").val();
        var password=$("#password").val();
        var jobdescription=$("#jobdescription").val();
        var menu=$("#menu").val();
        var key_id=$("#key_id").val();
        var images=$("#images").val();
        var enableflag=$("#enableflag").val();
        var id=$("#id").val();

        if (id_user=="") {
            alert("ID User Tidak Boleh Kosong");
            return false;
        }else if (id_karyawan=="") {
            alert("Karyawan Tidak Boleh Kosong");
            return false;
        }else if (name=="") {
            alert("Nama Tidak Boleh Kosong");
            return false;
        }else if (username=="") {
            alert("Username Tidak Boleh Kosong");
            return false;
        }else if (password=="") {
            alert("Password Tidak Boleh Kosong");
            return false;
        }else if (jobdescription=="") {
            alert("Deskripsi Tidak Boleh Kosong");
            return false;
        }else if (menu=="") {
            alert("Menu Tidak Boleh Kosong");
            return false;
        }else if (key_id=="") {
            alert("Key Tidak Boleh Kosong");
            return false;
        }else if (images=="") {
            alert("Foto Tidak Boleh Kosong");
            return false;                         
        }else{
            $('#update').attr('disabled',true); //set button disable
            $.ajax({
                url:"<?php echo site_url('c_master/user/update');?>",
                type:"POST",
                data:"id_user="+id_user+"&id_karyawan="+id_karyawan+"&name="+name+
                "&username="+username+"&password="+password+"&jobdescription="+jobdescription+
                "&menu="+menu+"&key_id="+key_id+"&images="+images+
                "&enableflag="+enableflag+"&id="+id,
                cache:false,
                success:function(html){
                    alert("Edit User Berhasil");
                        //location.reload();
                        window.location = "<?php echo site_url('c_master/user');?>";
                    }
                })
        }

    })

</script>

</body>
</html>