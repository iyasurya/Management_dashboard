<?php 
$this->load->view('template/head');
$this->load->view('template/topbar_fourth');
$this->load->view('template/sidebar_fourth');
?>


<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Edit Karyawan
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Master</a></li>
        <li class="active">Data Edit Karyawan</li>
      </ol>
    </section>
    
    <br>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box box-success">
            
            <div class="modal-body form">
                <form class="form-horizontal" action="<?php echo site_url('karyawan/update');?>" method="post">
                    <div class="form-body">
                        <input type="hidden"  name="id" id="id" value="<?php echo $record['id'] ?>">
                        <div class="form-group">
                            <label class="control-label col-md-3">NIP</label>
                            <div class="col-md-5">
                                <input name="id_karyawan" id='id_karyawan' placeholder="NIP Karyawan" class="form-control" type="text" required value="<?php echo  $record['id_karyawan']?>">
                                <span class="help-block"></span>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-md-3">Unit</label>
                            <div class="col-md-5">
                                <select class="form-control select2" style="width: 100%;" name='id_unit' id="id_unit">
                                    <option value='0'>Pilih Unit</option>
                                    <?php
                                         if (!empty($unit)) {
                                            foreach ($unit as $r) {
                                              echo "<option value='$r->id_unit'";
                                              echo $record['id_unit'] == $r->id_unit ? 'selected' : '';
                                              echo">$r->nama_unit</option>";
                                            }
                                        }  
                                    ?>
                                  </select>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-md-3">Department</label>
                            <div class="col-md-5">
                                <select class="form-control select2" style="width: 100%;" name='id_departemen' id="id_departemen">
                                    <option value='0'>Pilih Departement</option>
                                    <?php
                                         if (!empty($departemen)) {
                                            foreach ($departemen as $r) {
                                              echo "<option value='$r->id_departemen'";
                                              echo $record['id_departemen'] == $r->id_departemen ? 'selected' : '';
                                              echo">$r->nama_departemen</option>";
                                            }
                                        }  
                                    ?>
                                  </select>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-md-3">Section</label>
                            <div class="col-md-5">
                                <select class="form-control select2" style="width: 100%;" name='id_section' id="id_section">
                                    <option value='0'>Pilih Section</option>
                                    <?php
                                         if (!empty($section)) {
                                            foreach ($section as $r) {
                                              echo "<option value='$r->id_section'";
                                              echo $record['id_section'] == $r->id_section ? 'selected' : '';
                                              echo">$r->nama_section</option>";
                                            }
                                        }  
                                    ?>
                                  </select>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-md-3">Jabatan</label>
                            <div class="col-md-5">
                                <select class="form-control select2" style="width: 100%;" name='id_jabatan' id="id_jabatan">
                                    <option value='0'>Pilih Jabatan</option>
                                    <?php
                                         if (!empty($jabatan)) {
                                            foreach ($jabatan as $r) {
                                              echo "<option value='$r->id_jabatan'";
                                              echo $record['id_jabatan'] == $r->id_jabatan ? 'selected' : '';
                                              echo">$r->nama_jabatan</option>";
                                            }
                                        }  
                                    ?>
                                  </select>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-md-3">NIK</label>
                            <div class="col-md-5">
                                <input name="nik" id='nik' placeholder="NIK" class="form-control" type="text" required value="<?php echo  $record['nik']?>">
                                <span class="help-block"></span>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-md-3">Nama Karyawan</label>
                            <div class="col-md-5">
                                <input name="nama_karyawan" id='nama_karyawan' placeholder="Nama Karyawan" class="form-control" type="text" required value="<?php echo  $record['nama_karyawan']?>">
                                <span class="help-block"></span>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-md-3">Alamat Karyawan</label>
                            <div class="col-md-5">
                                <textarea name='alamat_karyawan' id="alamat_karyawan" class="form-control "><?php echo  $record['alamat_karyawan']?></textarea>
                                <span class="help-block"></span>
                            </div>
                        </div>
                        <!-- <div class="form-group">
                            <label class="control-label col-md-3">Jenis Kelamin</label>
                            <div class="col-md-5">
                            <select class="form-control" name="jenis_kelamin" id='jenis_kelamin' style="width: 240px">
                                    <option value="0" <?php if($record['jenis_kelamin']=="0") echo 'selected="selected"'; ?> >Laki-Laki</option>
                                    <option value="1" <?php if($record['jenis_kelamin']=="1") echo 'selected="selected"'; ?> >Perempuan</option>
                                </select>
                            </div>
                        </div> -->
                        <div class="form-group">
                            <label class="control-label col-md-3">Jenis Kelamin</label>
                            <div class="col-md-5">
                                <select class="form-control select2" style="width: 100%;" name='jenis_kelamin' id="jenis_kelamin">
                                    <option value='0'>Pilih Kelamin</option>
                                    <?php
                                         if (!empty($jeniskelamin)) {
                                            foreach ($jeniskelamin as $r) {
                                              echo "<option value='$r->id_subparameter'";
                                              echo $record['jenis_kelamin'] == $r->id_subparameter ? 'selected' : '';
                                              echo">$r->nama_subparameter</option>";
                                            }
                                        }  
                                    ?>
                                  </select>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-md-3">Tanggal Lahir</label>
                            <div class="col-md-5">
                                <input name="tanggal_lahir" id='tanggal_lahir' class="form-control" type="date" value="<?php echo $record['tanggal_lahir'];?>">
                                <span class="help-block"></span>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-md-3">Tanggal Masuk</label>
                            <div class="col-md-5">
                            <input name="tanggal_masuk" id='tanggal_masuk' class="form-control" type="date" value="<?php echo $record['tanggal_masuk'];?>">
                                <span class="help-block"></span>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-md-3">No HP</label>
                            <div class="col-md-5">
                                <input name="no_hp" id='no_hp' placeholder="No HP" class="form-control" type="text" required value="<?php echo  $record['no_hp']?>">
                                <span class="help-block"></span>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-md-3">Email</label>
                            <div class="col-md-5">
                                <input name="email" id='email' placeholder="Email" class="form-control" type="text" required value="<?php echo  $record['email']?>">
                                <span class="help-block"></span>
                            </div>
                        </div>

                        
                        <div class="form-group">
                            <label class="control-label col-md-3">Status</label>
                            <div class="col-md-5">
                                <select class="form-control" name="enableflag" id='enableflag' style="width: 240px">
                                    <option value="0" <?php if($record['enableflag']=="0") echo 'selected="selected"'; ?> >Aktif</option>
                                    <option value="1" <?php if($record['enableflag']=="1") echo 'selected="selected"'; ?> >Tidak Aktif</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </form>
            </div>

            <div class="panel-footer">
                <button id="update" class="btn btn-info">Update</button>
                <a href="<?php echo site_url('c_master/karyawan'); ?>" class="btn btn-danger">Batal</a>
            </div>

            </div>
            <!-- /.box-body -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

<?php 
$this->load->view('template/foot');
?> 

<!-- jQuery 2.2.3 -->
<script src="<?php echo base_url('assets/plugins/jQuery/jquery-2.2.3.min.js') ?>"></script>
<!-- Bootstrap 3.3.6 -->
<script src="<?php echo base_url('assets/bootstrap/js/bootstrap.min.js') ?>"></script>
<!-- Select2 -->
<script src="<?php echo base_url('assets/plugins/select2/select2.full.min.js') ?>"></script>
<!-- DataTables -->
<script src="<?php echo base_url('assets/plugins/datatables/jquery.dataTables.min.js') ?>"></script>
<script src="<?php echo base_url('assets/plugins/datatables/dataTables.bootstrap.min.js') ?>"></script>
<!-- SlimScroll -->
<script src="<?php echo base_url('assets/plugins/slimScroll/jquery.slimscroll.min.js') ?>"></script>
<!-- FastClick -->
<script src="<?php echo base_url('assets/plugins/fastclick/fastclick.js') ?>"></script>
<!-- AdminLTE App -->
<script src="<?php echo base_url('assets/dist/js/app.min.js') ?>"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?php echo base_url('assets/dist/js/demo.js') ?>"></script>
<script>
    $(function () {
        //Initialize Select2 Elements
        $(".select2").select2();

    });
</script>

<script>

    $("#update").click(function(){
        var id_karyawan=$("#id_karyawan").val();
        var id_unit=$("#id_unit").val();
        var id_departemen=$("#id_departemen").val();
        var id_section=$("#id_section").val();
        var id_jabatan=$("#id_jabatan").val();
        var nik=$("#nik").val();
        var nama_karyawan=$("#nama_karyawan").val();
        var alamat_karyawan=$("#alamat_karyawan").val();
        var jenis_kelamin=$("#jenis_kelamin").val();
        var tanggal_lahir=$("#tanggal_lahir").val();
        var tanggal_masuk=$("#tanggal_masuk").val();
        var no_hp=$("#no_hp").val();
        var email=$("#email").val();
        var enableflag=$("#enableflag").val();
        var id=$("#id").val();

        if (id_karyawan=="") {
            alert("NIP Karyawan Tidak Boleh Kosong");
            return false;
        }else if (id_unit=="") {
            alert("Unit Tidak Boleh Kosong");
            return false;
        }else if (id_departemen=="") {
            alert("Departement Tidak Boleh Kosong");
            return false;    
        }else if (id_jabatan=="") {
            alert("Jabatan Tidak Boleh Kosong");
            return false;
        }else if (nik=="") {
            alert("NIK Tidak Boleh Kosong");
            return false;
        }else if (nama_karyawan=="") {
            alert("Nama Karyawan Tidak Boleh Kosong");
            return false;
        }else if (alamat_karyawan=="") {
            alert("Alamat Karyawan Tidak Boleh Kosong");
            return false;
        }else if (jenis_kelamin=="") {
            alert("Jenis Kelamin Tidak Boleh Kosong");
            return false;
        }else if (tanggal_lahir=="") {
            alert("Tanggal Lahir Tidak Boleh Kosong");
            return false;
        }else if (tanggal_masuk=="") {
            alert("Tanggal Masuk Tidak Boleh Kosong");
            return false;
        }else if (no_hp=="") {
            alert("No HP Tidak Boleh Kosong");
            return false;  
        }else if (email=="") {
            alert("Email Tidak Boleh Kosong");
            return false;                              
        }else{
            $('#update').attr('disabled',true); //set button disable
            $.ajax({
                url:"<?php echo site_url('c_master/karyawan/update');?>",
                type:"POST",
                data:"id_karyawan="+id_karyawan+"&id_unit="+id_unit+"&id_departemen="+id_departemen+"&id_section="+id_section+"&id_jabatan="+id_jabatan+
                "&nik="+nik+"&nama_karyawan="+nama_karyawan+"&alamat_karyawan="+alamat_karyawan+"&jenis_kelamin="+jenis_kelamin+
                "&tanggal_lahir="+tanggal_lahir+"&tanggal_masuk="+tanggal_masuk+"&no_hp="+no_hp+"&email="+email+
                "&enableflag="+enableflag+"&id="+id,
                cache:false,
                success:function(html){
                    alert("Edit Karyawan Berhasil");
                        //location.reload();
                        window.location = "<?php echo site_url('c_master/karyawan');?>";
                    }
                })
        }

    })

</script>

</body>
</html>