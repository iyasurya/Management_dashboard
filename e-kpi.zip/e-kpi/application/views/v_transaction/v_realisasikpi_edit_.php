<?php 
$this->load->view('template/head');
$this->load->view('template/topbar_fourth');
$this->load->view('template/sidebar_fourth');
?>


<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Realisasi KPI
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Input KPI</a></li>
        <li class="active">Data Realisasi KPI</li>
      </ol>
    </section>
    
    <br>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box box-success">
            
            <div class="modal-body form">
                <form class="form-horizontal" action="<?php echo site_url('c_transaction/realisasikpi/update');?>" method="post" enctype="multipart/form-data">
                    <div class="form-body">
                        <input type="hidden"  name="id" id="id" value="<?php echo $record['id'] ?>">
                        <div class="form-group">
                            <label class="control-label col-md-3">ID Realisasi</label>
                            <div class="col-md-5">
                                <input name="id_realisasi" id='id_realisasi' placeholder="ID Realisasi" class="form-control" type="text" required value="<?php echo  $record['id_realisasi']?>" >
                                <span class="help-block"></span>
                            </div>
                        </div>

                         <div class="form-group">
                                <label class="control-label col-md-3">Karyawan</label>
                                <div class="col-md-5">
                                  <select class="form-control select2" style="width: 100%;" name='id_karyawan' id="id_karyawan">
                                    <option value='0'>Pilih Karyawan</option>
                                    <?php
                                         if (!empty($karyawan)) {
                                            foreach ($karyawan as $r) {
                                              echo "<option value='$r->id_karyawan'";
                                              echo $record['id_karyawan'] == $r->id_karyawan ? 'selected' : '';
                                              echo">$r->nama_karyawan</option>";
                                            }
                                        }  
                                    ?>
                                  </select>
                                </div>
                        </div>
                        <div class="form-group">
                                <label class="control-label col-md-3">Kategori</label>
                                <div class="col-md-5">
                                  <select class="form-control select2" style="width: 100%;" name='id_kategori' id="id_kategori">
                                    <option value='0'>Pilih Kategori</option>
                                    <?php
                                         if (!empty($kategori)) {
                                            foreach ($kategori as $r) {
                                              echo "<option value='$r->id_kategori'";
                                              echo $record['id_kategori'] == $r->id_kategori ? 'selected' : '';
                                              echo">$r->nama_kategori</option>";
                                            }
                                        }  
                                    ?>
                                  </select>
                                </div>
                        </div>
                        <div class="form-group">
                                <label class="control-label col-md-3">Bulan</label>
                                <div class="col-md-5">
                                  <select class="form-control select2" style="width: 100%;" name='id_bulan' id="id_bulan">
                                    <option value='0'>Pilih Bulan</option>
                                    <?php
                                         if (!empty($bulan)) {
                                            foreach ($bulan as $r) {
                                              echo "<option value='$r->id_bulan'";
                                              echo $record['id_bulan'] == $r->id_bulan ? 'selected' : '';
                                              echo">$r->nama_bulan</option>";
                                            }
                                        }  
                                    ?>
                                  </select>
                                </div>
                        </div>
                        <div class="form-group">
                                <label class="control-label col-md-3">Tahun</label>
                                <div class="col-md-5">
                                  <select class="form-control select2" style="width: 100%;" name='id_tahun' id="id_tahun">
                                    <option value='0'>Pilih Tahun</option>
                                    <?php
                                         if (!empty($tahun)) {
                                            foreach ($tahun as $r) {
                                              echo "<option value='$r->id_tahun'";
                                              echo $record['id_tahun'] == $r->id_tahun ? 'selected' : '';
                                              echo">$r->nama_tahun</option>";
                                            }
                                        }  
                                    ?>
                                  </select>
                                </div>
                        </div>
                        <div class="form-group">
                                <label class="control-label col-md-3">Supervisor</label>
                                <div class="col-md-5">
                                  <select class="form-control select2" style="width: 100%;" name='id_supervisor' id="id_supervisor">
                                    <option value='0'>Pilih Supervisor</option>
                                    <?php
                                         if (!empty($karyawan)) {
                                            foreach ($karyawan as $r) {
                                              echo "<option value='$r->id_karyawan'";
                                              echo $record['id_karyawan'] == $r->id_karyawan ? 'selected' : '';
                                              echo">$r->nama_karyawan</option>";
                                            }
                                        }  
                                    ?>
                                  </select>
                                </div>
                        </div>

                        
                       
                        <div class="form-group">
                            <label class="control-label col-md-3">Skor Akhir</label>
                            <div class="col-md-5">
                                <input name="skor_akhir" id='skor_akhir' placeholder="Skor Akhir" class="form-control" type="text" required value="<?php echo  $record['skor_akhir']?>">
                                <span class="help-block"></span>
                            </div>
                        </div>
                       
                       
                        
                    </div>
                    <br>                    
                   
               
            <div class="panel-footer">
                <button class="btn btn-info">Update</button>
                <a href="<?php echo site_url('c_transaction/realisasikpi'); ?>" class="btn btn-danger">Batal</a>
            </div>

             </form>

             </div>

            </div>
            <!-- /.box-body -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

<?php 
$this->load->view('template/foot');
?> 

<!-- jQuery 2.2.3 -->
<script src="<?php echo base_url('assets/plugins/jQuery/jquery-2.2.3.min.js') ?>"></script>
<!-- Bootstrap 3.3.6 -->
<script src="<?php echo base_url('assets/bootstrap/js/bootstrap.min.js') ?>"></script>
<!-- Select2 -->
<script src="<?php echo base_url('assets/plugins/select2/select2.full.min.js') ?>"></script>
<!-- DataTables -->
<script src="<?php echo base_url('assets/plugins/datatables/jquery.dataTables.min.js') ?>"></script>
<script src="<?php echo base_url('assets/plugins/datatables/dataTables.bootstrap.min.js') ?>"></script>
<!-- SlimScroll -->
<script src="<?php echo base_url('assets/plugins/slimScroll/jquery.slimscroll.min.js') ?>"></script>
<!-- FastClick -->
<script src="<?php echo base_url('assets/plugins/fastclick/fastclick.js') ?>"></script>
<!-- AdminLTE App -->
<script src="<?php echo base_url('assets/dist/js/app.min.js') ?>"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?php echo base_url('assets/dist/js/demo.js') ?>"></script>

<script>
    $(function () {
        //Initialize Select2 Elements
        $(".select2").select2();

    });
</script>

</body>
</html>