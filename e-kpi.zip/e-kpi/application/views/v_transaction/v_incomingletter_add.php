<?php 
$this->load->view('template/head');
$this->load->view('template/topbar_third');
$this->load->view('template/sidebar_third');
?>


<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Surat Masuk
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Input KPI</a></li>
        <li class="active">Data Surat Masuk</li>
      </ol>
    </section>
    
    <br>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box box-success">
            
            <div class="modal-body form">
                <form class="form-horizontal" action="<?php echo site_url('c_transaction/incomingletter/save');?>" method="post" enctype="multipart/form-data">
                    <div class="form-body">
                        <div class="form-group">
                            <label class="control-label col-md-3">Tanggal</label>
                            <div class="col-md-5">
                                <input name="dateofletter" id='dateofletter' class="form-control" type="date" value="<?php echo $dateofletter;?>">
                                <span class="help-block"></span>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-md-3">Judul Surat</label>
                            <div class="col-md-5">
                                <input name="title" id='title' placeholder="Judul Surat" class="form-control" type="text" required>
                                <span class="help-block"></span>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-md-3">Pengirim</label>
                            <div class="col-md-5">
                                <input name="originofletter" id='originofletter' placeholder="Pengirim" class="form-control" type="text" required>
                                <span class="help-block"></span>
                            </div>
                        </div>

                        <div class="form-group">
                                <label class="control-label col-md-3">Jenis Surat</label>
                                <div class="col-md-5">
                                  <select class="form-control select2" style="width: 100%;" name='typeofletterid' id="typeofletterid">
                                    <option value='0'>Pilih Jenis Surat</option>
                                    <?php
                                         if (!empty($record)) {
                                         foreach ($record as $r) {
                                    echo "<option value=".$r->idtypeofletter.">".$r->typeofletter."</option>";
                                        }
                                     }
                                    ?>
                                  </select>
                                </div>
                        </div>

                        <div class="form-group">
                                <label class="control-label col-md-3">Klasifikasi Surat</label>
                                <div class="col-md-5">
                                  <select class="form-control select2" style="width: 100%;" name='classificationofletterid' id="classificationofletterid">
                                    <option value='0'>Pilih Klasifikasi Surat</option>
                                    <?php
                                         if (!empty($record2)) {
                                         foreach ($record2 as $r) {
                                    echo "<option value=".$r->idclassificationofletter.">".$r->classificationofletter."</option>";
                                        }
                                     }
                                    ?>
                                  </select>
                                </div>
                        </div>
                        
                         <div class="form-group">
                                <label class="control-label col-md-3">Keterangan Surat</label>
                                <div class="col-md-5">
                                    <textarea name='description' id="description" class="form-control "> </textarea>
                                </div>
                        </div>

                        <div class="form-group">
                                <label class="control-label col-md-3">Lampiran Surat</label>
                                <div class="col-md-5">
                                    <input type="file" name="attachement" id="attachement"/>
                                </div>
                        </div>
                    </div>
                
            

            <div class="panel-footer">
                <button class="btn btn-info">Simpan</button>
                <a href="<?php echo site_url('c_transaction/incomingletter'); ?>" class="btn btn-danger">Batal</a>
            </div>

            </form>

            </div>

            </div>
            <!-- /.box-body -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

<?php 
$this->load->view('template/foot');
?> 

<!-- jQuery 2.2.3 -->
<script src="<?php echo base_url('assets/plugins/jQuery/jquery-2.2.3.min.js') ?>"></script>
<!-- Bootstrap 3.3.6 -->
<script src="<?php echo base_url('assets/bootstrap/js/bootstrap.min.js') ?>"></script>
<!-- Select2 -->
<script src="<?php echo base_url('assets/plugins/select2/select2.full.min.js') ?>"></script>
<!-- DataTables -->
<script src="<?php echo base_url('assets/plugins/datatables/jquery.dataTables.min.js') ?>"></script>
<script src="<?php echo base_url('assets/plugins/datatables/dataTables.bootstrap.min.js') ?>"></script>
<!-- SlimScroll -->
<script src="<?php echo base_url('assets/plugins/slimScroll/jquery.slimscroll.min.js') ?>"></script>
<!-- FastClick -->
<script src="<?php echo base_url('assets/plugins/fastclick/fastclick.js') ?>"></script>
<!-- AdminLTE App -->
<script src="<?php echo base_url('assets/dist/js/app.min.js') ?>"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?php echo base_url('assets/dist/js/demo.js') ?>"></script>

<script>
    $(function () {
        //Initialize Select2 Elements
        $(".select2").select2();

    });
</script>

</body>
</html>