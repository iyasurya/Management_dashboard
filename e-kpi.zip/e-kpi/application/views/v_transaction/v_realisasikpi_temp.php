<table id="table" class="table table-striped table-bordered" cellspacing="0" width="100%">
    <thead>
      <tr>
        <th><center>Nama KPI</center></th>
        <th><center>KPI Objectif</center></th>
        <th><center>KPI Waktu</center></th>
        <th><center>KPI</center></th>
        <th style="width:150px;"><center>Action</center></th>
    </tr>
</thead>
<tbody>
   <?php foreach($tmp as $tmp):?>
   
   <tr class="gradeX">
     <td><?php echo $tmp->nama_kpi;?></td>
     <td style="width:100px;"><?php echo $tmp->obj;?></td>
     <td style="width:100px;"><?php echo $tmp->waktu;?></td>
     <td style="width:100px;"><?php echo $tmp->realisasi;?></td>
     <td style="width:150px;">
        <center><a href="#" class="delbutton" kode="<?php echo $tmp->kode;?>"><i class="glyphicon glyphicon-trash"></i></a></center>
    </td>

    <?php
    endforeach;
    ?>
</tbody>
</table>

<script>
$(".delbutton").click(function(){
    var kode=$(this).attr("kode");
    if(confirm("Anda yakin akan menghapus?"))
        $.ajax({
            url:"<?php echo site_url('c_transaction/realisasikpi/delTemp');?>",
            type:"POST",
            data:"kode="+kode,
            cache:false,
            success:function(html){
                loadDataTemp();
                $('#nama_kpi').focus();
            }
        });
});
</script>