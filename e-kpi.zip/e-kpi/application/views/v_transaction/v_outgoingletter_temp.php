<table id="table" class="table table-striped table-bordered" cellspacing="0" width="100%">
    <thead>
      <tr>
        <th><center>Nama Pegawai</center></th>
        <th style="width:150px;"><center>Action</center></th>
    </tr>
</thead>
<tbody>
   <?php foreach($tmp as $tmp):?>
   
   <tr class="gradeX">
     <td><?php echo $tmp->employeename;?></td>
     <td>
        <center><a href="#" class="delbutton" kode="<?php echo $tmp->kode;?>"><i class="glyphicon glyphicon-trash"></i></a></center>
    </td>

    <?php
    endforeach;
    ?>
</tbody>
</table>

<script>
$(".delbutton").click(function(){
    var kode=$(this).attr("kode");
    if(confirm("Anda yakin akan menghapus?"))
        $.ajax({
            url:"<?php echo site_url('c_transaction/outgoingletter/delTemp');?>",
            type:"POST",
            data:"kode="+kode,
            cache:false,
            success:function(html){
                loadDataTemp();
                $('#employeename').focus();
            }
        });
});
</script>