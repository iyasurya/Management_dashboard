<?php 
$this->load->view('template/head');
$this->load->view('template/topbar_third');
$this->load->view('template/sidebar_third');
?>


<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Surat Keluar
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Input KPI</a></li>
        <li class="active">Data Surat Keluar</li>
      </ol>
    </section>
    
    <br>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box box-success">
            
            <div class="modal-body form">
                <form class="form-horizontal" action="<?php echo site_url('c_transaction/outgoingletter/save');?>" method="post">
                    <div class="form-body">
                        <div class="form-group">
                            <label class="control-label col-md-3">Tanggal</label>
                            <div class="col-md-5">
                                <input name="dateofletter" id='dateofletter' class="form-control" type="date" value="<?php echo $dateofletter;?>">
                                <span class="help-block"></span>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-md-3">Judul Surat</label>
                            <div class="col-md-5">
                                <input name="title" id='title' placeholder="Judul Surat" class="form-control" type="text" required>
                                <span class="help-block"></span>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-md-3">Penerima</label>
                            <div class="col-md-5">
                                <input name="destinationofletter" id='destinationofletter' placeholder="Penerima" class="form-control" type="text" required>
                                <span class="help-block"></span>
                            </div>
                        </div>

                        <div class="form-group">
                                <label class="control-label col-md-3">Jenis Surat</label>
                                <div class="col-md-5">
                                  <select class="form-control select2" style="width: 100%;" name='typeofletterid' id="typeofletterid">
                                    <option value='0'>Pilih Jenis Surat</option>
                                    <?php
                                         if (!empty($record)) {
                                         foreach ($record as $r) {
                                    echo "<option value=".$r->idtypeofletter.">".$r->typeofletter."</option>";
                                        }
                                     }
                                    ?>
                                  </select>
                                </div>
                        </div>

                        <div class="form-group">
                                <label class="control-label col-md-3">Klasifikasi Surat</label>
                                <div class="col-md-5">
                                  <select class="form-control select2" style="width: 100%;" name='classificationofletterid' id="classificationofletterid">
                                    <option value='0'>Pilih Klasifikasi Surat</option>
                                    <?php
                                         if (!empty($record2)) {
                                         foreach ($record2 as $r) {
                                    echo "<option value=".$r->idclassificationofletter.">".$r->classificationofletter."</option>";
                                        }
                                     }
                                    ?>
                                  </select>
                                </div>
                        </div>

                        <div class="form-group">
                            <label class="control-label col-md-3">Waktu</label>
                            <div class="col-md-5">
                                <input name="time" id='time' placeholder="Waktu" class="form-control" type="text" required>
                                <span class="help-block"></span>
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="control-label col-md-3">Tempat</label>
                            <div class="col-md-5">
                                <input name="place" id='place' placeholder="Tempat" class="form-control" type="text" required>
                                <span class="help-block"></span>
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="control-label col-md-3">Tanggal Penugasan</label>
                            <div class="col-md-5">
                                <input name="dateoftask" id='dateoftask' class="form-control" type="date" value="<?php echo $dateoftask;?>">
                                <span class="help-block"></span>
                            </div>
                        </div>

                         <div class="form-group">
                                <label class="control-label col-md-3">Acara</label>
                                <div class="col-md-5">
                                    <textarea name='toletter' id="toletter" class="form-control "> </textarea>
                                </div>
                        </div>

                         <div class="form-group">
                            <label class="control-label col-md-3">Nama Penandatangan</label>
                            <div class="col-md-5">
                                <input name="sign" id='sign' placeholder="Nama Penandatangan" class="form-control" type="text" required>
                                <span class="help-block"></span>
                            </div>
                        </div>

                        <div class="form-group">
                                <label class="control-label col-md-3">Tembusan</label>
                                <div class="col-md-5">
                                    <textarea name='copyofletter' id="copyofletter" class="form-control "> </textarea>
                                </div>
                        </div>
                        
                         <div class="form-group">
                                <label class="control-label col-md-3">Keterangan Surat</label>
                                <div class="col-md-5">
                                    <textarea name='description' id="description" class="form-control "> </textarea>
                                </div>
                        </div>
                    </div>

                    <br>

                    <table id="table" class="table table-striped table-bordered" cellspacing="0" width="100%">
                        <thead>
                          <tr>
                            <th><center>Nama Pegawai</center></th>
                            <th style="width:150px;"><center>Action</center></th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <th><input type="text" id="employeename" name="employeename" style="width: 100%; text-align: center;"></th>
                            <th style="width:150px;"><center><button id="addemployee" class="btn btn-sm btn-success"><i class="glyphicon glyphicon-plus"></i></button></center></th>
                        </tr>
                    </tbody>
                </table>

                <div id="viewDisposisi"></div>

                </form>
            </div>

            <div class="panel-footer">
                <button id="save" class="btn btn-info">Simpan</button>
                <a href="<?php echo site_url('c_transaction/outgoingletter'); ?>" class="btn btn-danger">Batal</a>
            </div>

            </div>
            <!-- /.box-body -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

<?php 
$this->load->view('template/foot');
?> 

<!-- jQuery 2.2.3 -->
<script src="<?php echo base_url('assets/plugins/jQuery/jquery-2.2.3.min.js') ?>"></script>
<!-- Bootstrap 3.3.6 -->
<script src="<?php echo base_url('assets/bootstrap/js/bootstrap.min.js') ?>"></script>
<!-- Select2 -->
<script src="<?php echo base_url('assets/plugins/select2/select2.full.min.js') ?>"></script>
<!-- DataTables -->
<script src="<?php echo base_url('assets/plugins/datatables/jquery.dataTables.min.js') ?>"></script>
<script src="<?php echo base_url('assets/plugins/datatables/dataTables.bootstrap.min.js') ?>"></script>
<!-- SlimScroll -->
<script src="<?php echo base_url('assets/plugins/slimScroll/jquery.slimscroll.min.js') ?>"></script>
<!-- FastClick -->
<script src="<?php echo base_url('assets/plugins/fastclick/fastclick.js') ?>"></script>
<!-- AdminLTE App -->
<script src="<?php echo base_url('assets/dist/js/app.min.js') ?>"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?php echo base_url('assets/dist/js/demo.js') ?>"></script>

<script type="text/javascript" src="<?=base_url();?>/assets/autocomplete/js/jquery-ui.js"></script>
<link rel="stylesheet" href="<?=base_url();?>/assets/autocomplete/css/jquery-autocomplete.css">

<script>
    $(function () {
        //Initialize Select2 Elements
        $(".select2").select2();

    });

    $(function(){
            $("#employeename").autocomplete({
      source: "<?php echo site_url('c_transaction/outgoingletter/getEmployee');?>" // path to the get_birds method
    });
    });

    function loadDataTemp(args) {
      //code
      $("#viewDisposisi").load("<?php echo site_url('c_transaction/outgoingletter/viewDisposisi');?>");
      $('#addemployee').attr('disabled',false); //set button enable
    } 

    function nullEmployeename(args) {
      //code
      $("#employeename").val('');
    }

    $("#addemployee").click(function(){
      var employeename=$("#employeename").val();

      if (employeename=="") {
      //code
      alert("Nama Pegawai Harus Diisi");
      return false;
        }else{
          $('#addemployee').attr('disabled',true); //set button disable 
          $.ajax({
            url:"<?php echo site_url('c_transaction/outgoingletter/addEmployee');?>",
            type:"POST",
            data:"employeename="+employeename,
            cache:false,
            success:function(html){
              loadDataTemp();
              nullEmployeename();
              $('#employeename').focus();
          },
          error:function (jqXHR, textStatus, errorThrown)
          {
            $('#addemployee').attr('disabled',false); //set button disable 
        }
      })    
     }
    })

    $("#save").click(function(){
        var dateofletter=$("#dateofletter").val();
        var title=$("#title").val();
        var destinationofletter=$("#destinationofletter").val();
        var typeofletterid=$("#typeofletterid").val();
        var classificationofletterid=$("#classificationofletterid").val();
        var time=$("#time").val();
        var place=$("#place").val();
        var dateoftask=$("#dateoftask").val();
        var toletter=$("#toletter").val();
        var sign=$("#sign").val();
        var copyofletter=$("#copyofletter").val();
        var description=$("#description").val();

        if (title=="") {
            alert("Judul Surat Tidak Boleh Kosong");
            return false;
        }else if (destinationofletter=="") {
            alert("Penerima Tidak Boleh Kosong");
            return false;
        }else{
            $('#save').attr('disabled',true); //set button disable
            $.ajax({
                url:"<?php echo site_url('c_transaction/outgoingletter/save');?>",
                type:"POST",
                data:"dateofletter="+dateofletter+"&destinationofletter="+destinationofletter+"&title="+title+"&typeofletterid="+typeofletterid+"&classificationofletterid="+classificationofletterid+"&time="+time+"&place="+place+"&dateoftask="+dateoftask+"&toletter="+toletter+"&description="+description+"&sign="+sign+"&copyofletter="+copyofletter,
                cache:false,
                success:function(html){
                    alert("Tambah Surat Keluar Berhasil");
                        //location.reload();
                        window.location = "<?php echo site_url('c_transaction/outgoingletter');?>";
                    }
                })
        }

    })

</script>

</body>
</html>