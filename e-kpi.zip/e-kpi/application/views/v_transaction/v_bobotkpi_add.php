<?php 
$this->load->view('template/head');
$this->load->view('template/topbar_third');
$this->load->view('template/sidebar_third');
?>


<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Bobot KPI
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Input KPI</a></li>
        <li class="active">Data Bobot KPI</li>
      </ol>
    </section>
    
    <br>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box box-success">
            
            <div class="modal-body form">
                <form class="form-horizontal" action="<?php echo site_url('c_transaction/bobotkpi/save');?>" method="post" enctype="multipart/form-data">
                    <div class="form-body">
                        
                        <div class="form-group">
                            <label class="control-label col-md-3">ID Target</label>
                            <div class="col-md-5">
                                <input name="id_target" id='id_target' class="form-control" type="text" value="<?php echo $kodejadi;?>" disabled>
                                <span class="help-block"></span>
                            </div>
                        </div>
                        <div class="form-group">
                                <label class="control-label col-md-3">KPI</label>
                                <div class="col-md-5">
                                  <select class="form-control select2" style="width: 100%;" name='id_kpi' id="id_kpi">
                                    <option value='0'>Pilih KPI</option>
                                    <?php
                                         if (!empty($kpi)) {
                                         foreach ($kpi as $r) {
                                    echo "<option value=".$r->id_kpi.">".$r->nama_kpi."</option>";
                                        }
                                     }
                                    ?>
                                  </select>
                                </div>
                        </div>
                        <div class="form-group">
                                <label class="control-label col-md-3">Bulan</label>
                                <div class="col-md-5">
                                  <select class="form-control select2" style="width: 100%;" name='id_bulan' id="id_bulan">
                                    <option value='0'>Pilih Bulan</option>
                                    <?php
                                         if (!empty($bulan)) {
                                         foreach ($bulan as $r) {
                                    echo "<option value=".$r->id_bulan.">".$r->nama_bulan."</option>";
                                        }
                                     }
                                    ?>
                                  </select>
                                </div>
                        </div>
                        <div class="form-group">
                                <label class="control-label col-md-3">Tahun</label>
                                <div class="col-md-5">
                                  <select class="form-control select2" style="width: 100%;" name='id_tahun' id="id_tahun">
                                    <option value='0'>Pilih Tahun</option>
                                    <?php
                                         if (!empty($tahun)) {
                                         foreach ($tahun as $r) {
                                    echo "<option value=".$r->id_tahun.">".$r->nama_tahun."</option>";
                                        }
                                     }
                                    ?>
                                  </select>
                                </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-md-3">Target KPI</label>
                            <div class="col-md-5">
                                <input name="target_kpi" id='target_kpi' placeholder="Target KPI" class="form-control" type="text" required>
                                <span class="help-block"></span>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-md-3">Unit Pengukuran</label>
                            <div class="col-md-5">
                                <input name="unit_pengukuran" id='unit_pengukuran' placeholder="Unit Pengukuran" class="form-control" type="text" required>
                                <span class="help-block"></span>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-md-3">Bobot KPI</label>
                            <div class="col-md-5">
                                <input name="bobot_kpi" id='bobot_kpi' placeholder="Bobot KPI" class="form-control" type="text" required>
                                <span class="help-block"></span>
                            </div>
                        </div>

                       
                    </div>
                
            

            <div class="panel-footer">
                <button class="btn btn-info">Simpan</button>
                <a href="<?php echo site_url('c_transaction/bobotkpi'); ?>" class="btn btn-danger">Batal</a>
            </div>

            </form>

            </div>

            </div>
            <!-- /.box-body -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

<?php 
$this->load->view('template/foot');
?> 

<!-- jQuery 2.2.3 -->
<script src="<?php echo base_url('assets/plugins/jQuery/jquery-2.2.3.min.js') ?>"></script>
<!-- Bootstrap 3.3.6 -->
<script src="<?php echo base_url('assets/bootstrap/js/bootstrap.min.js') ?>"></script>
<!-- Select2 -->
<script src="<?php echo base_url('assets/plugins/select2/select2.full.min.js') ?>"></script>
<!-- DataTables -->
<script src="<?php echo base_url('assets/plugins/datatables/jquery.dataTables.min.js') ?>"></script>
<script src="<?php echo base_url('assets/plugins/datatables/dataTables.bootstrap.min.js') ?>"></script>
<!-- SlimScroll -->
<script src="<?php echo base_url('assets/plugins/slimScroll/jquery.slimscroll.min.js') ?>"></script>
<!-- FastClick -->
<script src="<?php echo base_url('assets/plugins/fastclick/fastclick.js') ?>"></script>
<!-- AdminLTE App -->
<script src="<?php echo base_url('assets/dist/js/app.min.js') ?>"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?php echo base_url('assets/dist/js/demo.js') ?>"></script>

<script>
    $(function () {
        //Initialize Select2 Elements
        $(".select2").select2();

    });
</script>

</body>
</html>