<?php 
$this->load->view('template/head');
$this->load->view('template/topbar_fourth');
$this->load->view('template/sidebar_fourth');
?>


<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Disposisi Surat Masuk
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Input KPI</a></li>
        <li class="active">Data Disposisi Surat Masuk</li>
      </ol>
    </section>
    
    <br>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box box-success">
            
            <div class="modal-body form">
                <form class="form-horizontal" action="<?php echo site_url('c_transaction/disposisi/update');?>" method="post" enctype="multipart/form-data">
                    <div class="form-body">
                        <input type="hidden"  name="id" id="id" value="<?php echo $record['id'] ?>">
                        <input type="hidden"  name="idincomingletter" id="idincomingletter" value="<?php echo $record['idincomingletter'] ?>">
                        
                        <div class="form-group">
                            <label class="control-label col-md-3">No Surat</label>
                            <div class="control-label col-md-5" style="text-align: left">
                                <?php echo  $record['referencenumber']?>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-md-3">Tanggal</label>
                             <div class="control-label col-md-5" style="text-align: left">
                                <?php echo  $record['dateofletter']?>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-md-3">Judul Surat</label>
                            <div class="control-label col-md-5" style="text-align: left">
                                <?php echo  $record['title']?>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-md-3">Pengirim</label>
                             <div class="control-label col-md-5" style="text-align: left">
                                <?php echo  $record['originofletter']?>
                            </div>
                        </div>

                         <div class="form-group">
                            <label class="control-label col-md-3">Jenis Surat</label>
                            <div class="control-label col-md-5" style="text-align: left">
                                <?php echo  $typeofletter?>
                            </div>
                        </div>

                        <div class="form-group">
                             <label class="control-label col-md-3">Klasifikasi Surat</label>
                               <div class="control-label col-md-5" style="text-align: left">
                                <?php echo  $classificationofletter?>
                            </div>
                        </div>
                       <div class="form-group">
                                <label class="control-label col-md-3">Keterangan Surat</label>
                                <div class="control-label col-md-5" style="text-align: left">
                                    <?php echo  $record['description']?>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-md-3">Lampiran Surat</label>
                            <div class="col-md-5">
                                <a href="../../../upload/<?php echo  $record['attachement']?>" target="_blank"><?php echo  $record['attachement']?></a>
                            </div>
                        </div>

                    </div>
                    
                    <br>

                    <table id="table" class="table table-striped table-bordered" cellspacing="0" width="100%">
                        <thead>
                          <tr>
                            <th><center>Nama Pegawai</center></th>
                            <th style="width:150px;"><center>Action</center></th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <th><input type="text" id="employeename" name="employeename" style="width: 100%; text-align: center;"></th>
                            <th style="width:150px;"><center><button id="addemployee" class="btn btn-sm btn-success"><i class="glyphicon glyphicon-plus"></i></button></center></th>
                        </tr>
                    </tbody>
                </table>

                <div id="viewDisposisi"></div>
               
            <div class="panel-footer">
                <button id="save" class="btn btn-info">Simpan</button>
                <a href="<?php echo site_url('c_transaction/disposisi'); ?>" class="btn btn-danger">Batal</a>
            </div>

             </form>

             </div>

            </div>
            <!-- /.box-body -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

<?php 
$this->load->view('template/foot');
?> 

<!-- jQuery 2.2.3 -->
<script src="<?php echo base_url('assets/plugins/jQuery/jquery-2.2.3.min.js') ?>"></script>
<!-- Bootstrap 3.3.6 -->
<script src="<?php echo base_url('assets/bootstrap/js/bootstrap.min.js') ?>"></script>
<!-- Select2 -->
<script src="<?php echo base_url('assets/plugins/select2/select2.full.min.js') ?>"></script>
<!-- DataTables -->
<script src="<?php echo base_url('assets/plugins/datatables/jquery.dataTables.min.js') ?>"></script>
<script src="<?php echo base_url('assets/plugins/datatables/dataTables.bootstrap.min.js') ?>"></script>
<!-- SlimScroll -->
<script src="<?php echo base_url('assets/plugins/slimScroll/jquery.slimscroll.min.js') ?>"></script>
<!-- FastClick -->
<script src="<?php echo base_url('assets/plugins/fastclick/fastclick.js') ?>"></script>
<!-- AdminLTE App -->
<script src="<?php echo base_url('assets/dist/js/app.min.js') ?>"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?php echo base_url('assets/dist/js/demo.js') ?>"></script>

<script type="text/javascript" src="<?=base_url();?>/assets/autocomplete/js/jquery-ui.js"></script>
<link rel="stylesheet" href="<?=base_url();?>/assets/autocomplete/css/jquery-autocomplete.css">

<script>
 $(function(){
    $("#employeename").autocomplete({
  source: "<?php echo site_url('c_transaction/disposisi/getEmployee');?>" // path to the get_birds method
});
});

function loadDataTemp(args) {
  //code
  $("#viewDisposisi").load("<?php echo site_url('c_transaction/disposisi/viewDisposisi');?>");
  $('#addemployee').attr('disabled',false); //set button enable
} 

function nullEmployeename(args) {
  //code
  $("#employeename").val('');
}

$("#addemployee").click(function(){
  var employeename=$("#employeename").val();

if (employeename=="") {
  //code
  alert("Nama Pegawai Harus Diisi");
  return false;
}else{
  $('#addemployee').attr('disabled',true); //set button disable 
  $.ajax({
    url:"<?php echo site_url('c_transaction/disposisi/addEmployee');?>",
    type:"POST",
    data:"employeename="+employeename,
    cache:false,
    success:function(html){
      loadDataTemp();
      nullEmployeename();
      $('#employeename').focus();
    },
    error:function (jqXHR, textStatus, errorThrown)
    {
    $('#addemployee').attr('disabled',false); //set button disable 
    }
  })    
}
})

$("#save").click(function(){
        var idincomingletter=$("#idincomingletter").val();

            $('#save').attr('disabled',true); //set button disable
            $.ajax({
                url:"<?php echo site_url('c_transaction/disposisi/save');?>",
                type:"POST",
                data:"idincomingletter="+idincomingletter,
                cache:false,
                success:function(html){
                    alert("Disposisi Berhasil disimpan");
                        //location.reload();
                        window.location = "<?php echo site_url('c_transaction/disposisi');?>";
                    }
                })

    })
</script>

</body>
</html>