<?php 
$this->load->view('template/head');
$this->load->view('template/topbar_five');
$this->load->view('template/sidebar_five');
?>


<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Surat Keluar
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Input KPI</a></li>
        <li class="active">Data Surat Keluar</li>
      </ol>
    </section>
    
    <br>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box box-success">
            
            <div class="modal-body form">
                <form class="form-horizontal" action="<?php echo site_url('c_transaction/outgoingletter/update');?>" method="post">
                    <div class="form-body">
                        <input type="hidden"  name="id" id="id" value="<?php echo $record['id'] ?>">
                        <input type="hidden"  name="idoutgoingletter" id="idoutgoingletter" value="<?php echo $record['idoutgoingletter'] ?>">
                        <input type="hidden"  name="classificationofletterid" id="classificationofletterid" value="<?php echo $record['classificationofletterid'] ?>">
                        <div class="form-group">
                            <label class="control-label col-md-3">No Surat</label>
                            <div class="col-md-5">
                                <input name="referencenumber" id='referencenumber' placeholder="No Surat" class="form-control" type="text" required value="<?php echo  $record['referencenumber']?>" disabled>
                                <span class="help-block"></span>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-md-3">Tanggal</label>
                            <div class="col-md-5">
                                <input name="dateofletter" id='dateofletter' class="form-control" type="date" value="<?php echo $record['dateofletter'];?>">
                                <span class="help-block"></span>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-md-3">Judul Surat</label>
                            <div class="col-md-5">
                                <input name="title" id='title' placeholder="Judul Surat" class="form-control" type="text" required value="<?php echo $record['title'];?>">
                                <span class="help-block"></span>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-md-3">Penerima</label>
                            <div class="col-md-5">
                                <input name="destinationofletter" id='destinationofletter' placeholder="Penerima" class="form-control" type="text" required value="<?php echo $record['destinationofletter'];?>">
                                <span class="help-block"></span>
                            </div>
                        </div>
                        <div class="form-group">
                                <label class="control-label col-md-3">Jenis Surat</label>
                                <div class="col-md-5">
                                  <select class="form-control select2" style="width: 100%;" name='typeofletterid' id="typeofletterid">
                                    <option value='0'>Pilih Jenis Surat</option>
                                    <?php
                                         if (!empty($record2)) {
                                            foreach ($record2 as $r) {
                                              echo "<option value='$r->idtypeofletter'";
                                              echo $record['typeofletterid'] == $r->idtypeofletter ? 'selected' : '';
                                              echo">$r->typeofletter</option>";
                                            }
                                        }  
                                    ?>
                                  </select>
                                </div>
                        </div>

                        <div class="form-group">
                                <label class="control-label col-md-3">Klasifikasi Surat</label>
                                <div class="col-md-5">
                                  <select class="form-control select2" style="width: 100%;" name='classificationofletterid2' id="classificationofletterid2" disabled>
                                    <option value='0'>Pilih Klasifikasi Surat</option>
                                    <?php
                                         if (!empty($record3)) {
                                            foreach ($record3 as $o) {
                                              echo "<option value='$o->idclassificationofletter'";
                                              echo $record['classificationofletterid'] == $o->idclassificationofletter ? 'selected' : '';
                                              echo">$o->classificationofletter</option>";
                                            }
                                        }
                                    ?>
                                  </select>
                                </div>
                        </div>

                        <div class="form-group">
                            <label class="control-label col-md-3">Waktu</label>
                            <div class="col-md-5">
                                <input name="time" id='time' placeholder="Waktu" class="form-control" type="text" required value="<?php echo $record['time'];?>">
                                <span class="help-block"></span>
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="control-label col-md-3">Tempat</label>
                            <div class="col-md-5">
                                <input name="place" id='place' placeholder="Tempat" class="form-control" type="text" required value="<?php echo $record['place'];?>">
                                <span class="help-block"></span>
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="control-label col-md-3">Tanggal Penugasan</label>
                            <div class="col-md-5">
                                <input name="dateoftask" id='dateoftask' class="form-control" type="date" value="<?php echo $record['dateoftask'];?>">
                                <span class="help-block"></span>
                            </div>
                        </div>

                         <div class="form-group">
                                <label class="control-label col-md-3">Acara</label>
                                <div class="col-md-5">
                                    <textarea name='toletter' id="toletter" class="form-control "><?php echo $record['toletter'];?></textarea>
                                </div>
                        </div>

                         <div class="form-group">
                            <label class="control-label col-md-3">Nama Penandatangan</label>
                            <div class="col-md-5">
                                <input name="sign" id='sign' placeholder="Nama Penandatangan" class="form-control" type="text" required value="<?php echo $record['sign'];?>">
                                <span class="help-block"></span>
                            </div>
                        </div>

                        <div class="form-group">
                                <label class="control-label col-md-3">Tembusan</label>
                                <div class="col-md-5">
                                    <textarea name='copyofletter' id="copyofletter" class="form-control "><?php echo $record['copyofletter'];?></textarea>
                                </div>
                        </div>
                        

                        <div class="form-group">
                                <label class="control-label col-md-3">Keterangan Surat</label>
                                <div class="col-md-5">
                                    <textarea name='description' id="description" class="form-control "><?php echo  $record['description']?></textarea>
                                </div>
                        </div>
                        
                        <div class="form-group">
                            <label class="control-label col-md-3">Status</label>
                            <div class="col-md-5">
                                <select class="form-control" name="status" id='status' style="width: 240px">
                                    <option value="0" <?php if($record['status']=="0") echo 'selected="selected"'; ?> >Belum Disposisi</option>
                                    <option value="1" <?php if($record['status']=="1") echo 'selected="selected"'; ?> >Sudah Disposisi</option>
                                    <option value="4" <?php if($record['status']=="4") echo 'selected="selected"'; ?> >Selesai</option>
                                </select>
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label class="control-label col-md-3">Hapus Surat Keluar</label>
                            <div class="col-md-5">
                                <select class="form-control" name="voidflag" id='voidflag' style="width: 240px">
                                    <option value="0" <?php if($record['voidflag']=="0") echo 'selected="selected"'; ?> >Tidak Hapus</option>
                                    <option value="1" <?php if($record['voidflag']=="1") echo 'selected="selected"'; ?> >Hapus</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <br>
                    <table id="table" class="table table-striped table-bordered" cellspacing="0" width="100%">
                        <thead>
                              <tr>
                                <th><center>Nama Pegawai</center></th>
                                <th style="width:150px;"><center>Action</center></th>
                            </tr>
                        </thead>
                        <tbody>
                         <?php foreach($detail as $detail):?>

                             <tr class="gradeX">
                               <td><?php echo $detail->employeename;?></td>
                               <td>
                                <center><a href="#" class="delbuttonDetail" kode="<?php echo $detail->id;?>"><i class="glyphicon glyphicon-trash"></i></a></center>
                            </td>

                            <?php
                        endforeach;
                        ?>
                        </tbody>
                    </table>
                    <br>
                    <table id="table" class="table table-striped table-bordered" cellspacing="0" width="100%">
                    
                    <tbody>
                        <tr>
                            <th><input type="text" id="employeename" name="employeename" style="width: 100%; text-align: center;"></th>
                            <th style="width:150px;"><center><button id="addemployee" class="btn btn-sm btn-success"><i class="glyphicon glyphicon-plus"></i></button></center></th>
                        </tr>
                    </tbody>
                </table>

                <div id="viewDisposisi"></div>
                </form>
            </div>

            <div class="panel-footer">
                <button id="update" class="btn btn-info">Update</button>
                <a href="<?php echo site_url('c_transaction/outgoingletter'); ?>" class="btn btn-danger">Batal</a>
            </div>

            </div>
            <!-- /.box-body -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

<?php 
$this->load->view('template/foot');
?> 

<!-- jQuery 2.2.3 -->
<script src="<?php echo base_url('assets/plugins/jQuery/jquery-2.2.3.min.js') ?>"></script>
<!-- Bootstrap 3.3.6 -->
<script src="<?php echo base_url('assets/bootstrap/js/bootstrap.min.js') ?>"></script>
<!-- Select2 -->
<script src="<?php echo base_url('assets/plugins/select2/select2.full.min.js') ?>"></script>
<!-- DataTables -->
<script src="<?php echo base_url('assets/plugins/datatables/jquery.dataTables.min.js') ?>"></script>
<script src="<?php echo base_url('assets/plugins/datatables/dataTables.bootstrap.min.js') ?>"></script>
<!-- SlimScroll -->
<script src="<?php echo base_url('assets/plugins/slimScroll/jquery.slimscroll.min.js') ?>"></script>
<!-- FastClick -->
<script src="<?php echo base_url('assets/plugins/fastclick/fastclick.js') ?>"></script>
<!-- AdminLTE App -->
<script src="<?php echo base_url('assets/dist/js/app.min.js') ?>"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?php echo base_url('assets/dist/js/demo.js') ?>"></script>

<script type="text/javascript" src="<?=base_url();?>/assets/autocomplete/js/jquery-ui.js"></script>
<link rel="stylesheet" href="<?=base_url();?>/assets/autocomplete/css/jquery-autocomplete.css">

<script>

    $(function () {
        //Initialize Select2 Elements
        $(".select2").select2();

    });

    $(function(){
            $("#employeename").autocomplete({
      source: "<?php echo site_url('c_transaction/outgoingletter/getEmployee');?>" // path to the get_birds method
    });
    });

    function loadDataTemp(args) {
      //code
      $("#viewDisposisi").load("<?php echo site_url('c_transaction/outgoingletter/viewDisposisi');?>");
      $('#addemployee').attr('disabled',false); //set button enable
    } 

    function nullEmployeename(args) {
      //code
      $("#employeename").val('');
    }

    $("#addemployee").click(function(){
      var employeename=$("#employeename").val();

      if (employeename=="") {
      //code
      alert("Nama Pegawai Harus Diisi");
      return false;
        }else{
          $('#addemployee').attr('disabled',true); //set button disable 
          $.ajax({
            url:"<?php echo site_url('c_transaction/outgoingletter/addEmployee');?>",
            type:"POST",
            data:"employeename="+employeename,
            cache:false,
            success:function(html){
              loadDataTemp();
              nullEmployeename();
              $('#employeename').focus();
          },
          error:function (jqXHR, textStatus, errorThrown)
          {
            $('#addemployee').attr('disabled',false); //set button disable 
        }
      })    
     }
    })

    $(".delbuttonDetail").click(function(){
        var kode=$(this).attr("kode");
        if(confirm("Anda yakin akan menghapus?"))
            $.ajax({
                url:"<?php echo site_url('c_transaction/outgoingletter/delDetail');?>",
                type:"POST",
                data:"kode="+kode,
                cache:false,
                success: function(){
              }
            });
            $(this).parents(".gradeX").animate({ opacity: "hide" }, "slow");

    });

    $("#update").click(function(){
        var dateofletter=$("#dateofletter").val();
        var title=$("#title").val();
        var destinationofletter=$("#destinationofletter").val();
        var typeofletterid=$("#typeofletterid").val();
        var classificationofletterid=$("#classificationofletterid").val();
        var time=$("#time").val();
        var place=$("#place").val();
        var dateoftask=$("#dateoftask").val();
        var toletter=$("#toletter").val();
        var sign=$("#sign").val();
        var copyofletter=$("#copyofletter").val();
        var description=$("#description").val();
        var status=$("#status").val();
        var voidflag=$("#voidflag").val();

        var id=$("#id").val();
        var idoutgoingletter=$("#idoutgoingletter").val();

        if (title=="") {
            alert("Judul Surat Tidak Boleh Kosong");
            return false;
        }else if (destinationofletter=="") {
            alert("Penerima Tidak Boleh Kosong");
            return false;
        }else{
            $('#update').attr('disabled',true); //set button disable
            $.ajax({
                url:"<?php echo site_url('c_transaction/outgoingletter/update');?>",
                type:"POST",
                data:"dateofletter="+dateofletter+"&destinationofletter="+destinationofletter+"&title="+title+"&typeofletterid="+typeofletterid+"&classificationofletterid="+classificationofletterid+"&time="+time+"&place="+place+"&dateoftask="+dateoftask+"&toletter="+toletter+"&description="+description+"&sign="+sign+"&copyofletter="+copyofletter+"&id="+id+"&status="+status+"&voidflag="+voidflag+"&idoutgoingletter="+idoutgoingletter,
                cache:false,
                success:function(html){
                    alert("Edit Surat Masuk Berhasil");
                        //location.reload();
                        window.location = "<?php echo site_url('c_transaction/outgoingletter');?>";
                    }
                })
        }

    })

</script>

</body>
</html>