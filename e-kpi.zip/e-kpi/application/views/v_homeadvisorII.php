<?php
$this->load->view('template/head');
$this->load->view('template/topbar');
$this->load->view('template/sidebar');
?>
  
  <!-- Content Wrapper. Contains page content -->
  
  <div class="content-wrapper" style="overflow-x: auto;">
  <form class="form-horizontal" action="<?php echo site_url('homeadvisor');?>" method="post"  id="form_id">
 <br>
  <div class="container">
 
	
 
	</div>
  
	<section class="col-lg-12 connectedSortable">
	<ul class="nav nav-tabs" >
			<li ><a href="homeadvisor">Page 1</a></li>
			<li class="active"><a href="homeadvisorII">Page 2</a></li>
		</ul>    

				<div class="panel panel-primary">
  <!-- Default panel contents -->
  <div class="panel-heading"> 
		<h3 style=" align-content: center;">
        <font style="color: white;"><center><b> HOME ADVISOR DASHBOARD</b></center></font>
    </h3>       
	</div>
	<br>
		<table style="width: 100%;" >
          
					<tr>
					<td>&nbsp;</td>
														<td> <div class="form-group">
															 
															 <div class="col-md-5" style="width: 100%; ">
																			<select class="form-control select2"  name='periode' id="periode" aria-placeholder="">
																				<option value='0'>Periode</option>
																				<?php
																						 if (!empty($periode)) {
																						 foreach ($periode as $r) {
																				echo "<option value=".$r->id_subparameter.">".$r->nama_subparameter."</option>";
																						}
																				 }
																				?>
																			</select>
															 </div>
													 </div></td>
													 <td>&nbsp;</td>
													 <td> <div class="form-group">
															 
															 <div class="col-md-5" style="width: 100%; ">
															 <select class="form-control select2" name='project' id="project" aria-placeholder="">
																				<option value='0'>project</option>
																				<?php
																						 if (!empty($project)) {
																						 foreach ($project as $r) {
																				echo "<option value=".$r->id_subparameter.">".$r->nama_subparameter."</option>";
																						}
																				 }
																				?>
																			</select>
															 </div>
													 </div></td> 
													 <td>&nbsp;</td>               
													 <td> <div class="form-group">
															 
															 <div class="col-md-5" style="width: 100%; ">
																	 <select class="form-control select2"  name='cluster' id="cluster" aria-placeholder="">
																			 <option value='0'>Cluster</option>
																			 <?php
																						 if (!empty($cluster)) {
																						 foreach ($cluster as $r) {
																				echo "<option value=".$r->id_subparameter.">".$r->nama_subparameter."</option>";
																						}
																				 }
																				?>
																		 </select>
															 </div>
													 </div></td>
													 <td>&nbsp;</td>
													 <td> <div class="form-group">
															 
															 <div class="col-md-5" style="width: 100%; ">
															 <select class="form-control select2"  name='team' id="team" aria-placeholder="">
																				<option value='0'>Team</option>
																				<?php
																						 if (!empty($team)) {
																						 foreach ($team as $r) {
																				echo "<option value=".$r->id_subparameter.">".$r->nama_subparameter."</option>";
																						}
																				 }
																				?>
																			</select>
															 </div>
													 </div></td>
													 <td>&nbsp;</td>
													 <td> <div class="form-group">
															 
															 <div class="col-md-5" style="width: 100%; ">
																	 <select class="form-control select2"  name='karyawan' id="karyawan" aria-placeholder="">
																			 <option value='0'>HA Names</option>
																			 <?php
																						 if (!empty($karyawan)) {
																						 foreach ($karyawan as $r) {
																				echo "<option value=".$r->id_karyawan.">".$r->nama_karyawan."</option>";
																						}
																				 }
																				?>
																		 </select>
															 </div>
													 </div></td>
													 <td>&nbsp;</td>
													 <td> <div class="form-group">
															 
															 <div class="col-md-5" style="width: 100%; ">
																	 <select class="form-control select2" name='sourcesha' id="sourcesha" aria-placeholder="">
																			 <option value='0'>Sources HA</option>
																			 <?php
																						 if (!empty($sourcesha)) {
																						 foreach ($sourcesha as $r) {
																				echo "<option value=".$r->id_subparameter.">".$r->nama_subparameter."</option>";
																						}
																				 }
																				?>
																		 </select>
															 </div>
													 </div></td>
													 <td>&nbsp;</td>
													 </tr>
													
													 <tr>
													 <td>&nbsp;</td>
													 <td> <div class="form-group">
															 
															 <div class="col-md-5" style="width: 100%; ">
																	 <select class="form-control select2" name='sourcesmarcomm' id="sourcesmarcomm" aria-placeholder="">
																			 <option value='0' >Sources Marcomm</option>
																			 <?php
																						 if (!empty($sourcesmarcomm)) {
																						 foreach ($sourcesmarcomm as $r) {
																				echo "<option value=".$r->id_subparameter.">".$r->nama_subparameter."</option>";
																						}
																				 }
																				?>
																		 </select>
															 </div>
													 </div></td>
													 <td>&nbsp;</td>
		
													 <td> <div class="form-group">
															 
															 <div class="col-md-5" style="width: 100%; ">
																	 <select class="form-control select2"  name='tidakprospek' id="tidakprospek" aria-placeholder="">
																			 <option value='0' >Tidak Prospek</option>
																			 <?php
																						 if (!empty($tidakprospek)) {
																						 foreach ($tidakprospek as $r) {
																				echo "<option value=".$r->id_subparameter.">".$r->nama_subparameter."</option>";
																						}
																				 }
																				?>
																		 </select>
															 </div>
													 </div></td>
													 <td>&nbsp;</td>
		
													 <td> <div class="form-group">
															 
															 <div class="col-md-5" style="width: 100%; ">
																	 <select class="form-control select2"  name='sosialmedia' id="sosialmedia" aria-placeholder="">
																			 <option value='0' >Sosial Media</option>
																			 <?php
																						 if (!empty($sosialmedia)) {
																						 foreach ($sosialmedia as $r) {
																				echo "<option value=".$r->id_subparameter.">".$r->nama_subparameter."</option>";
																						}
																				 }
																				?>
																		 </select>
															 </div>
													 </div></td>
													 <td>&nbsp;</td>
		
													 <td> <div class="form-group">
															 
															 <div class="col-md-5" style="width: 100%; ">
																	 <select class="form-control select2"  name='alasanpembatalan' id="alasanpembatalan" aria-placeholder="">
																			 <option value='0' >Alasan Pembatalan</option>
																			 <?php
																						 if (!empty($alasanpembatalan)) {
																						 foreach ($alasanpembatalan as $r) {
																				echo "<option value=".$r->id_subparameter.">".$r->nama_subparameter."</option>";
																						}
																				 }
																				?>
																		 </select>
															 </div>
													 </div></td>
													 <td>&nbsp;</td>
		
													 <td> <div class="form-group">
															 
															 <div class="col-md-5" style="width: 100%; ">
																	 <select class="form-control select2"  name='detailpembatalan' id="detailpembatalan" aria-placeholder="">
																			 <option value='0' >Detail Pembatalan</option>
																			 <?php
																						 if (!empty($detailpembatalan)) {
																						 foreach ($detailpembatalan as $r) {
																				echo "<option value=".$r->id_subparameter.">".$r->nama_subparameter."</option>";
																						}
																				 }
																				?>
																		 </select>
															 </div>
													 </div></td>
													 <td>&nbsp;</td>
		
													 <td> <div class="form-group">
															 
															 <div class="col-md-5" style="width: 100%; ">
																	 <select class="form-control select2" name='masagaransi' id="masagaransi" aria-placeholder="">
																			 <option value='0' >Masa Garansi</option>
																			 <?php
																						 if (!empty($masagaransi)) {
																						 foreach ($masagaransi as $r) {
																				echo "<option value=".$r->id_subparameter.">".$r->nama_subparameter."</option>";
																						}
																				 }
																				?>
																		 </select>
															 </div>
													 </div></td>
													 <td>&nbsp;</td>
													 
						
		
						
					</tr>
				 </table>
</div>


        </section>



        <section class="col-lg-12 connectedSortable">
          <div >
            <div class="box box-primary">
            <div class="box-header"><h3 class="box-title">KLASEMEN HA</h3>
            </div>
            <div class="box-body" style="overflow-x: auto;">
                <table  id="table" class="table table-striped table-bordered" cellspacing="0" width="100%">
                    <tr>
                      <th>Rank</th>
                      <th>HA Name</th>
                      <th>% Ach Sales</th>
                      <th>% Prospect of New Customer</th>
                      <th>% Conversion rate</th>
                    </tr>
                      <td>sfsdfsdf</td>
                      <td>sfsdfsdf</td>
                      <td>sfsdfsdf</td>
                      <td>sfsdfsdf</td>
                      <td>sfsdfsdf</td>
                    <tr>
                </table>
            </div>
          </div>
        </div>
        </section>

        <section class="col-lg-12 connectedSortable">
          <div>
            <div class="box box-primary">
            <div class="box-header"><h3 class="box-title">CUSTOMER JOURNEY</h3>
            </div>
            <div class="box-body" style="overflow-x: auto;">
                <table  id="table" class="table table-striped table-bordered" cellspacing="0" width="100%" >
                    <tr style="background-color:  #054896;">
                      <th rowspan="2"><font>KETERANGAN</font></th>
                      <th>START</th>
                      <th>BALAS</th>
                      <th>MINTA PRICE LIST</th>
                      <th>SITE VISIT</th>
                      <th>NEGO</th>
                      <th>BI CHECKING</th>
                      <th>CLOSING</th>
                    </tr>
										<tr style="background-color:  #054896;">
                      <td>Tahap 1</td>
                      <td>Tahap 2</td>
                      <td>Tahap 3</td>
                      <td>Tahap 4</td>
                      <td>Tahap 5</td>
                      <td>Tahap 6</td>
                      <td>Tahap 7</td>
											</tr>        
											<tr>
											<td>Total Leads</td>
                      <td></td>
                      <td></td>
                      <td></td>
                      <td></td>
                      <td></td>
                      <td></td>
                      <td></td>
											</tr>
											<tr>
											<td>Tidak Prospect</td>
											<td></td>
                      <td></td>
                      <td></td>
                      <td></td>
                      <td></td>
                      <td></td>
                      <td></td>
											</tr>
											<tr>
											<td>% Conversion Rate</td>
                      <td></td>
                      <td></td>
                      <td></td>
                      <td></td>
                      <td></td>
                      <td></td>
                      <td></td>
											</tr>
											<tr>
											<td>% Drop off Rate</td>
											<td></td>
                      <td></td>
                      <td></td>
                      <td></td>
                      <td></td>
                      <td></td>
                      <td></td>
											</tr>
                </table>
            </div>
          </div>
        </div>
        </section>

				<section class="col-lg-12 connectedSortable">
          <div >
            <div class="box box-primary">
            <div class="box-header"><h3 class="box-title">BUDGET</h3>
            </div>
            <div class="box-body" style="overflow-x: auto;">
                <table  id="table" class="table table-striped table-bordered" cellspacing="0" width="100%">
                    <tr>
                      <th></th>
                      <th colspan="4"><center>Desember 2022</center> </th>
											<th colspan="4"><center>Januari 2023</center> </th>
											<th colspan="4"><center>YTD 2022</center> </th>
                      
                    </tr>
										<tr style="background-color:  #10EAFA;">
										  <td>Category COA</td>
                      <td>Anggaran</td>
                      <td>Aktual</td>
                      <td>+/-</td>
                      <td>%</td>
                      <td>Anggaran</td>
                      <td>Aktual</td>
                      <td>+/-</td>
                      <td>%</td> 
											<td>Anggaran</td>
                      <td>Aktual</td>
                      <td>+/-</td>
                      <td>%</td>
										</tr>
										<tr>
										  <td>Biaya Advertising</td>
                      <td></td>
                      <td></td>
                      <td></td>
                      <td></td>
                      <td></td>
                      <td></td>
                      <td></td>
                      <td></td> 
											<td></td>
                      <td></td>
                      <td></td>
                      <td></td>
										</tr>
										<tr>
										  <td>Biaya Operasional Marketing</td>
                      <td></td>
                      <td></td>
                      <td></td>
                      <td></td>
                      <td></td>
                      <td></td>
                      <td></td>
                      <td></td> 
											<td></td>
                      <td></td>
                      <td></td>
                      <td></td>
										</tr>
										<tr>
										  <td>Biaya Penyusutan</td>
											<td></td>
                      <td></td>
                      <td></td>
                      <td></td>
                      <td></td>
                      <td></td>
                      <td></td>
                      <td></td> 
											<td></td>
                      <td></td>
                      <td></td>
                      <td></td>
										</tr>
										<tr>
										  <td>Biaya SDM Marketing</td>
                      <td></td>
                      <td></td>
                      <td></td>
                      <td></td>
                      <td></td>
                      <td></td>
                      <td></td>
                      <td></td> 
											<td></td>
                      <td></td>
                      <td></td>
                      <td></td>
										</tr>
										<tr>
										  <td>Aktiva Tetap</td>
                      <td></td>
                      <td></td>
                      <td></td>
                      <td></td>
                      <td></td>
                      <td></td>
                      <td></td>
                      <td></td> 
											<td></td>
                      <td></td>
                      <td></td>
                      <td></td>
										</tr>
										<tr>
										  <td>Grand Total</td>
                      <td></td>
                      <td></td>
                      <td></td>
                      <td></td>
                      <td></td>
                      <td></td>
                      <td></td>
                      <td></td> 
											<td></td>
                      <td></td>
                      <td></td>
                      <td></td>
										</tr>
									 </table>
            </div>
          </div>
        </div>

				<div class="panel panel-primary">
  <!-- Default panel contents -->
  <div class="panel-heading">BUDGET</div>
	<table  id="table" class="table table-striped table-bordered" cellspacing="0" width="100%">
                    <tr>
                      <th></th>
                      <th colspan="4"><center>Desember 2022</center> </th>
											<th colspan="4"><center>Januari 2023</center> </th>
											<th colspan="4"><center>YTD 2022</center> </th>
                      
                    </tr>
										<tr style="background-color:  #10EAFA;">
										  <td>Category COA</td>
                      <td>Anggaran</td>
                      <td>Aktual</td>
                      <td>+/-</td>
                      <td>%</td>
                      <td>Anggaran</td>
                      <td>Aktual</td>
                      <td>+/-</td>
                      <td>%</td> 
											<td>Anggaran</td>
                      <td>Aktual</td>
                      <td>+/-</td>
                      <td>%</td>
										</tr>
										<tr>
										  <td>Biaya Advertising</td>
                      <td></td>
                      <td></td>
                      <td></td>
                      <td></td>
                      <td></td>
                      <td></td>
                      <td></td>
                      <td></td> 
											<td></td>
                      <td></td>
                      <td></td>
                      <td></td>
										</tr>
										<tr>
										  <td>Biaya Operasional Marketing</td>
                      <td></td>
                      <td></td>
                      <td></td>
                      <td></td>
                      <td></td>
                      <td></td>
                      <td></td>
                      <td></td> 
											<td></td>
                      <td></td>
                      <td></td>
                      <td></td>
										</tr>
										<tr>
										  <td>Biaya Penyusutan</td>
											<td></td>
                      <td></td>
                      <td></td>
                      <td></td>
                      <td></td>
                      <td></td>
                      <td></td>
                      <td></td> 
											<td></td>
                      <td></td>
                      <td></td>
                      <td></td>
										</tr>
										<tr>
										  <td>Biaya SDM Marketing</td>
                      <td></td>
                      <td></td>
                      <td></td>
                      <td></td>
                      <td></td>
                      <td></td>
                      <td></td>
                      <td></td> 
											<td></td>
                      <td></td>
                      <td></td>
                      <td></td>
										</tr>
										<tr>
										  <td>Aktiva Tetap</td>
                      <td></td>
                      <td></td>
                      <td></td>
                      <td></td>
                      <td></td>
                      <td></td>
                      <td></td>
                      <td></td> 
											<td></td>
                      <td></td>
                      <td></td>
                      <td></td>
										</tr>
										<tr>
										  <td>Grand Total</td>
                      <td></td>
                      <td></td>
                      <td></td>
                      <td></td>
                      <td></td>
                      <td></td>
                      <td></td>
                      <td></td> 
											<td></td>
                      <td></td>
                      <td></td>
                      <td></td>
										</tr>
									 </table>
</div>

<div class="row">
  <div class="col-xs-6 col-md-3">
    <a href="#" class="thumbnail">
      <img src="..." alt="...">
    </a>
  </div>
	<div class="col-xs-6 col-md-3">
    <a href="#" class="thumbnail">
      <img src="..." alt="...">
    </a>
  </div>
	<div class="col-xs-6 col-md-3">
    <a href="#" class="thumbnail">
      <img src="..." alt="...">
    </a>
  </div>
	<div class="col-xs-6 col-md-3">
	<a href="<?php echo base_url('c_master/chartconversionratebymonth'); ?>"><div id='conversionratebymonth'></div></a>
  </div>
  ...
</div>
        </section>
    


     



   

       
                                    </form>
        

  </div>
  
  <!-- /.content-wrapper -->
  
<?php
$this->load->view('template/foot');
?> 

<!-- jQuery 2.2.3 -->
<script src="<?php echo base_url('assets/plugins/jQuery/jquery-2.2.3.min.js') ?>"></script>
<!-- Bootstrap 3.3.6 -->
<script src="<?php echo base_url('assets/bootstrap/js/bootstrap.min.js') ?>"></script>
<!-- DataTables -->
<script src="<?php echo base_url('assets/plugins/datatables/jquery.dataTables.min.js') ?>"></script>
<script src="<?php echo base_url('assets/plugins/datatables/dataTables.bootstrap.min.js') ?>"></script>
<!-- SlimScroll -->
<script src="<?php echo base_url('assets/plugins/slimScroll/jquery.slimscroll.min.js') ?>"></script>
<!-- FastClick -->
<script src="<?php echo base_url('assets/plugins/fastclick/fastclick.js') ?>"></script>
<!-- AdminLTE App -->
<script src="<?php echo base_url('assets/dist/js/app.min.js') ?>"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?php echo base_url('assets/dist/js/demo.js') ?>"></script>

<!-- page script -->
<script type="text/javascript">
var save_method; //for save method string
var table;
var base_url = '<?php echo base_url();?>';

$(document).ready(function() {

    //datatables
    table = $('#table').DataTable({ 

        "processing": true, //Feature control the processing indicator.
        "serverSide": true, //Feature control DataTables' server-side processing mode.
        "order": [], //Initial no order.

        // Load data for the table's content from an Ajax source
        "ajax": {
            "url": "<?php echo site_url('c_master/kpi/ajax_list_dashboard')?>",
            "type": "POST"
        },

        //Set column definition initialisation properties.
        "columnDefs": [
            { 
                "targets": [ -1 ], //last column
                "orderable": false, //set not orderable
            },
            { 
                "targets": [ -2 ], //2 last column (photo)
                "orderable": false, //set not orderable
            },
        ],

    });

});


</script>
<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
<html>
  <head>
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
      google.charts.load('current', {'packages':['corechart']});
      google.charts.setOnLoadCallback(drawVisualization);

      function drawVisualization() {
        // Some raw data (not necessarily accurate)
        var data = google.visualization.arrayToDataTable([
          ['Name','Target 1', 'Target 2', 'Realisasi', 'Ach Target 1','Ach Target 2'],
          ['Januari',  165,      938,         522,             998,           450],
          ['Februari',  135,      1120,        599,             1268,          288],
          ['Maret',  157,      1167,        587,             807,           39],
          ['April',  139,      1110,        615,             968,           215],
          ['Mei',  136,      691,         629,             1026,          366]
        ]);

        // var options = {
        //   title : 'Sales Acchievment',
        //   vAxis: {title: 'Millions'},
        //   hAxis: {title: 'Month'},
        //   seriesType: 'bars',
        //   series: {5: {type: 'line'}}
        // };
        var options = {
    title: 'Sales By Month',
    legend: { position: 'top', maxLines: 4 },
    seriesType: 'bars',
    series: {3: {type: 'line'},
             4: {type: 'line'}},
   
    colors: ['#ffa500', '#FFD900', '#1AAA26', '#26126D', '#1AAA26'],
    interpolateNulls: false,
        };

        var chart = new google.visualization.ComboChart(document.getElementById('salesbymonth'));
        chart.draw(data, options);
      }
    </script>

<script type="text/javascript">
      google.charts.load('current', {'packages':['corechart']});
      google.charts.setOnLoadCallback(drawVisualization);

      function drawVisualization() {
        // Some raw data (not necessarily accurate)
        var data = google.visualization.arrayToDataTable([
          ['Name','Target 1'],
          ['Januari',  165],
          ['Februari',  135],
          ['Maret',  157],
          ['April',  139],
          ['Mei',  136]
        ]);

        // var options = {
        //   title : 'Sales Acchievment',
        //   vAxis: {title: 'Millions'},
        //   hAxis: {title: 'Month'},
        //   seriesType: 'bars',
        //   series: {5: {type: 'line'}}
        // };
        var options = {
    title: 'Lead By Month',
  //  legend: { position: 'top', maxLines: 4 },
    seriesType: 'bars',
    // series: {3: {type: 'line'},
    //          4: {type: 'line'}},
   
  //  colors: ['#ffa500', '#FFD900', '#1AAA26', '#26126D', '#1AAA26'],
    interpolateNulls: false,
        };

        var chart = new google.visualization.ComboChart(document.getElementById('leadbymonth'));
        chart.draw(data, options);
      }
    </script>

<script type="text/javascript">
      google.charts.load('current', {'packages':['corechart']});
      google.charts.setOnLoadCallback(drawVisualization);

      function drawVisualization() {
        // Some raw data (not necessarily accurate)
        var data = google.visualization.arrayToDataTable([
          ['Name','Target 1'],
          ['Januari',  209],
          ['Februari',  222],
          ['Maret',  126],
          ['April',  139],
          ['Mei',  136]
        ]);

        // var options = {
        //   title : 'Sales Acchievment',
        //   vAxis: {title: 'Millions'},
        //   hAxis: {title: 'Month'},
        //   seriesType: 'bars',
        //   series: {5: {type: 'line'}}
        // };
        var options = {
    title: 'CONVERSION RATE BY MONTH',
   // legend: { position: 'top', maxLines: 4 },
    seriesType: 'bars',
    // series: {3: {type: 'line'},
    //          4: {type: 'line'}},
   
    colors: ['#ffa500', '#FFD900', '#1AAA26', '#26126D', '#1AAA26'],
    interpolateNulls: false,
        };

        var chart = new google.visualization.ComboChart(document.getElementById('conversionratebymonth'));
        chart.draw(data, options);
      }
    </script>

<script type="text/javascript">
      google.charts.load('current', {'packages':['corechart']});
      google.charts.setOnLoadCallback(drawVisualization);

      function drawVisualization() {
        // Some raw data (not necessarily accurate)
        var data = google.visualization.arrayToDataTable([
          ['Name','Target 1', 'Target 2', 'Realisasi', 'Ach Target 1','Ach Target 2'],
          ['Januari',  165,      938,         522,             998,           450],
          ['Februari',  135,      1120,        599,             1268,          288],
          ['Maret',  157,      1167,        587,             807,           39],
          ['April',  139,      1110,        615,             968,           215],
          ['Mei',  136,      691,         629,             1026,          366]
        ]);

        // var options = {
        //   title : 'Sales Acchievment',
        //   vAxis: {title: 'Millions'},
        //   hAxis: {title: 'Month'},
        //   seriesType: 'bars',
        //   series: {5: {type: 'line'}}
        // };
        var options = {
    title: 'Lead By HA',
    legend: { position: 'top', maxLines: 4 },
    seriesType: 'bars',
    series: {3: {type: 'line'},
             4: {type: 'line'}},
   
    colors: ['#ffa500', '#FFD900', '#1AAA26', '#26126D', '#1AAA26'],
    interpolateNulls: false,
        };

        var chart = new google.visualization.ComboChart(document.getElementById('leadbyHA'));
        chart.draw(data, options);
      }
    </script>

<script type="text/javascript">
      google.charts.load('current', {'packages':['corechart']});
      google.charts.setOnLoadCallback(drawVisualization);

      function drawVisualization() {
        // Some raw data (not necessarily accurate)
        var data = google.visualization.arrayToDataTable([
          ['Name','Target 1', 'Target 2', 'Realisasi', 'Ach Target 1','Ach Target 2'],
          ['Januari',  165,      938,         522,             998,           450],
          ['Februari',  135,      1120,        599,             1268,          288],
          ['Maret',  157,      1167,        587,             807,           39],
          ['April',  139,      1110,        615,             968,           215],
          ['Mei',  136,      691,         629,             1026,          366]
        ]);

        // var options = {
        //   title : 'Sales Acchievment',
        //   vAxis: {title: 'Millions'},
        //   hAxis: {title: 'Month'},
        //   seriesType: 'bars',
        //   series: {5: {type: 'line'}}
        // };
        var options = {
    title: 'Sales By HA',
    legend: { position: 'top', maxLines: 4 },
    seriesType: 'bars',
    series: {3: {type: 'line'},
             4: {type: 'line'}},
   
    colors: ['#ffa500', '#FFD900', '#1AAA26', '#26126D', '#1AAA26'],
    interpolateNulls: false,
        };

        var chart = new google.visualization.ComboChart(document.getElementById('salesbyHA'));
        chart.draw(data, options);
      }
    </script>

<script type="text/javascript">
      google.charts.load('current', {'packages':['corechart']});
      google.charts.setOnLoadCallback(drawVisualization);

      function drawVisualization() {
        // Some raw data (not necessarily accurate)
        var data = google.visualization.arrayToDataTable([
          ['Name','Target 1', 'Target 2', 'Realisasi', 'Ach Target 1','Ach Target 2'],
          ['Januari',  165,      938,         522,             998,           450],
          ['Februari',  135,      1120,        599,             1268,          288],
          ['Maret',  157,      1167,        587,             807,           39],
          ['April',  139,      1110,        615,             968,           215],
          ['Mei',  136,      691,         629,             1026,          366]
        ]);

        // var options = {
        //   title : 'Sales Acchievment',
        //   vAxis: {title: 'Millions'},
        //   hAxis: {title: 'Month'},
        //   seriesType: 'bars',
        //   series: {5: {type: 'line'}}
        // };
        var options = {
    title: 'CONVERSION RATE BY HA',
    legend: { position: 'top', maxLines: 4 },
    seriesType: 'bars',
    series: {3: {type: 'line'},
             4: {type: 'line'}},
   
    colors: ['#ffa500', '#FFD900', '#1AAA26', '#26126D', '#1AAA26'],
    interpolateNulls: false,
        };

        var chart = new google.visualization.ComboChart(document.getElementById('conversionratebyHA'));
        chart.draw(data, options);
      }
    </script>

     <script type="text/javascript">
     google.charts.load("current", {packages:["corechart"]});
     google.charts.setOnLoadCallback(drawChart);
     function drawChart() {
       var data = google.visualization.arrayToDataTable([
         ['Age', 'Weight'],
         [ 8,      12],
         [ 4,      5.5],
         [ 11,     14],
         [ 4,      5],
         [ 3,      3.5],
         [ 6.5,    7]
       ]);

       var options = {
         title: 'Sales Trend',
         legend: 'none',
         crosshair: { trigger: 'both', orientation: 'both' },
         trendlines: {
           0: {
             type: 'polynomial',
             degree: 3,
             visibleInLegend: true,
           }
         }
       };

       var chart = new google.visualization.ScatterChart(document.getElementById('polynomial2_div'));
       chart.draw(data, options);
     }
   </script>
    <script type="text/javascript">
      google.charts.load("current", {packages:["corechart"]});
      google.charts.setOnLoadCallback(drawChart);
      function drawChart() {
        var data = google.visualization.arrayToDataTable([
          ['Task', 'Hours per Day'],
          ['Bhuvana',     11],
          ['Aswana',      2],
          ['Sadana',  2]
         
        ]);

        var options = {
          title: 'Sales Contribution',
          is3D: true,
        };

        var chart = new google.visualization.PieChart(document.getElementById('piechart_3d'));
        chart.draw(data, options);
      }
    </script>
     <script type="text/javascript">
      google.charts.load("current", {packages:["corechart"]});
      google.charts.setOnLoadCallback(drawChart);
      function drawChart() {
        var data = google.visualization.arrayToDataTable([
          ['Task', 'Hours per Day'],
          ['< 30 Hari',     11],
          ['30 - 60 Hari',      2],
          ['60 - 90 hari',  2],
          ['> 90 Hari', 2]
        ]);

        var options = {
          title: 'Inventory Turn Over Warning Rate',
          is3D: true,
        };

        var chart = new google.visualization.PieChart(document.getElementById('piechart_3d2'));
        chart.draw(data, options);
      }
    </script>
     <!-- <script type="text/javascript">
      google.charts.load('current', {'packages':['bar']});
      google.charts.setOnLoadCallback(drawChart);

      function drawChart() {
        var data = google.visualization.arrayToDataTable([
          ['Year', 'Sales', 'Expenses', 'Profit'],
          ['2014', 1000, 400, 200],
          ['2015', 1170, 460, 250],
          ['2016', 660, 1120, 300],
          ['2017', 1030, 540, 350]
        ]);

        var options = {
          chart: {
            title: 'Prospect of New Customer',
            legend: { position: 'top', maxLines: 4 },
          }
        };

        var chart = new google.charts.Bar(document.getElementById('columnchart_material'));

        chart.draw(data, google.charts.Bar.convertOptions(options));
      }
    </script> -->
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
      google.charts.load('current', {'packages':['corechart']});
      google.charts.setOnLoadCallback(drawVisualization);

      function drawVisualization() {
        // Some raw data (not necessarily accurate)
        var data = google.visualization.arrayToDataTable([
          ['Name','Drop Off', 'Prospect', 'On Progress'],
          ['Canvasing',  165,      938,         522],
          ['Data Marcom',  135,      1120,        599],
          ['Maret',  157,      1167,        587],
          ['April',  139,      1110,        615],
          ['Mei',  136,      691,         629]
        ]);

        // var options = {
        //   title : 'Sales Acchievment',
        //   vAxis: {title: 'Millions'},
        //   hAxis: {title: 'Month'},
        //   seriesType: 'bars',
        //   series: {5: {type: 'line'}}
        // };
        var options = {
    title: 'Prospect Of New Customer',
    legend: { position: 'bottom', maxLines: 4 },
    seriesType: 'bars',
   
    colors: ['#C90404', '#FF9900', '#F5E612'],
    interpolateNulls: false,
        };

        var chart = new google.visualization.ComboChart(document.getElementById('columnchart_material'));
        chart.draw(data, options);
      }
    </script>
     

<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
      google.charts.load('current', {'packages':['corechart']});
      google.charts.setOnLoadCallback(drawVisualization);

      function drawVisualization() {
        // Some raw data (not necessarily accurate)
        var data = google.visualization.arrayToDataTable([
          ['Name','Lead', 'Closing', 'Convertion Rate'],
          ['Januari',  165,      938,         522],
          ['Februari',  135,      1120,        599],
          ['Maret',  157,      1167,        587],
          ['April',  139,      1110,        615],
          ['Mei',  136,      691,         629]
        ]);

        // var options = {
        //   title : 'Sales Acchievment',
        //   vAxis: {title: 'Millions'},
        //   hAxis: {title: 'Month'},
        //   seriesType: 'bars',
        //   series: {5: {type: 'line'}}
        // };
        var options = {
    title: 'Convertion Rate',
    legend: { position: 'top', maxLines: 4 },
    seriesType: 'bars',
    series: {2: {type: 'line'}},
   
    colors: ['#ffa500', '#FFD900', '#1AAA26', '#26126D', '#1AAA26'],
    interpolateNulls: false,
        };

        var chart = new google.visualization.ComboChart(document.getElementById('columnchart_material2'));
        chart.draw(data, options);
      }
    </script>
  </head>
  <body>
   
  </body>
</html>
</body>
</html>
