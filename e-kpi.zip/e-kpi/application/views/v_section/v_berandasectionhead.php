<?php
$this->load->view('template/head');
$this->load->view('template/topbar');
$this->load->view('template/sidebar_section');
?>

  
  <!-- Content Wrapper. Contains page content -->    
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Beranda Officer
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Beranda</li>
      </ol>
    </section>
    

    <section class="content">
        <form class="form-horizontal" action="<?php echo site_url('c_section/berandasectionhead');?>" method="post"  id="form_id">
      
        <div class="col-xs-12">
            <div class="box box-primary">
            <div class="box-header">
             
              <div class="panel-footer" style="border-radius: 5px; width: 100%; border: 4px;">
      <div class="row">
        <div class="col-xs-6">
            <span style="font-size: 12pt; font-weight: bold">DARI</span>
            <div class="form-group">
                                <label class="control-label col-md-3">Bulan</label>
                                <div class="col-md-5">
                                <select class="form-control select2" style="width: 100%;" name='id_bulanFrom' id="id_bulanFrom">
                                    <option value='0' le>Pilih Bulan</option>
                                    <?php
                                    
                                         if (!empty($bulan)) {
                                         foreach ($bulan as $r) {
                                    echo '<option value="'.$r->id_bulan.'">'.$r->nama_bulan.'</option>';
                                        }
                                     }
                                    ?>
                                  </select> 
                                </div>
                        </div>
                        <div class="form-group">
                                <label class="control-label col-md-3">Tahun</label>
                                <div class="col-md-5">
                                  <select class="form-control select2" style="width: 100%;" name='id_tahunFrom' id="id_tahunFrom">
                                    <option value='0' le>Pilih Tahun</option>
                                    <?php
                                    
                                         if (!empty($tahun)) {
                                         foreach ($tahun as $r) {
                                    echo '<option value="'.$r->id_tahun.'">'.$r->nama_tahun.'</option>';
                                        }
                                     }
                                    ?>
                                  </select> 
                                </div>
                        </div>
            <br><br>
        
        </div>
            <div class="col-xs-6">
                <span style="font-size: 12pt; font-weight: bold">SAMPAI</span>
                <div class="form-group">
                                <label class="control-label col-md-3">Bulan</label>
                                <div class="col-md-5">
                                <select class="form-control select2" style="width: 100%;" name='id_bulanTo' id="id_bulanTo">
                                    <option value='0' le>Pilih Bulan</option>
                                    <?php
                                    
                                         if (!empty($bulan)) {
                                         foreach ($bulan as $r) {
                                    echo '<option value="'.$r->id_bulan.'">'.$r->nama_bulan.'</option>';
                                        }
                                     }
                                    ?>
                                  </select> 
                                </div>
                        </div>
                        <div class="form-group">
                                <label class="control-label col-md-3">Tahun</label>
                                <div class="col-md-5">
                                  <select class="form-control select2" style="width: 100%;" name='id_tahunTo' id="id_tahunTo">
                                    <option value='0' le>Pilih Tahun</option>
                                    <?php
                                    
                                         if (!empty($tahun)) {
                                         foreach ($tahun as $r) {
                                    echo '<option value="'.$r->id_tahun.'">'.$r->nama_tahun.'</option>';
                                        }
                                     }
                                    ?>
                                  </select> 
                                </div>
                        </div>
        </div>
      </div>
        <button id="submit" class="btn btn-info" >Lihat</button>
      </div>
     
            </div>
          </div>
        </div>

        <div class="col-xs-6">
            <div class="box box-primary">
            <div class="box-header">
              <i class="ion ion-person-stalker"></i>

              <h3 class="box-title">Departement Head</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body" style="overflow-x: auto;">
            <table style="width: 100%;">
    <tr >
      <td colspan="6"> <h4 style="font-weight: bold; text-align: center;">
            <?php
              foreach ($departemen as $row) {
                 echo "$row->nama_departemen";
             }
             ?>
             </h4>&nbsp;</td>
      
      <!-- <td>b</td>
      <td>c</td> -->
    </tr>
    <tr >
      <td colspan="6"><center>
      <div class="small-box bg-green" style="width: 100px; border-radius: 30px;">
            <div class="inner">
            <p style="font-weight: bold; text-align: center;">Rock Star</p>
            </div>
          </div>
          </center>
      </td>
      
      <!-- <td>b</td>
      /* 
      if else if else if else if else if else if else if else if else if else2
      */
      <td>c</td> -->
    </tr>
    <tr >
      <td>
        <div>
          <!-- small box -->
          <div class="small-box bg-green">
            <div class="inner">
            <p style="font-weight: bold; text-align: center;">Rock Star</p>
              <h4 style="font-weight: bold; text-align: center;">5</h4> 
            </div>
          </div>
        </div>
      </td>
      <td>&nbsp;</td>
      <td>
        <div>
          <!-- small box -->
          <div class="small-box bg-orange">
            <div class="inner">
            <p style="font-weight: bold; text-align: center;">Adequate</p>
              <h4 style="font-weight: bold; text-align: center;">5</h4>
            </div>
          </div>
        </div>
      </td>
      <td>&nbsp;</td>
      <td>
      <div >
          <!-- small box -->
          <div class="small-box bg-red">
            <div class="inner">
            <p style="font-weight: bold; text-align: center;">Need Helps</p>
              <h4 style="font-weight: bold; text-align: center;">5</h4>
            </div>
          </div>
        </div>
      </td>
    </tr>
    <tr>
      <td colspan="6">
      <table id="table" class="table table-striped table-bordered" cellspacing="0" width="100%">
                <thead>
                  <tr>
                    <th>Images</th>
                    <!-- <th>Jabatan</th> -->
                    <th>Nilai</th>
                    <th>Action</th>
                    
                  </tr>
                </thead>
                <tbody>
                </tbody>
              </table>
      </td>
    </tr>
   
    </table>
            </div>
          </div>
        </div>
      

      <div class="col-xs-6">
            <div class="box box-primary">
            <div class="box-header">
      <div> <i class="ion ion-stats-bars"></i>

<h3 class="box-title">KPI Perbulan</h3></div>
            </div>
            <canvas id="myChart"></canvas>
          </div>
          
        </div>
        
        

        <div class="col-xs-6">
            <div class="box box-primary">
            <div class="box-header">
              <table style="width: 100%;">
                <tr>
                  <td> <i class="ion ion-levels"></i><h3 class="box-title">KPI</h3></td>
                 
                </tr>
              </table>
              
            </div>
            <!-- /.box-header -->
            <div class="box-body" style="overflow-x: auto;">
         
              <table  id="table" class="table table-striped table-bordered" cellspacing="0" width="100%">
		<tr>
			<th>Avg. Score</th>
			<th>Result Areas</th>
			<th>Review</th>
		</tr>
		<?php 
		foreach($kpi as $u){ 
		?>
		<tr>
			<td><?php echo number_format($u->nilai,1,",",".");?></td>
			<td><?php echo $u->nama_kpi ?></td>
			<td>
      <?php
      if($u->nilai > 2){
			echo '<center>
			<a class="btn btn-sm btn-success" href="" title="Rock Star">
			Rock Star
			</a></center>';
			}else if($u->nilai== 2){
        echo '<center>
        <a class="btn btn-sm btn-warning" href="" title="Adequate">
        Adequate
        </a></center>';
			}else {
        echo '<center>
        <a class="btn btn-sm btn-danger" href="" title="Need Helps">
        Need Helps
        </a></center>';
			}
      ?>
        
      </td>
		
		</tr>
		<?php } ?>
	</table>
            </div>
          </div>
            <!-- /.box-body -->
        </div>
        <!-- /.col -->
      
      </form>

    </section>

    <!-- Main content -->   
    <section class="content" style="height: 100%;" >
      <br><br>
      <!-- Main row -->
      <div class="row">
 


       
        
        
        <!-- /.Left col -->
        <!-- right col (We are only adding the ID to make the widgets sortable)-->
      </div>
      <!-- /.row (main row)  -->

    </section>
    
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  
<?php
$this->load->view('template/foot');
?> 

<?php
    //Inisialisasi nilai variabel awal
    $namakpi= "";
    $nilai=null;
    foreach ($kpi as $item)
    {
        $nk=$item->nama_kpi;
        $namakpi .= "'$nk'". ", ";
        $ni=$item->nilai;
        $nilai .= "$ni". ", ";
    }
    ?>
<!-- jQuery 2.2.3 -->
<!-- jQuery 2.2.3 -->
<script src="<?php echo base_url('assets/plugins/jQuery/jquery-2.2.3.min.js') ?>"></script>
<!-- Bootstrap 3.3.6 -->
<script src="<?php echo base_url('assets/bootstrap/js/bootstrap.min.js') ?>"></script>
<!-- DataTables -->
<script src="<?php echo base_url('assets/plugins/datatables/jquery.dataTables.min.js') ?>"></script>
<script src="<?php echo base_url('assets/plugins/datatables/dataTables.bootstrap.min.js') ?>"></script>
<!-- SlimScroll -->
<script src="<?php echo base_url('assets/plugins/slimScroll/jquery.slimscroll.min.js') ?>"></script>
<!-- FastClick -->
<script src="<?php echo base_url('assets/plugins/fastclick/fastclick.js') ?>"></script>
<!-- AdminLTE App -->
<script src="<?php echo base_url('assets/dist/js/app.min.js') ?>"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?php echo base_url('assets/dist/js/demo.js') ?>"></script>
<!-- Chartjs -->
<script src="<?php echo base_url('assets/plugins/chartjs/chart.js') ?>"></script>

<!-- page script -->
<script type="text/javascript">
var save_method; //for save method string 
var table;
var base_url = '<?php echo base_url();?>';

$(document).ready(function() {

    //datatables
    table = $('#table').DataTable({ 

        "processing": true, //Feature control the processing indicator.
        "serverSide": true, //Feature control DataTables' server-side processing mode.
        "order": [], //Initial no order.     

        // Load data for the table's content from an Ajax source
        "ajax": {
            "url": "<?php echo site_url('c_section/berandasectionhead/ajax_list')?>",
            "type": "POST"
        },

        //Set column definition initialisation properties.
        "columnDefs": [
            { 
                "targets": [ -1 ], //last column
                "orderable": false, //set not orderable
            },
            { 
                "targets": [ -2 ], //2 last column (photo)
                "orderable": false, //set not orderable
            },
        ],

    });

});


</script>
<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
<html>
  <head>
<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
<script type="text/javascript">
      google.charts.load('current', {'packages':['corechart']});
      google.charts.setOnLoadCallback(drawVisualization);

      function drawVisualization() {
        // Some raw data (not necessarily accurate)
        var data = google.visualization.arrayToDataTable([
          ['Bulan','Realisasi',],
          //['Januari',  5],
          
          <?php
              foreach ($realisasi as $row) {
                 echo "['$row->nama_bulan',$row->nilai],";
             }
            
             ?>
         
          
        ]);

       
      

        // var options = {
        //   title : 'Sales Acchievment',
        //   vAxis: {title: 'Millions'},
        //   hAxis: {title: 'Month'},
        //   seriesType: 'bars',
        //   series: {5: {type: 'line'}}
        // };
        var options = {
    title: '',
    legend: { position: 'top', maxLines: 2},
    seriesType: 'bars',
    // series: {3: {type: 'line'},
    //          4: {type: 'line'}},
   
    colors: ['#C01212', '#FFD900', '#1AAA26'],
    interpolateNulls: false,
        };

        var chart = new google.visualization.ComboChart(document.getElementById('chart_div2'));
        chart.draw(data, options);
      }
    </script>
    <script type="text/javascript">
  document.getElementById('id_bulanFrom').onchange = function () {
  localStorage.setItem('id_bulanFrom', this.value);
};
</script>
<script>
    var ctx = document.getElementById('myChart').getContext('2d');
    var chart = new Chart(ctx, {
        // The type of chart we want to create
        type: 'bar',
        // The data for our dataset
        data: {
            labels: [<?php echo $namakpi; ?>],
            datasets: [{
                label:'Nilai ',
                backgroundColor: ['rgb(255, 99, 132)', 'rgba(56, 86, 255, 0.87)', 'rgb(60, 179, 113)','rgb(175, 238, 239)'],
                borderColor: ['rgb(255, 99, 132)'],
                data: [<?php echo $nilai; ?>]
            }]
        },
        // Configuration options go here
        options: {
            scales: {
                yAxes: [{
                    ticks: {
                        beginAtZero:true
                    }
                }]
            }
        }
    });
</script>

<script type="text/javascript">

        $("#periode").change(function(){
                var periode = {periode:$("#periode").val()};
                $.ajax({
                        method: "POST",
                        url : '<?php echo site_url('c_officer/berandaofficer');?>',
                        data: periode,
                        success: function(data){
                        //  $('#periode2').html(data);
                      //  alert("Data: " +data );
                            

                        }

                    });

        });

       </script>



</body>
</html>