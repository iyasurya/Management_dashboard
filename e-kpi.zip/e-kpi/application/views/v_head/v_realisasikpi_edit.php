<?php 
$this->load->view('template/head');
$this->load->view('template/topbar_fourth');
$this->load->view('template/sidebar_head_second');
?>


<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Realisasi KPI
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Input KPI</a></li>
        <li class="active">Data Realisasi KPI</li>
      </ol>
    </section>
    
    <br>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box box-success">
            
            <div class="modal-body form">
                <form class="form-horizontal" action="<?php echo site_url('c_head/realisasikpi/update');?>" method="post">
                    <div class="form-body">
                    <input type="hidden"  name="id" id="id" value="<?php echo $record['id'] ?>">
                        <div class="form-group" hidden>
                            <label class="control-label col-md-3">ID Realisasi</label>
                            <div class="col-md-5">
                                <input name="id_realisasi" id='id_realisasi' placeholder="ID Realisasi" class="form-control" type="text" required value="<?php echo  $record['id_realisasi']?>" >
                                <span class="help-block"></span>
                            </div>
                        </div>

                         <div class="form-group">
                                <label class="control-label col-md-3">Karyawan</label>
                                <div class="col-md-5">
                                  <select class="form-control select2" style="width: 100%;" name='id_karyawan' id="id_karyawan" disabled>
                                    <option value='0'>Pilih Karyawan</option>
                                    <?php
                                         if (!empty($karyawan)) {
                                            foreach ($karyawan as $r) {
                                              echo "<option value='$r->id_karyawan'";
                                              echo $record['id_karyawan'] == $r->id_karyawan ? 'selected' : '';
                                              echo">$r->nama_karyawan</option>";
                                            }
                                        }  
                                    ?>
                                  </select>
                                </div>
                        </div>
                        <div class="form-group" hidden>
                                <label class="control-label col-md-3">Kategori</label>
                                <div class="col-md-5">
                                  <select class="form-control select2" style="width: 100%;" name='id_kategori' id="id_kategori">
                                    <option value='0'>Pilih Kategori</option>
                                    <?php
                                         if (!empty($kategori)) {
                                            foreach ($kategori as $r) {
                                              echo "<option value='$r->id_kategori'";
                                              echo $record['id_kategori'] == $r->id_kategori ? 'selected' : '';
                                              echo">$r->nama_kategori</option>";
                                            }
                                        }  
                                    ?>
                                  </select>
                                </div>
                        </div>
                        <div class="form-group">
                                <label class="control-label col-md-3">Bulan</label>
                                <div class="col-md-5">
                                  <select class="form-control select2" style="width: 100%;" name='id_bulan' id="id_bulan" disabled>
                                    <option value='0'>Pilih Bulan</option>
                                    <?php
                                         if (!empty($bulan)) {
                                            foreach ($bulan as $r) {
                                              echo "<option value='$r->id_bulan'";
                                              echo $record['id_bulan'] == $r->id_bulan ? 'selected' : '';
                                              echo">$r->nama_bulan</option>";
                                            }
                                        }  
                                    ?>
                                  </select>
                                </div>
                        </div>
                        <div class="form-group">
                                <label class="control-label col-md-3">Tahun</label>
                                <div class="col-md-5">
                                  <select class="form-control select2" style="width: 100%;" name='id_tahun' id="id_tahun" disabled>
                                    <option value='0'>Pilih Tahun</option>
                                    <?php
                                         if (!empty($tahun)) {
                                            foreach ($tahun as $r) {
                                              echo "<option value='$r->id_tahun'";
                                              echo $record['id_tahun'] == $r->id_tahun ? 'selected' : '';
                                              echo">$r->nama_tahun</option>";
                                            }
                                        }  
                                    ?>
                                  </select>
                                </div>
                        </div>
                        <div class="form-group" hidden>
                                <label class="control-label col-md-3">Supervisor</label>
                                <div class="col-md-5">
                                  <select class="form-control select2" style="width: 100%;" name='id_supervisor' id="id_supervisor">
                                    <option value='0'>Pilih Supervisor</option>
                                    <?php
                                         if (!empty($karyawan)) {
                                            foreach ($karyawan as $r) {
                                              echo "<option value='$r->id_karyawan'";
                                              echo $record['id_karyawan'] == $r->id_karyawan ? 'selected' : '';
                                              echo">$r->nama_karyawan</option>";
                                            }
                                        }  
                                    ?>
                                  </select>
                                </div>
                        </div>

                        
                       
                        <div class="form-group" hidden>
                            <label class="control-label col-md-3">Skor Akhir</label>
                            <div class="col-md-5">
                                <input name="skor_akhir" id='skor_akhir' placeholder="Skor Akhir" class="form-control" type="text" required value="<?php echo  $record['skor_akhir']?>">
                                <span class="help-block"></span>
                            </div>
                        </div>
                        <div class="form-group" hidden>
                            <label class="control-label col-md-3">Status</label>
                            <div class="col-md-5">
                                <select class="form-control" name="enableflag" id='enableflag' style="width: 240px">
                                    <option value="0" <?php if($record['enableflag']=="0") echo 'selected="selected"'; ?> >Aktif</option>
                                    <option value="1" <?php if($record['enableflag']=="1") echo 'selected="selected"'; ?> >Tidak Aktif</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <br>
                    <table id="table" class="table table-striped table-bordered" cellspacing="0" width="100%">
                        <thead>
                              <tr>
                                <th><center>Nama KPI</center></th>
                                <th style="width:100px;"><center>KPI Objectif</center></th>
                                <th style="width:100px;"><center>KPI Waktu</center></th>
                                <th style="width:100px;"><center>KPI</center></th>
                                <th style="width:150px;"><center>Action</center></th>
                            </tr>
                        </thead>
                        <tbody>
                         <?php foreach($detail as $detail):?>

                             <tr class="gradeX">
                               <td><?php echo $detail->nama_kpi;?></td>
                               <td style="width:100px;"><?php echo $detail->obj;?></td>
                               <td style="width:100px;"><?php echo $detail->waktu;?></td>
                               <td style="width:100px;"><?php echo $detail->realisasi;?></td>
                               <td style="width:150px;">
                                <center><a href="#" class="delbuttonDetail" kode="<?php echo $detail->id;?>"><i class="glyphicon glyphicon-trash"></i></a></center>
                            </td>

                            <?php
                        endforeach;
                        ?>
                        </tbody>
                    </table>
                    <br>
                    <table id="table" class="table table-striped table-bordered" cellspacing="0" width="100%">
                    
                    <tbody>
                        <tr>
                            <th>
                            <select class="form-control select2" style="width: 100%;" name='nama_kpi2' id="nama_kpi2" onchange="isi();">
                                    <option value='0'>Pilih KPI</option>
                                    <?php
                                         if (!empty($kpi)) {
                                         foreach ($kpi as $r) {
                                          echo '<option value="'.$r->nama_kpi.'">'.$r->nama_kpi.'</option>';
                                        }
                                     }
                                    ?>
                                  </select> 
                                  <input type="text" id="nama_kpi" name="nama_kpi" style="width: 100%; text-align: center;" hidden>
                            </th>
                            <th style="width:100px;"><input type="text" id="obj" name="obj" style="width: 100%; text-align: center;" onkeyup="sum();"></th>
                            <th style="width:100px;"><input type="text" id="waktu" name="waktu" style="width: 100%; text-align: center;" onkeyup="sum();"></th>
                            <th style="width:100px;"><input id="realisasi" type="text" name="realisasi" style="width: 100%; text-align: center;"  disabled></th>
                            <th style="width:150px;"><center><button id="addkpi" class="btn btn-sm btn-success"><i class="glyphicon glyphicon-plus"></i></button></center></th>
                        </tr>
                    </tbody>
                </table>

                <div id="viewKPI"></div>
                </form>
            </div>

            <div class="panel-footer">
                <button id="update" class="btn btn-info">Update</button>
                <a href="<?php echo site_url('c_head/realisasikpi'); ?>" class="btn btn-danger">Batal</a>
            </div>

            </div>
            <!-- /.box-body -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

<?php 
$this->load->view('template/foot');
?> 

<!-- jQuery 2.2.3 -->
<script src="<?php echo base_url('assets/plugins/jQuery/jquery-2.2.3.min.js') ?>"></script>
<!-- Bootstrap 3.3.6 -->
<script src="<?php echo base_url('assets/bootstrap/js/bootstrap.min.js') ?>"></script>
<!-- Select2 -->
<script src="<?php echo base_url('assets/plugins/select2/select2.full.min.js') ?>"></script>
<!-- DataTables -->
<script src="<?php echo base_url('assets/plugins/datatables/jquery.dataTables.min.js') ?>"></script>
<script src="<?php echo base_url('assets/plugins/datatables/dataTables.bootstrap.min.js') ?>"></script>
<!-- SlimScroll -->
<script src="<?php echo base_url('assets/plugins/slimScroll/jquery.slimscroll.min.js') ?>"></script>
<!-- FastClick -->
<script src="<?php echo base_url('assets/plugins/fastclick/fastclick.js') ?>"></script>
<!-- AdminLTE App -->
<script src="<?php echo base_url('assets/dist/js/app.min.js') ?>"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?php echo base_url('assets/dist/js/demo.js') ?>"></script>

<script type="text/javascript" src="<?=base_url();?>/assets/autocomplete/js/jquery-ui.js"></script>
<link rel="stylesheet" href="<?=base_url();?>/assets/autocomplete/css/jquery-autocomplete.css">

<script>

    $(function () {
        //Initialize Select2 Elements
        $(".select2").select2();

    });

    $(function(){
            $("#nama_kpi").autocomplete({
      source: "<?php echo site_url('c_head/realisasikpi/getKPI');?>" // path to the get_birds method
    });
    });

    function loadDataTemp(args) {
      //code
      $("#viewKPI").load("<?php echo site_url('c_head/realisasikpi/viewKPI');?>");
      $('#addkpi').attr('disabled',false); //set button enable
    } 

    function nullNamakpi(args) {
      //code
      $("#nama_kpi").val('');
      $("#obj").val('');
      $("#waktu").val('');
      $("#realisasi").val('');
    }

    $("#addkpi").click(function(){
      var nama_kpi=$("#nama_kpi").val();
      var obj=$("#obj").val();
      var waktu=$("#waktu").val();
      var realisasi=$("#realisasi").val();

      if (nama_kpi=="") {
      //code
      alert("Nama KPI Harus Diisi");
      return false;
      }else if (realisasi=="") {
      //code
      alert("Realisasi Harus Diisi");
      return false;
        }else{
          $('#addkpi').attr('disabled',true); //set button disable 
          $.ajax({
            url:"<?php echo site_url('c_head/realisasikpi/addKpi');?>",
            type:"POST",
            data:"nama_kpi="+nama_kpi+"&obj="+obj+"&waktu="+waktu+"&realisasi="+realisasi,
            cache:false,
            success:function(html){
              loadDataTemp();
              nullNamakpi();
              $('#nama_kpi').focus();
              $('#obj').focus();
              $('#waktu').focus();
              $('#realisasi').focus();
          },
          error:function (jqXHR, textStatus, errorThrown)
          {
            $('#addkpi').attr('disabled',false); //set button disable 
        }
      })    
     }
    })

//     $("#sum").on("keyup", function(){
//     var obj = $("#obj").val();
//     var  = $("#waktu").val();
//     var realisasi= parseInt($("#realisasi").val());

//     $("#test").text("Balance -"+qty*balance); //you can change the id to place result whereever you want
// });

      function sum() {
           var txtFirstNumberValue = document.getElementById('obj').value;
           var txtSecondNumberValue = document.getElementById('waktu').value;
           var result = (parseInt(txtFirstNumberValue) + parseInt(txtSecondNumberValue)) / 2;
           if (!isNaN(result)) {
               document.getElementById('realisasi').value = result;
           }
       }

       function isi() {
       
       var txtFirst = document.getElementById('nama_kpi2').value;
    //   console.log(txtFirst);
    //   alert(txtFirst);
           document.getElementById('nama_kpi').value = txtFirst;
   }

    $(".delbuttonDetail").click(function(){
        var kode=$(this).attr("kode");
        if(confirm("Anda yakin akan menghapus?"))
            $.ajax({
                url:"<?php echo site_url('c_head/realisasikpi/delDetail');?>",
                type:"POST",
                data:"kode="+kode,
                cache:false,
                success: function(){
              }
            });
            $(this).parents(".gradeX").animate({ opacity: "hide" }, "slow");

    });

    $("#update").click(function(){
        var id=$("#id").val();
        var id_realisasi=$("#id_realisasi").val();
        var id_karyawan=$("#id_karyawan").val();
        var id_kategori=$("#id_kategori").val();
        var id_bulan=$("#id_bulan").val();
        var id_tahun=$("#id_tahun").val();
        var id_supervisor=$("#id_supervisor").val();
        var skor_akhir=$("#skor_akhir").val();
        var enableflag=$("#enableflag").val();

        

        if (id_karyawan=="") {
            alert("Karyawan Tidak Boleh Kosong");
            return false;
        }else if (id_kategori=="") {
            alert("Kategori Tidak Boleh Kosong");
            return false;
        }else{
            $('#update').attr('disabled',true); //set button disable
            $.ajax({
                url:"<?php echo site_url('c_head/realisasikpi/update');?>",
                type:"POST",
                data:"&id="+id+"&id_realisasi="+id_realisasi+"&id_karyawan="+id_karyawan+"&id_kategori="+id_kategori+"&id_bulan="+id_bulan+"&id_tahun="+id_tahun+"&id_supervisor="+id_supervisor+"&skor_akhir="+skor_akhir+"&enableflag="+enableflag,
                cache:false,
                success:function(html){
                    alert("Edit Realisasi Berhasil");
                        //location.reload();
                        window.location = "<?php echo site_url('c_head/realisasikpi');?>";
                    }
                })
        }

    })

</script>

</body>
</html>