<?php
$this->load->view('template/head');
$this->load->view('template/topbar');
$this->load->view('template/sidebar_head_second');
?>
  
  <!-- Content Wrapper. Contains page content -->    
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Beranda Officer
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Beranda</li>
      </ol>
    </section>

    <!-- Main content -->   
    <section class="content" style="height: 100%;" >
    
      <!-- /.row -->
      <br><br>
      <!-- Main row -->
      <div class="row">
        <!-- Left col -->
        <section class="col-lg- connectedSortable" hidden>
          <!-- TO DO List -->
          <div class="box box-primary">
            <div class="box-header">
              <i class="ion ion-person-stalker"></i>

              <h3 class="box-title">Officer</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body" style="overflow-x: auto;">
            <table style="width: 100%;">
    <tr >
      <td colspan="6"> <h5 style="font-weight: bold; text-align: center;">Marketing</h5>&nbsp;</td>
      
      <!-- <td>b</td>
      <td>c</td> -->
    </tr>
    <tr >
      <td colspan="6"><center>
      <div class="small-box bg-green" style="width: 100px; border-radius: 30px;">
            <div class="inner">
            <p style="font-weight: bold; text-align: center;">Rock Star</p>
            </div>
          </div>
          </center>
      </td>
      
      <!-- <td>b</td>
      /* 
      if else if else if else if else if else if else if else if else if else2
      */
      <td>c</td> -->
    </tr>
    <tr >
      <td>
        <div>
          <!-- small box -->
          <div class="small-box bg-green">
            <div class="inner">
            <p style="font-weight: bold; text-align: center;">Rock Star</p>
              <h4 style="font-weight: bold; text-align: center;">5</h4> 
            </div>
          </div>
        </div>
      </td>
      <td>&nbsp;</td>
      <td>
        <div>
          <!-- small box -->
          <div class="small-box bg-orange">
            <div class="inner">
            <p style="font-weight: bold; text-align: center;">Adequate</p>
              <h4 style="font-weight: bold; text-align: center;">5</h4>
            </div>
          </div>
        </div>
      </td>
      <td>&nbsp;</td>
      <td>
      <div >
          <!-- small box -->
          <div class="small-box bg-red">
            <div class="inner">
            <p style="font-weight: bold; text-align: center;">Need Helps</p>
              <h4 style="font-weight: bold; text-align: center;">5</h4>
            </div>
          </div>
        </div>
      </td>
    </tr>
    <tr>
      <td colspan="6">
      <table id="table" class="table table-striped table-bordered" cellspacing="0" width="100%">
                <thead>
                  <tr>
                    <th style="width:50px;">No</th>
                    <th>Images</th>
                    <th>Nama</th>
                    <th>Jabatan</th>
                    <th>Skor</th>
                    <th>KPI</th>
                    <th>Action</th>
                    
                  </tr>
                </thead>
                <tbody>
                </tbody>
              </table>
      </td>
      <!-- <td>h</td>
      <td>i</td>
      <td>j</td>
      <td>k</td> -->
    </tr>
   
    </table>
            </div>
          </div>
          
          <!-- /.box -->

        </section>

        <section class="col-lg-12 connectedSortable" >
          <!-- TO DO List -->
          <div class="box box-primary">
            <div class="box-header">
              <i class="ion ion-stats-bars"></i>

              <h3 class="box-title">KPI Perbulan</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body" style="overflow-x: auto;">
            <div id="chart_div" style="width: 100%; "></div>
            </div>
          </div>
          
          <!-- /.box -->

        </section>

        <section class="col-lg-12 connectedSortable" >
          <!-- TO DO List -->
          <div class="box box-primary">
            <div class="box-header">
              <i class="ion ion-levels"></i>

              <h3 class="box-title">KPI</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body" style="overflow-x: auto;">
              <table id="table" class="table table-striped table-bordered" cellspacing="0" width="100%">
                <thead>
                  <tr>
                    <th style="width:50px;">No</th>
                    <th>Avg. Score</th>
                    <th>Result Areas</th>
                    <th>Review</th>
                    
                  </tr>
                </thead>
                <tbody>
                </tbody>
              </table>
            </div>
          </div>
          
          <!-- /.box -->

        </section>
        
        <!-- /.Left col -->
        <!-- right col (We are only adding the ID to make the widgets sortable)-->
      </div>
      <!-- /.row (main row)  -->

    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  
<?php
$this->load->view('template/foot');
?> 
<!-- jQuery 2.2.3 -->
<!-- jQuery 2.2.3 -->
<script src="<?php echo base_url('assets/plugins/jQuery/jquery-2.2.3.min.js') ?>"></script>
<!-- Bootstrap 3.3.6 -->
<script src="<?php echo base_url('assets/bootstrap/js/bootstrap.min.js') ?>"></script>
<!-- DataTables -->
<script src="<?php echo base_url('assets/plugins/datatables/jquery.dataTables.min.js') ?>"></script>
<script src="<?php echo base_url('assets/plugins/datatables/dataTables.bootstrap.min.js') ?>"></script>
<!-- SlimScroll -->
<script src="<?php echo base_url('assets/plugins/slimScroll/jquery.slimscroll.min.js') ?>"></script>
<!-- FastClick -->
<script src="<?php echo base_url('assets/plugins/fastclick/fastclick.js') ?>"></script>
<!-- AdminLTE App -->
<script src="<?php echo base_url('assets/dist/js/app.min.js') ?>"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?php echo base_url('assets/dist/js/demo.js') ?>"></script>

<!-- page script -->
<script type="text/javascript">
var save_method; //for save method string 
var table;
var base_url = '<?php echo base_url();?>';

$(document).ready(function() {

    //datatables
    table = $('#table').DataTable({ 

        "processing": true, //Feature control the processing indicator.
        "serverSide": true, //Feature control DataTables' server-side processing mode.
        "order": [], //Initial no order.     

        // Load data for the table's content from an Ajax source
        "ajax": {
            "url": "<?php echo site_url('c_officer/berandaofficer/ajax_list')?>",
            "type": "POST"
        },

        //Set column definition initialisation properties.
        "columnDefs": [
            { 
                "targets": [ -1 ], //last column
                "orderable": false, //set not orderable
            },
            { 
                "targets": [ -2 ], //2 last column (photo)
                "orderable": false, //set not orderable
            },
        ],

    });

});


</script>
<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
<html>
  <head>
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
      google.charts.load('current', {'packages':['corechart']});
      google.charts.setOnLoadCallback(drawVisualization);

      function drawVisualization() {
        // Some raw data (not necessarily accurate)
        var data = google.visualization.arrayToDataTable([
          ['Name','1', '2', '3-5'],
          ['Januari',  165,      938,         522],
          ['Februari',  135,      1120,        599],
          ['Maret',  157,      1167,        587],
          ['April',  139,      1110,        615],
          ['Mei',  136,      691,         629]
        ]);

        // var options = {
        //   title : 'Sales Acchievment',
        //   vAxis: {title: 'Millions'},
        //   hAxis: {title: 'Month'},
        //   seriesType: 'bars',
        //   series: {5: {type: 'line'}}
        // };
        var options = {
    title: '',
    legend: { position: 'top', maxLines: 4 },
    seriesType: 'bars',
    // series: {3: {type: 'line'},
    //          4: {type: 'line'}},
   
    colors: ['#C01212', '#FFD900', '#1AAA26'],
    interpolateNulls: false,
        };

        var chart = new google.visualization.ComboChart(document.getElementById('chart_div'));
        chart.draw(data, options);
      }
    </script>
     <script type="text/javascript">
     google.charts.load("current", {packages:["corechart"]});
     google.charts.setOnLoadCallback(drawChart);
     function drawChart() {
       var data = google.visualization.arrayToDataTable([
         ['Age', 'Weight'],
         [ 8,      12],
         [ 4,      5.5],
         [ 11,     14],
         [ 4,      5],
         [ 3,      3.5],
         [ 6.5,    7]
       ]);

       var options = {
         title: 'Sales Trend',
         legend: 'none',
         crosshair: { trigger: 'both', orientation: 'both' },
         trendlines: {
           0: {
             type: 'polynomial',
             degree: 3,
             visibleInLegend: true,
           }
         }
       };

       var chart = new google.visualization.ScatterChart(document.getElementById('polynomial2_div'));
       chart.draw(data, options);
     }
   </script>
    <script type="text/javascript">
      google.charts.load("current", {packages:["corechart"]});
      google.charts.setOnLoadCallback(drawChart);
      function drawChart() {
        var data = google.visualization.arrayToDataTable([
          ['Task', 'Hours per Day'],
          ['Bhuvana',     11],
          ['Aswana',      2],
          ['Sadana',  2]
         
        ]);

        var options = {
          title: 'Sales Contribution',
          is3D: true,
        };

        var chart = new google.visualization.PieChart(document.getElementById('piechart_3d'));
        chart.draw(data, options);
      }
    </script>
     <script type="text/javascript">
      google.charts.load("current", {packages:["corechart"]});
      google.charts.setOnLoadCallback(drawChart);
      function drawChart() {
        var data = google.visualization.arrayToDataTable([
          ['Task', 'Hours per Day'],
          ['< 30 Hari',     11],
          ['30 - 60 Hari',      2],
          ['60 - 90 hari',  2],
          ['> 90 Hari', 2]
        ]);

        var options = {
          title: 'Inventory Turn Over Warning Rate',
          is3D: true,
        };

        var chart = new google.visualization.PieChart(document.getElementById('piechart_3d2'));
        chart.draw(data, options);
      }
    </script>
     <!-- <script type="text/javascript">
      google.charts.load('current', {'packages':['bar']});
      google.charts.setOnLoadCallback(drawChart);

      function drawChart() {
        var data = google.visualization.arrayToDataTable([
          ['Year', 'Sales', 'Expenses', 'Profit'],
          ['2014', 1000, 400, 200],
          ['2015', 1170, 460, 250],
          ['2016', 660, 1120, 300],
          ['2017', 1030, 540, 350]
        ]);

        var options = {
          chart: {
            title: 'Prospect of New Customer',
            legend: { position: 'top', maxLines: 4 },
          }
        };

        var chart = new google.charts.Bar(document.getElementById('columnchart_material'));

        chart.draw(data, google.charts.Bar.convertOptions(options));
      }
    </script> -->
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
      google.charts.load('current', {'packages':['corechart']});
      google.charts.setOnLoadCallback(drawVisualization);

      function drawVisualization() {
        // Some raw data (not necessarily accurate)
        var data = google.visualization.arrayToDataTable([
          ['Name','Drop Off', 'Prospect', 'On Progress'],
          ['Canvasing',  165,      938,         522],
          ['Data Marcom',  135,      1120,        599],
          ['Maret',  157,      1167,        587],
          ['April',  139,      1110,        615],
          ['Mei',  136,      691,         629]
        ]);

        // var options = {
        //   title : 'Sales Acchievment',
        //   vAxis: {title: 'Millions'},
        //   hAxis: {title: 'Month'},
        //   seriesType: 'bars',
        //   series: {5: {type: 'line'}}
        // };
        var options = {
    title: 'Prospect Of New Customer',
    legend: { position: 'bottom', maxLines: 4 },
    seriesType: 'bars',
   
    colors: ['#C90404', '#FF9900', '#F5E612'],
    interpolateNulls: false,
        };

        var chart = new google.visualization.ComboChart(document.getElementById('columnchart_material'));
        chart.draw(data, options);
      }
    </script>
     

<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
      google.charts.load('current', {'packages':['corechart']});
      google.charts.setOnLoadCallback(drawVisualization);

      function drawVisualization() {
        // Some raw data (not necessarily accurate)
        var data = google.visualization.arrayToDataTable([
          ['Name','Lead', 'Closing', 'Convertion Rate'],
          ['Januari',  165,      938,         522],
          ['Februari',  135,      1120,        599],
          ['Maret',  157,      1167,        587],
          ['April',  139,      1110,        615],
          ['Mei',  136,      691,         629]
        ]);

        // var options = {
        //   title : 'Sales Acchievment',
        //   vAxis: {title: 'Millions'},
        //   hAxis: {title: 'Month'},
        //   seriesType: 'bars',
        //   series: {5: {type: 'line'}}
        // };
        var options = {
    title: 'Convertion Rate',
    legend: { position: 'top', maxLines: 4 },
    seriesType: 'bars',
    series: {2: {type: 'line'}},
   
    colors: ['#ffa500', '#FFD900', '#1AAA26', '#26126D', '#1AAA26'],
    interpolateNulls: false,
        };

        var chart = new google.visualization.ComboChart(document.getElementById('columnchart_material2'));
        chart.draw(data, options);
      }
    </script>


</body>
</html>