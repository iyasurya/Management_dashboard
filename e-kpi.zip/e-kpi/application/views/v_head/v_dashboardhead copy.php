<?php
$this->load->view('template/head');
$this->load->view('template/topbar');
$this->load->view('template/sidebar_head');
?>
  
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper" style="overflow-x: auto;">
    <!-- Content Header (Page header) -->
    <section class="content-header" >
    <h1 style="background-color: #28B463; align-content: center;">
        <font style="color: white;"><center><b>DASHBOARD</b></center></font>
    </h1>
    <table>
  &nbsp;
</table>
     <table style="width: 160px;">
      <tr>
        <td> <div class="form-group">
                           
                            <div class="col-md-5">
                            <select class="form-control select2" style="width: 100px; background-color: yellow;" name='id_karyawan' id="id_karyawan" aria-placeholder="">
                                    <option value='0'>Kategori</option>
                                    <?php
                                         if (!empty($kategori)) {
                                         foreach ($kategori as $r) {
                                    echo "<option value=".$r->id_subparameter.">".$r->nama_subparameter."</option>";
                                        }
                                     }
                                    ?>
                                  </select>
                            </div>
                        </div></td>
                        <td> <div class="form-group">
                           
                           <div class="col-md-5">
                                  <select class="form-control select2" style="width: 100px; background-color: yellow;" name='id_karyawan' id="id_karyawan" aria-placeholder="">
                                    <option value='0'>Periode</option>
                                    <?php
                                         if (!empty($periode)) {
                                         foreach ($periode as $r) {
                                    echo "<option value=".$r->id_subparameter.">".$r->nama_subparameter."</option>";
                                        }
                                     }
                                    ?>
                                  </select>
                           </div>
                       </div></td>
                       <td> <div class="form-group">
                           
                           <div class="col-md-5">
                           <select class="form-control select2" style="width: 100px; background-color: yellow;" name='id_karyawan' id="id_karyawan" aria-placeholder="">
                                    <option value='0'>project</option>
                                    <?php
                                         if (!empty($project)) {
                                         foreach ($project as $r) {
                                    echo "<option value=".$r->id_subparameter.">".$r->nama_subparameter."</option>";
                                        }
                                     }
                                    ?>
                                  </select>
                           </div>
                       </div></td>                
                       <td> <div class="form-group">
                           
                           <div class="col-md-5">
                               <select class="form-control select2" style="width: 100px; background-color: yellow;" name='id_karyawan' id="id_karyawan" aria-placeholder="">
                                   <option value='0'>Cluster</option>
                                   <?php
                                        if (!empty($pic)) {
                                           foreach ($pic as $r) {
                                             echo "<option value='$r->id_karyawan'";
                                             echo $record['id_karyawan'] == $r->id_karyawan ? 'selected' : '';
                                             echo">$r->nama_karyawan</option>";
                                           }
                                       }  
                                   ?>
                                 </select>
                           </div>
                       </div></td>
                       <td> <div class="form-group">
                           
                           <div class="col-md-5">
                           <select class="form-control select2" style="width: 100px; background-color: yellow;" name='id_karyawan' id="id_karyawan" aria-placeholder="">
                                    <option value='0'>Team</option>
                                    <?php
                                         if (!empty($team)) {
                                         foreach ($team as $r) {
                                    echo "<option value=".$r->id_subparameter.">".$r->nama_subparameter."</option>";
                                        }
                                     }
                                    ?>
                                  </select>
                           </div>
                       </div></td>
                       <td> <div class="form-group">
                           
                           <div class="col-md-5">
                               <select class="form-control select2" style="width: 100px; background-color: yellow;" name='id_karyawan' id="id_karyawan" aria-placeholder="">
                                   <option value='0'>HA</option>
                                   <?php
                                        if (!empty($pic)) {
                                           foreach ($pic as $r) {
                                             echo "<option value='$r->id_karyawan'";
                                             echo $record['id_karyawan'] == $r->id_karyawan ? 'selected' : '';
                                             echo">$r->nama_karyawan</option>";
                                           }
                                       }  
                                   ?>
                                 </select>
                           </div>
                       </div></td>
                       <td> <div class="form-group">
                           
                           <div class="col-md-5">
                               <select class="form-control select2" style="width: 100px; background-color: yellow;" name='id_karyawan' id="id_karyawan" aria-placeholder="">
                                   <option value='0'>Sources</option>
                                   <?php
                                        if (!empty($pic)) {
                                           foreach ($pic as $r) {
                                             echo "<option value='$r->id_karyawan'";
                                             echo $record['id_karyawan'] == $r->id_karyawan ? 'selected' : '';
                                             echo">$r->nama_karyawan</option>";
                                           }
                                       }  
                                   ?>
                                 </select>
                           </div>
                       </div></td>
        

        
      </tr>
     </table>
     &nbsp;
    </section>
   

    <section class="col-lg-6 connectedSortable">
          <!-- TO DO List -->
          <center>
          <div class="box box-primary">
          <table style="width: 250px;" border="2">
                <tr>
                  <th colspan="2" style="background: #0A3A5C;"><center><font style="color: white;"><b>Sales</b></font></center></th>
                </tr>
                <tr style="text-align: center; ">
                  <td style="width: 125px;"><font style="color: brown;"><b>Target</b></td>
                  <td style="width: 125px;"><font style="color: green;"><b>Realisasi</b></td>
                </tr>
                <tr style="text-align: center;">
                  <td><h1><b>50 M</b></h1></td>
                  <td><h1><b>54 M</b></h1></td>
                </tr>
              </table>
              <table>
  &nbsp;
</table>
<table style="width: 250px;" border="2">
  <tr>
    <th colspan="2" style="background: #944216;;"><center><font style="color: white;"><b>Prospect New Customer</b></font></center></th>
  </tr>
  <tr style="text-align: center; ">
    <td style="width: 125px;"><font style="color: brown;"><b>Target</b></td>
    <td style="width: 125px;"><font style="color: green;"><b>Realisasi</b></td>
  </tr>
  </tr>
  <tr style="text-align: center;">
    <td><h1><b>210</b></h1></td>
    <td><h1><b>198</b></h1></td>
  </tr>
</table>
<table>
  &nbsp;
</table>
<table style="width: 250px;" border="2">
  <tr>
    <th colspan="2" style="background: #605C5A;"><center><font style="color: white;"><b>Conversion Rate</b></font></center></th>
  </tr>
  <tr style="text-align: center; ">
    <td style="width: 125px;"><font style="color: brown;"><center><b>Total Prospect</b></center></td>
    <td style="width: 125px;"><font style="color: green;"><center><b>Closing</b></center></td>
  </tr>
  <tr style="text-align: center;">
    <td><h1><b>1,210</b></h1></td>
    <td><h1><b>110</b></h1></td>
  </tr>
</table>
<table>
  &nbsp;
</table>
<table style="width: 250px;" border="2">
  <tr>
    <th colspan="2" style="background: #0B6421;"><center><font style="color: white;"><b>Inventory Turn Over Warning Rate</b></font></center></th>
  </tr>
  <tr style="text-align: center; ">
    <td style="width: 125px;"><font style="color: green;"><center><b>Closing</b></center></td>
    <td style="width: 125px;"><font style="color: green;"><center><b>Average</b></center></td>
  </tr>
  <tr style="text-align: center;">
    <td><h1><b>72</b></h1></td>
    <td><h1><b>36</b></h1></td>
  </tr>
  <tr style="text-align: center; ">
  <td style="width: 125px;"><font style="color: green;"><center><b>Minimal</b></center></td>
    <td style="width: 125px;"><font style="color: green;"><center><b>Maximal</b></center></td>
  </tr>
  <tr style="text-align: center;">
    <td><h1><b>1</b></h1></td>
    <td><h1><b>619</b></h1></td>
  </tr>
</table>
          </div>
          
          <!-- /.box -->
          </center>
        </section>
        <section class="col-lg-6 connectedSortable">
          <!-- TO DO List -->
          <div class="box box-primary">
           
          <!-- <a href="<?php echo base_url('c_master/chart'); ?>"> <div id="chart_div" ></div></a>
          <a href="<?php echo base_url('c_master/chartsalestrend'); ?>"><div id='polynomial2_div'></div></a> -->
          <div id="chart_div" ></div>
          <div id='polynomial2_div'></div>
          </div>
          
          <!-- /.box -->

        </section>
        <section class="col-lg-12 connectedSortable">
          <!-- TO DO List -->
          <div class="box box-primary">
            <table style="width: 100%;" border="2">
              <tr>
                <!-- <td style="width: 46%;"><a href="<?php echo base_url('c_master/chartsalescontribution'); ?>"><div id="piechart_3d" style=""></div></a></td> -->
                <td style="width: 46%;"><div id="piechart_3d"></div></td>
                <td style="width: 2%;">&nbsp;</td>
                <td style="width: 46%;">b</td>
              </tr>
              <tr>
                <!-- <td style="width: 46%;"><a href="<?php echo base_url('c_master/chartinventoryturnover'); ?>"><div id="piechart_3d2" style=""></div></a></td> -->
                <td style="width: 46%;"><div id="piechart_3d2"></div></td>
                <td style="width: 2%;">&nbsp;</td>
                <td style="width: 46%;">d</td>
              </tr>
            </table>
          <!-- <table border="2" style="width: 100%;">
            <tr style="width: 50%;">
              <td><a href="<?php echo base_url('c_master/chartsalescontribution'); ?>"><div id="piechart_3d" style=""></div></a></td>
              <td><a href="<?php echo base_url('c_master/chartprospectofnewcustomer'); ?>"><div id="columnchart_material" style=" height: 200px;"></div></a></td>
            </tr>
            <tr style="width: 50%;">
              <td><a href="<?php echo base_url('c_master/chartinventoryturnover'); ?>"><div id="piechart_3d2" style=""></div></a></td>
              <td><a href="<?php echo base_url('c_master/chartconvertionrate'); ?>"><div id="columnchart_material2" style=" height: 200px;"></div></a></td>
            </tr>
          </table> -->
            
          </div>
          
          <!-- /.box -->

        </section>
       

        

  
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  
<?php
$this->load->view('template/foot');
?> 

<!-- jQuery 2.2.3 -->
<script src="<?php echo base_url('assets/plugins/jQuery/jquery-2.2.3.min.js') ?>"></script>
<!-- Bootstrap 3.3.6 -->
<script src="<?php echo base_url('assets/bootstrap/js/bootstrap.min.js') ?>"></script>
<!-- DataTables -->
<script src="<?php echo base_url('assets/plugins/datatables/jquery.dataTables.min.js') ?>"></script>
<script src="<?php echo base_url('assets/plugins/datatables/dataTables.bootstrap.min.js') ?>"></script>
<!-- SlimScroll -->
<script src="<?php echo base_url('assets/plugins/slimScroll/jquery.slimscroll.min.js') ?>"></script>
<!-- FastClick -->
<script src="<?php echo base_url('assets/plugins/fastclick/fastclick.js') ?>"></script>
<!-- AdminLTE App -->
<script src="<?php echo base_url('assets/dist/js/app.min.js') ?>"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?php echo base_url('assets/dist/js/demo.js') ?>"></script>

<!-- page script -->
<script type="text/javascript">
var save_method; //for save method string
var table;
var base_url = '<?php echo base_url();?>';

$(document).ready(function() {

    //datatables
    table = $('#table').DataTable({ 

        "processing": true, //Feature control the processing indicator.
        "serverSide": true, //Feature control DataTables' server-side processing mode.
        "order": [], //Initial no order.

        // Load data for the table's content from an Ajax source
        "ajax": {
            "url": "<?php echo site_url('c_master/kpi/ajax_list_dashboard')?>",
            "type": "POST"
        },

        //Set column definition initialisation properties.
        "columnDefs": [
            { 
                "targets": [ -1 ], //last column
                "orderable": false, //set not orderable
            },
            { 
                "targets": [ -2 ], //2 last column (photo)
                "orderable": false, //set not orderable
            },
        ],

    });

});


</script>
<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
<html>
  <head>
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
      google.charts.load('current', {'packages':['corechart']});
      google.charts.setOnLoadCallback(drawVisualization);

      function drawVisualization() {
        // Some raw data (not necessarily accurate)
        var data = google.visualization.arrayToDataTable([
          ['Name','Target 1', 'Target 2', 'Realisasi', 'Ach Target 1','Ach Target 2'],
          ['Januari',  165,      938,         522,             998,           450],
          ['Februari',  135,      1120,        599,             1268,          288],
          ['Maret',  157,      1167,        587,             807,           39],
          ['April',  139,      1110,        615,             968,           215],
          ['Mei',  136,      691,         629,             1026,          366]
        ]);

        // var options = {
        //   title : 'Sales Acchievment',
        //   vAxis: {title: 'Millions'},
        //   hAxis: {title: 'Month'},
        //   seriesType: 'bars',
        //   series: {5: {type: 'line'}}
        // };
        var options = {
    title: 'Sales Achievement',
    legend: { position: 'top', maxLines: 4 },
    seriesType: 'bars',
    series: {3: {type: 'line'},
             4: {type: 'line'}},
   
    colors: ['#ffa500', '#FFD900', '#1AAA26', '#26126D', '#1AAA26'],
    interpolateNulls: false,
        };

        var chart = new google.visualization.ComboChart(document.getElementById('chart_div'));
        chart.draw(data, options);
      }
    </script>
     <script type="text/javascript">
     google.charts.load("current", {packages:["corechart"]});
     google.charts.setOnLoadCallback(drawChart);
     function drawChart() {
       var data = google.visualization.arrayToDataTable([
         ['Age', 'Weight'],
         [ 8,      12],
         [ 4,      5.5],
         [ 11,     14],
         [ 4,      5],
         [ 3,      3.5],
         [ 6.5,    7]
       ]);

       var options = {
         title: 'Sales Trend',
         legend: 'none',
         crosshair: { trigger: 'both', orientation: 'both' },
         trendlines: {
           0: {
             type: 'polynomial',
             degree: 3,
             visibleInLegend: true,
           }
         }
       };

       var chart = new google.visualization.ScatterChart(document.getElementById('polynomial2_div'));
       chart.draw(data, options);
     }
   </script>
    <script type="text/javascript">
      google.charts.load("current", {packages:["corechart"]});
      google.charts.setOnLoadCallback(drawChart);
      function drawChart() {
        var data = google.visualization.arrayToDataTable([
          ['Task', 'Hours per Day'],
          ['Bhuvana',     11],
          ['Aswana',      2],
          ['Sadana',  2]
         
        ]);

        var options = {
          title: 'Sales Contribution',
          is3D: true,
        };

        var chart = new google.visualization.PieChart(document.getElementById('piechart_3d'));
        chart.draw(data, options);
      }
    </script>
     <script type="text/javascript">
      google.charts.load("current", {packages:["corechart"]});
      google.charts.setOnLoadCallback(drawChart);
      function drawChart() {
        var data = google.visualization.arrayToDataTable([
          ['Task', 'Hours per Day'],
          ['< 30 Hari',     11],
          ['30 - 60 Hari',      2],
          ['60 - 90 hari',  2],
          ['> 90 Hari', 2]
        ]);

        var options = {
          title: 'Inventory Turn Over Warning Rate',
          is3D: true,
        };

        var chart = new google.visualization.PieChart(document.getElementById('piechart_3d2'));
        chart.draw(data, options);
      }
    </script>
     <!-- <script type="text/javascript">
      google.charts.load('current', {'packages':['bar']});
      google.charts.setOnLoadCallback(drawChart);

      function drawChart() {
        var data = google.visualization.arrayToDataTable([
          ['Year', 'Sales', 'Expenses', 'Profit'],
          ['2014', 1000, 400, 200],
          ['2015', 1170, 460, 250],
          ['2016', 660, 1120, 300],
          ['2017', 1030, 540, 350]
        ]);

        var options = {
          chart: {
            title: 'Prospect of New Customer',
            legend: { position: 'top', maxLines: 4 },
          }
        };

        var chart = new google.charts.Bar(document.getElementById('columnchart_material'));

        chart.draw(data, google.charts.Bar.convertOptions(options));
      }
    </script> -->
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
      google.charts.load('current', {'packages':['corechart']});
      google.charts.setOnLoadCallback(drawVisualization);

      function drawVisualization() {
        // Some raw data (not necessarily accurate)
        var data = google.visualization.arrayToDataTable([
          ['Name','Drop Off', 'Prospect', 'On Progress'],
          ['Canvasing',  165,      938,         522],
          ['Data Marcom',  135,      1120,        599],
          ['Maret',  157,      1167,        587],
          ['April',  139,      1110,        615],
          ['Mei',  136,      691,         629]
        ]);

        // var options = {
        //   title : 'Sales Acchievment',
        //   vAxis: {title: 'Millions'},
        //   hAxis: {title: 'Month'},
        //   seriesType: 'bars',
        //   series: {5: {type: 'line'}}
        // };
        var options = {
    title: 'Prospect Of New Customer',
    legend: { position: 'bottom', maxLines: 4 },
    seriesType: 'bars',
   
    colors: ['#C90404', '#FF9900', '#F5E612'],
    interpolateNulls: false,
        };

        var chart = new google.visualization.ComboChart(document.getElementById('columnchart_material'));
        chart.draw(data, options);
      }
    </script>
     

<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
      google.charts.load('current', {'packages':['corechart']});
      google.charts.setOnLoadCallback(drawVisualization);

      function drawVisualization() {
        // Some raw data (not necessarily accurate)
        var data = google.visualization.arrayToDataTable([
          ['Name','Lead', 'Closing', 'Convertion Rate'],
          ['Januari',  165,      938,         522],
          ['Februari',  135,      1120,        599],
          ['Maret',  157,      1167,        587],
          ['April',  139,      1110,        615],
          ['Mei',  136,      691,         629]
        ]);

        // var options = {
        //   title : 'Sales Acchievment',
        //   vAxis: {title: 'Millions'},
        //   hAxis: {title: 'Month'},
        //   seriesType: 'bars',
        //   series: {5: {type: 'line'}}
        // };
        var options = {
    title: 'Convertion Rate',
    legend: { position: 'top', maxLines: 4 },
    seriesType: 'bars',
    series: {2: {type: 'line'}},
   
    colors: ['#ffa500', '#FFD900', '#1AAA26', '#26126D', '#1AAA26'],
    interpolateNulls: false,
        };

        var chart = new google.visualization.ComboChart(document.getElementById('columnchart_material2'));
        chart.draw(data, options);
      }
    </script>
  </head>
  <body>
   
  </body>
</html>
</body>
</html>
