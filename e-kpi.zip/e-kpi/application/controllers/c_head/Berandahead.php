<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Berandahead extends CI_Controller {

	function __construct(){
		parent::__construct();
		$this->load->model('m_head/m_berandahead','head');
	}

	public function index(){
		$bulanFrom= $this->input->post('id_bulanFrom');
		$bulanTo= $this->input->post('id_bulanTo');
		$tahunFrom= $this->input->post('id_tahunFrom');
		$tahunTo= $this->input->post('id_tahunTo');
		

		$bFrom =$bulanFrom;
		if ($bulanFrom == null ) {
			$bFrom = 'B0001';
			} 

		$bTo =$bulanTo;
		if ($bulanTo == null ) {
			$bTo = 'B0012';
			} 

		$tFrom =$tahunFrom;
		if ($tahunFrom == null ) {
			$tFrom = 'T0001';
			} 

		$tTo =$tahunTo;
		if ($tahunTo == null ) {
			$tTo = 'T0001';
			} 
		
		 $periode= $this->input->post('periode');	
		// //var_dump($periode);
		// $bFrom ='';
		// $bTo ='';
		// $tFrom ='';
		// $tTo ='';
		// if ($periode == 'SP0005' ) {
		// 	date('Y-m-d');
		// 	$bFrom = 'B0001';
		// 	$bTo = 'B0012';
		// 	$tFrom = 'T0001';
		// 	$tTo = 'T0001';
			
		// 	} 	



		$data['realisasi']			= $this->head->viewRealisasi($bFrom,$bTo,$tFrom,$tTo,$periode); 
		$data['kpi']			= $this->head->viewKPI($bFrom,$bTo,$tFrom,$tTo,$periode);
		$data['departemen']			= $this->head->viewDepartement();
		$data['bulan']=$this->db->get_where('m_bulan',array('enableflag'=> '0'))->result();
		$data['tahun']=$this->db->get_where('m_tahun',array('enableflag'=> '0'))->result();
		$data['periode']=$this->db->get_where('m_subparameter',array('enableflag'=> '0','id_parameter'=> 'PM0004'))->result();
		$data['kpi1']			= $this->head->viewNilaiKPI1()->num_rows();
		$data['kpi2']			= $this->head->viewNilaiKPI2()->num_rows();
		$data['kpi3']			= $this->head->viewNilaiKPI3()->num_rows();
		$data['kpi4']			= $this->head->viewNilaiKPI4()->num_rows();
		$data['kpi5']			= $this->head->viewNilaiKPI5()->num_rows();
		$this->load->view('v_head/v_berandahead',$data);
		
	}

	public function ajax_list()
	{
		$this->load->helper('url');

		$list = $this->head->get_datatables();
		$data = array();
		$no = $_POST['start'];
		foreach ($list as $head) {
			$no++;
			$row = array();
			if($head->attachement)
			$row[] = '<center><a href="'.base_url('upload/'.$head->attachement).'" target="_blank"><img src="'.base_url('upload/'.$head->attachement).'" class="img-responsive" width="50" height="50"/>
			</a></center>';
		    else
			$row[] = '(No photo)';
		    $row[] = $head->nama_karyawan;
			if($head->nilai > 2)
			$row[] = '<center>
			<a class="btn btn-sm btn-success" href="" title="Rock Star">
			'.number_format(empty($head->nilai) ? '0' : $head->nilai,1,",",".").'
			</a></center>';
			else if($head->nilai == 2)
			$row[] = '<center>
			<a class="btn btn-sm btn-warning" href="" title="Adequate">
			'.number_format(empty($head->nilai) ? '0' : $head->nilai,1,",",".").'
			</a></center>';
			else
			$row[] = '<center>
			<a class="btn btn-sm btn-danger" href="" title="Need Helps">
			'.number_format(empty($head->nilai) ? '0' : $head->nilai,1,",",".").'
			</a></center>';
			$row[] = '<center>
			<a class="btn btn-sm btn-info" href="berandahead/detail/'.$head->id_karyawan.'" title="Detail"><i class="glyphicon glyphicon-search"></i></a></center>';
			$data[] = $row;
		}

		$output = array(
						"draw" => $_POST['draw'],
						"recordsTotal" => $this->head->count_all(),
						"recordsFiltered" => $this->head->count_filtered(),
						"data" => $data,
				);
		//output to json format
		echo json_encode($output);
	}

	public function ajax_list_dashboard()
	{
		$this->load->helper('url');

		$list = $this->head->get_datatables();
		$data = array();
		$no = $_POST['start'];
		foreach ($list as $head) {
			$no++;
			$row = array();
			$row[] = $no;
			$row[] = $head->nama_departemen;
			$row[] = $head->nama_karyawan;
			$row[] = $head->nama_jabatan;
			$row[] = $head->nama_kpi;
			$row[] = $head->skor_akhir;
			
			//add html for action
			// $row[] = '<center><a class="btn btn-sm btn-primary" href="c_master/head/edit/'.$head->id_kpi.'" title="Edit"><i class="glyphicon glyphicon-pencil"></i></a></center>';
		
			$row[] = '<center><a class="btn btn-sm btn-primary" href="c_master/head/edit/'.$head->id_kpi.'" title="Edit"><i class="glyphicon glyphicon-pencil"></i></a>
			<a class="btn btn-sm btn-info" href="c_master/head/detail/'.$head->id_kpi.'" title="Detail"><i class="glyphicon glyphicon-search"></i></a></center>';
			$data[] = $row;
		}

		$output = array(
						"draw" => $_POST['draw'],
						"recordsTotal" => $this->head->count_all(),
						"recordsFiltered" => $this->head->count_filtered(),
						"data" => $data,
				);
		//output to json format 
		echo json_encode($output);
	}

	public function ajax_list_departement()
	{
		$this->load->helper('url');

		$list = $this->head->get_datatables();
		$data = array();
		$no = $_POST['start'];    
		foreach ($list as $head) {
			$no++;
			$row = array();
			$row[] = $no;
			$row[] = $head->nama_departemen;
			
		
			$row[] ='
			<div class="progress">
			<div class="progress-bar" role="progressbar" aria-valuenow="70" aria-valuemin="0" aria-valuemax="100" style="width:70%">
			  70%
			</div>
		  </div>';

			$row[] = '<center>
					<a class="btn btn-sm btn-info" href="c_departement/departement/detail/'.$head->id_departemen.'" title="Detail"><i class="glyphicon glyphicon-circle-arrow-right"></i></a>
					</center>';
			$data[] = $row;
		}

		$output = array(
						"draw" => $_POST['draw'],
						"recordsTotal" => $this->head->count_all(),
						"recordsFiltered" => $this->head->count_filtered(),
						"data" => $data,
				);
		//output to json format
		echo json_encode($output);
	}

	function add() { 
		//$data['tanggal_lahir']=date('Y-m-d');
		//$data['tanggal_masuk']=date('Y-m-d'); date format
		$data['unit']=$this->db->get_where('m_unit',array('enableflag'=> '0'))->result();
		$data['departemen']=$this->db->get_where('m_departemen',array('enableflag'=> '0'))->result();
		$data['section']=$this->db->get_where('m_section',array('enableflag'=> '0'))->result();
		$data['jabatan']=$this->db->get_where('m_jabatan',array('enableflag'=> '0'))->result();
		$data['pic']=$this->db->get_where('m_pic',array('enableflag'=> '0'))->result();
		
		$this->load->view('v_head/v_kpi_add',$data);
	}

	function save(){
		$infoHeader=array(
			'id_kpi'=>$this->input->post('id_kpi'),
			'id_unit'=>$this->input->post('id_unit'),
			'id_departemen'=>$this->input->post('id_departemen'),
			'id_section'=>$this->input->post('id_section'),  
			'id_jabatan'=>$this->input->post('id_jabatan'),
			'nama_kpi'=>$this->input->post('nama_kpi'),
			'perspective'=>$this->input->post('perspective'),
			'subkpi'=>$this->input->post('subkpi'),
			'parameter'=>$this->input->post('parameter'),
			'measurement'=>$this->input->post('measurement'),
			'sourcesdata'=>$this->input->post('sourcesdata'),
			'pic'=>$this->input->post('pic'),
			'enableflag'=>$this->input->post('enableflag'),
			'userid' => $this->session->userdata("name")
			);

		$this->head->save($infoHeader);

		redirect('c_master/head');
	}

	function edit(){
		$id= $this->uri->segment(4);
		$data['record']=  $this->db->get_where('m_kpi',array('id_kpi'=> $id))->row_array();
		$data['unit']=$this->db->get_where('m_unit',array('enableflag'=> '0'))->result();
		$data['departemen']=$this->db->get_where('m_departemen',array('enableflag'=> '0'))->result();
		$data['section']=$this->db->get_where('m_section',array('enableflag'=> '0'))->result();
		$data['jabatan']=$this->db->get_where('m_jabatan',array('enableflag'=> '0'))->result();
		$data['pic']=$this->db->get_where('m_pic',array('enableflag'=> '0'))->result();
		
		$this->load->view('v_head/v_kpi_edit',$data);
	}

	function detail(){
		$id= $this->uri->segment(4);
		$data['record']=  $this->db->get_where('m_kpi',array('id_kpi'=> $id))->row_array();
		$data['unit']=$this->db->get_where('m_unit',array('enableflag'=> '0'))->result();
		$data['departemen']=$this->db->get_where('m_departemen',array('enableflag'=> '0'))->result();
		$data['section']=$this->db->get_where('m_section',array('enableflag'=> '0'))->result();
		$data['jabatan']=$this->db->get_where('m_jabatan',array('enableflag'=> '0'))->result();
		$data['pic']=$this->db->get_where('m_pic',array('enableflag'=> '0'))->result();
		
		$this->load->view('v_head/v_berandaofficer',$data);
	}

	function update(){ 
		$id=$this->input->post('id');
		$id_kpi=$this->input->post('id_kpi'); 
		$id_unit=$this->input->post('id_unit');
		$id_departemen=$this->input->post('id_departemen');
		$id_section=$this->input->post('id_section');
		$id_jabatan=$this->input->post('id_jabatan');
		$nama_kpi=$this->input->post('nama_kpi');
		$perspective=$this->input->post('perspective');
		$subkpi=$this->input->post('subkpi');
		$parameter=$this->input->post('parameter');
		$measurement=$this->input->post('measurement');
		$sourcesdata=$this->input->post('sourcesdata');
		$pic=$this->input->post('pic');
		$enableflag=$this->input->post('enableflag');

		$this->head->update($id,$id_kpi,$id_unit,$id_departemen,$id_section,$id_jabatan,$nama_kpi,$perspective,$subkpi,
		$parameter,$measurement,$sourcesdata,$pic,$enableflag);

		redirect('c_master/head');
	}

	public function ajax_delete($id)
	{
		//delete file
		$head = $this->head->get_by_id($id);
		
		$this->head->delete_by_id($id);
		echo json_encode(array("status" => TRUE));
	}
	
}



