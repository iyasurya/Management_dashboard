<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends CI_Controller {

	function __construct(){
		parent::__construct();
		$this->load->model('m_login','login');
		
		if($this->session->userdata('status') != "login"){
			redirect(base_url("auth"));
		}

		$this->load->model('m_login');
	}

	public function index(){
		$data['lsu']			= $this->login->viewLsu()->num_rows();
		$data['pmu']			= $this->login->viewPmu()->num_rows();
		$data['rebu']			= $this->login->viewRebu()->num_rows();
		$data['tcbu']			= $this->login->viewTcbu()->num_rows();
		$data['csu']			= $this->login->viewCsu()->num_rows();

		$this->load->view('v_dashboard',$data);
	}

	// public function ajax_list()
	// {
	// 	$kd_poli=$this->session->userdata("kd_poli");
	// 	$this->load->helper('url');

	// 	$list = $this->login->get_datatables($kd_poli);
	// 	$data = array();
	// 	$no = $_POST['start'];
	// 	foreach ($list as $login) {
	// 		$no++;
	// 		$row = array();
	// 		$row[] = $no;
	// 		$row[] = $login->no_rawat;
	// 		$row[] = $login->no_rkm_medis;
	// 		$row[] = $login->nm_pasien;
	// 		$row[] = $login->png_jawab;
	// 		$row[] = $login->stts_daftar;
	// 		$row[] = $login->jam_reg;

	// 		if($kd_poli == 'IGDK'){
	// 			$row[] = '<center><a class="btn btn-sm btn-success" href="dashboard/editIGD/'.$login->no_rawat.'/'.$login->no_rkm_medis.'/'.$login->kd_pj.'/'.$login->kd_poli.'" title="Edit"><i class="glyphicon glyphicon-pencil"></i></a></center>';
			
	// 		}else{
	// 			$row[] = '<center><a class="btn btn-sm btn-success" href="dashboard/edit/'.$login->no_rawat.'/'.$login->no_rkm_medis.'/'.$login->kd_pj.'/'.$login->kd_poli.'" title="Edit"><i class="glyphicon glyphicon-pencil"></i></a></center>';
	// 		}
			
			
	// 		$data[] = $row;
	// 	}

	// 	$output = array(
	// 		"draw" => $_POST['draw'],
	// 		"recordsTotal" => $this->login->count_all(),
	// 		"recordsFiltered" => $this->login->count_filtered(),
	// 		"data" => $data,
	// 		);
	// 	//output to json format
	// 	echo json_encode($output);
	// }

}
