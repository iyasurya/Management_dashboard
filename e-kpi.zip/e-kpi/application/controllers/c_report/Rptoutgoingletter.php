<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Rptoutgoingletter extends CI_Controller {

	function __construct(){
		parent::__construct();
		$this->load->model('m_report/m_rptoutgoingletter','rptoutgoingletter');
	}

	public function index(){
		$data['record']=$this->db->get_where('m_typeofletter',array('enableflag'=> '0'))->result();
		$data['record2']=$this->db->get_where('m_classificationofletter',array('enableflag'=> '0','typeclassification'=> '2'))->result();
		$this->load->view('v_report/v_rptoutgoingletter',$data);
	}

	function print_detail() { 
		$datefrom=$this->input->post('datefrom');
		$dateto=$this->input->post('dateto');
		$typeofletteridfrom=$this->input->post('typeofletteridfrom');
		$typeofletteridto=$this->input->post('typeofletteridto');
		$classificationofletteridfrom=$this->input->post('classificationofletteridfrom');
		$classificationofletteridto=$this->input->post('classificationofletteridto');
		$reporttype=$this->input->post('reporttype');

		if($reporttype == 1){

			redirect('../../e-arsip.report/rptoutgoingletter_detail.php?datefrom='.$datefrom.'&dateto='.$dateto.'&typeofletteridfrom='.$typeofletteridfrom.'&typeofletteridto='.$typeofletteridto.'&classificationofletteridfrom='.$classificationofletteridfrom.'&classificationofletteridto='.$classificationofletteridto);
		
		}else if($reporttype == 2){

			redirect('../../e-arsip.report/rptoutgoingletter_groupbytype.php?datefrom='.$datefrom.'&dateto='.$dateto.'&typeofletteridfrom='.$typeofletteridfrom.'&typeofletteridto='.$typeofletteridto.'&classificationofletteridfrom='.$classificationofletteridfrom.'&classificationofletteridto='.$classificationofletteridto);

		}else{

			redirect('../../e-arsip.report/rptoutgoingletter_groupbyclassification.php?datefrom='.$datefrom.'&dateto='.$dateto.'&typeofletteridfrom='.$typeofletteridfrom.'&typeofletteridto='.$typeofletteridto.'&classificationofletteridfrom='.$classificationofletteridfrom.'&classificationofletteridto='.$classificationofletteridto);

		}
	}

}