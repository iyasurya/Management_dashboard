<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Berandasectionhead extends CI_Controller {

	function __construct(){
		parent::__construct();
		$this->load->model('m_section/m_berandasectionhead','section');
	}

	public function index(){
		$bulanFrom= $this->input->post('id_bulanFrom');
		$bulanTo= $this->input->post('id_bulanTo');
		$tahunFrom= $this->input->post('id_tahunFrom');
		$tahunTo= $this->input->post('id_tahunTo');
		

		$bFrom =$bulanFrom;
		if ($bulanFrom == null ) {
			$bFrom = 'B0001';
			} 

		$bTo =$bulanTo;
		if ($bulanTo == null ) {
			$bTo = 'B0012';
			} 

		$tFrom =$tahunFrom;
		if ($tahunFrom == null ) {
			$tFrom = 'T0001';
			} 

		$tTo =$tahunTo;
		if ($tahunTo == null ) {
			$tTo = 'T0001';
			} 
		
		 $periode= $this->input->post('periode');	
		// //var_dump($periode);
		// $bFrom ='';
		// $bTo ='';
		// $tFrom ='';
		// $tTo ='';
		// if ($periode == 'SP0005' ) {
		// 	date('Y-m-d');
		// 	$bFrom = 'B0001';
		// 	$bTo = 'B0012';
		// 	$tFrom = 'T0001';
		// 	$tTo = 'T0001';
			
		// 	} 	



		$data['realisasi']			= $this->section->viewRealisasi($bFrom,$bTo,$tFrom,$tTo,$periode); 
		$data['kpi']			= $this->section->viewKPI($bFrom,$bTo,$tFrom,$tTo,$periode);
		$data['departemen']			= $this->section->viewDepartement();
		$data['bulan']=$this->db->get_where('m_bulan',array('enableflag'=> '0'))->result();
		$data['tahun']=$this->db->get_where('m_tahun',array('enableflag'=> '0'))->result();
		$data['periode']=$this->db->get_where('m_subparameter',array('enableflag'=> '0','id_parameter'=> 'PM0004'))->result();
		$this->load->view('v_section/v_berandasectionhead',$data);
		
	}

	public function ajax_list()
	{
		$this->load->helper('url');

		$list = $this->section->get_datatables();
		$data = array();
		$no = $_POST['start'];
		foreach ($list as $section) {
			$no++;
			$row = array();
			if($section->attachement)
			$row[] = '<center><a href="'.base_url('upload/'.$section->attachement).'" target="_blank"><img src="'.base_url('upload/'.$section->attachement).'" class="img-responsive" width="50" height="50"/>'.$section->nama_karyawan.'
			</a></center>';
		    else
			$row[] = '(No photo)';
			// $row[] = $section->nama_jabatan;
			if($section->nilai > 2)
			$row[] = '<center>
			<a class="btn btn-sm btn-success" href="" title="Rock Star">
			'.number_format(empty($section->nilai) ? '0' : $section->nilai,1,",",".").'
			</a></center>';
			else if($section->nilai == 2)
			$row[] = '<center>
			<a class="btn btn-sm btn-warning" href="" title="Adequate">
			'.number_format(empty($section->nilai) ? '0' : $section->nilai,1,",",".").'
			</a></center>';
			else
			$row[] = '<center>
			<a class="btn btn-sm btn-danger" href="" title="Need Helps">
			'.number_format(empty($section->nilai) ? '0' : $section->nilai,1,",",".").'
			</a></center>';
			$row[] = '<center>
			<a class="btn btn-sm btn-info" href="berandahead/detail/'.$section->id_karyawan.'" title="Detail"><i class="glyphicon glyphicon-search"></i></a></center>';
			$data[] = $row;
		}

		$output = array(
						"draw" => $_POST['draw'],
						"recordsTotal" => $this->section->count_all(),
						"recordsFiltered" => $this->section->count_filtered(),
						"data" => $data,
				);
		//output to json format
		echo json_encode($output);
	}

	public function ajax_list_dashboard()
	{
		$this->load->helper('url');

		$list = $this->section->get_datatables();
		$data = array();
		$no = $_POST['start'];
		foreach ($list as $section) {
			$no++;
			$row = array();
			$row[] = $no;
			$row[] = $section->nama_departemen;
			$row[] = $section->nama_karyawan;
			$row[] = $section->nama_jabatan;
			$row[] = $section->nama_kpi;
			$row[] = $section->skor_akhir;
			
			//add html for action
			// $row[] = '<center><a class="btn btn-sm btn-primary" href="c_master/section/edit/'.$section->id_kpi.'" title="Edit"><i class="glyphicon glyphicon-pencil"></i></a></center>';
		
			$row[] = '<center><a class="btn btn-sm btn-primary" href="c_master/section/edit/'.$section->id_kpi.'" title="Edit"><i class="glyphicon glyphicon-pencil"></i></a>
			<a class="btn btn-sm btn-info" href="c_master/section/detail/'.$section->id_kpi.'" title="Detail"><i class="glyphicon glyphicon-search"></i></a></center>';
			$data[] = $row;
		}

		$output = array(
						"draw" => $_POST['draw'],
						"recordsTotal" => $this->section->count_all(),
						"recordsFiltered" => $this->section->count_filtered(),
						"data" => $data,
				);
		//output to json format 
		echo json_encode($output);
	}

	public function ajax_list_departement()
	{
		$this->load->helper('url');

		$list = $this->section->get_datatables();
		$data = array();
		$no = $_POST['start'];    
		foreach ($list as $section) {
			$no++;
			$row = array();
			$row[] = $no;
			$row[] = $section->nama_departemen;
			
		
			$row[] ='
			<div class="progress">
			<div class="progress-bar" role="progressbar" aria-valuenow="70" aria-valuemin="0" aria-valuemax="100" style="width:70%">
			  70%
			</div>
		  </div>';

			$row[] = '<center>
					<a class="btn btn-sm btn-info" href="c_departement/departement/detail/'.$section->id_departemen.'" title="Detail"><i class="glyphicon glyphicon-circle-arrow-right"></i></a>
					</center>';
			$data[] = $row;
		}

		$output = array(
						"draw" => $_POST['draw'],
						"recordsTotal" => $this->section->count_all(),
						"recordsFiltered" => $this->section->count_filtered(),
						"data" => $data,
				);
		//output to json format
		echo json_encode($output);
	}

	function add() { 
		//$data['tanggal_lahir']=date('Y-m-d');
		//$data['tanggal_masuk']=date('Y-m-d'); date format
		$data['unit']=$this->db->get_where('m_unit',array('enableflag'=> '0'))->result();
		$data['departemen']=$this->db->get_where('m_departemen',array('enableflag'=> '0'))->result();
		$data['section']=$this->db->get_where('m_section',array('enableflag'=> '0'))->result();
		$data['jabatan']=$this->db->get_where('m_jabatan',array('enableflag'=> '0'))->result();
		$data['pic']=$this->db->get_where('m_pic',array('enableflag'=> '0'))->result();
		
		$this->load->view('v_section/v_kpi_add',$data);
	}

	function save(){
		$infoHeader=array(
			'id_kpi'=>$this->input->post('id_kpi'),
			'id_unit'=>$this->input->post('id_unit'),
			'id_departemen'=>$this->input->post('id_departemen'),
			'id_section'=>$this->input->post('id_section'),  
			'id_jabatan'=>$this->input->post('id_jabatan'),
			'nama_kpi'=>$this->input->post('nama_kpi'),
			'perspective'=>$this->input->post('perspective'),
			'subkpi'=>$this->input->post('subkpi'),
			'parameter'=>$this->input->post('parameter'),
			'measurement'=>$this->input->post('measurement'),
			'sourcesdata'=>$this->input->post('sourcesdata'),
			'pic'=>$this->input->post('pic'),
			'enableflag'=>$this->input->post('enableflag'),
			'userid' => $this->session->userdata("name")
			);

		$this->section->save($infoHeader);

		redirect('c_master/section');
	}

	function edit(){
		$id= $this->uri->segment(4);
		$data['record']=  $this->db->get_where('m_kpi',array('id_kpi'=> $id))->row_array();
		$data['unit']=$this->db->get_where('m_unit',array('enableflag'=> '0'))->result();
		$data['departemen']=$this->db->get_where('m_departemen',array('enableflag'=> '0'))->result();
		$data['section']=$this->db->get_where('m_section',array('enableflag'=> '0'))->result();
		$data['jabatan']=$this->db->get_where('m_jabatan',array('enableflag'=> '0'))->result();
		$data['pic']=$this->db->get_where('m_pic',array('enableflag'=> '0'))->result();
		
		$this->load->view('v_section/v_kpi_edit',$data);
	}

	function detail(){
		$id= $this->uri->segment(4);
		$data['record']=  $this->db->get_where('m_kpi',array('id_kpi'=> $id))->row_array();
		$data['unit']=$this->db->get_where('m_unit',array('enableflag'=> '0'))->result();
		$data['departemen']=$this->db->get_where('m_departemen',array('enableflag'=> '0'))->result();
		$data['section']=$this->db->get_where('m_section',array('enableflag'=> '0'))->result();
		$data['jabatan']=$this->db->get_where('m_jabatan',array('enableflag'=> '0'))->result();
		$data['pic']=$this->db->get_where('m_pic',array('enableflag'=> '0'))->result();
		
		$this->load->view('v_section/v_berandaofficer',$data);
	}

	function update(){ 
		$id=$this->input->post('id');
		$id_kpi=$this->input->post('id_kpi'); 
		$id_unit=$this->input->post('id_unit');
		$id_departemen=$this->input->post('id_departemen');
		$id_section=$this->input->post('id_section');
		$id_jabatan=$this->input->post('id_jabatan');
		$nama_kpi=$this->input->post('nama_kpi');
		$perspective=$this->input->post('perspective');
		$subkpi=$this->input->post('subkpi');
		$parameter=$this->input->post('parameter');
		$measurement=$this->input->post('measurement');
		$sourcesdata=$this->input->post('sourcesdata');
		$pic=$this->input->post('pic');
		$enableflag=$this->input->post('enableflag');

		$this->section->update($id,$id_kpi,$id_unit,$id_departemen,$id_section,$id_jabatan,$nama_kpi,$perspective,$subkpi,
		$parameter,$measurement,$sourcesdata,$pic,$enableflag);

		redirect('c_master/section');
	}

	public function ajax_delete($id)
	{
		//delete file
		$section = $this->section->get_by_id($id);
		
		$this->section->delete_by_id($id);
		echo json_encode(array("status" => TRUE));
	}
	
}



