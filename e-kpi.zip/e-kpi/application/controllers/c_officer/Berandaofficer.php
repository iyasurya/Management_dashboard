<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Berandaofficer extends CI_Controller {

	function __construct(){
		parent::__construct();
		$this->load->model('m_officer/m_berandaofficer','rebu');
	}

	public function index(){
		$bulanFrom= $this->input->post('id_bulanFrom');
		$bulanTo= $this->input->post('id_bulanTo');
		$tahunFrom= $this->input->post('id_tahunFrom');
		$tahunTo= $this->input->post('id_tahunTo');
		

		$bFrom =$bulanFrom;
		if ($bulanFrom == null ) {
			$bFrom = 'B0001';
			} 

		$bTo =$bulanTo;
		if ($bulanTo == null ) {
			$bTo = 'B0012';
			} 

		$tFrom =$tahunFrom;
		if ($tahunFrom == null ) {
			$tFrom = 'T0001';
			} 

		$tTo =$tahunTo;
		if ($tahunTo == null ) {
			$tTo = 'T0001';
			} 
		
		 $periode= $this->input->post('periode');	
		// //var_dump($periode);
		// $bFrom ='';
		// $bTo ='';
		// $tFrom ='';
		// $tTo ='';
		// if ($periode == 'SP0005' ) {
		// 	date('Y-m-d');
		// 	$bFrom = 'B0001';
		// 	$bTo = 'B0012';
		// 	$tFrom = 'T0001';
		// 	$tTo = 'T0001';
			
		// 	} 	



		$data['realisasi']			= $this->rebu->viewRealisasi($bFrom,$bTo,$tFrom,$tTo,$periode); 
		$data['kpi']			= $this->rebu->viewKPI($bFrom,$bTo,$tFrom,$tTo,$periode);
		$data['bulan']=$this->db->get_where('m_bulan',array('enableflag'=> '0'))->result();
		$data['tahun']=$this->db->get_where('m_tahun',array('enableflag'=> '0'))->result();
		$data['periode']=$this->db->get_where('m_subparameter',array('enableflag'=> '0','id_parameter'=> 'PM0004'))->result();
		
		$this->load->view('v_officer/v_berandaofficer',$data);
		
	}

	
}



