<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Realisasikpi extends CI_Controller {

	function __construct(){
		parent::__construct();
		$this->load->model('m_officer/m_realisasikpi','realisasikpi');
	}

	public function index(){
		$this->load->view('v_officer/v_realisasikpi');
	}

	public function ajax_list()
	{
		$this->load->helper('url');
    
		$list = $this->realisasikpi->get_datatables();
		$data = array();
		$no = $_POST['start'];
		foreach ($list as $realisasikpi) {
			$no++;
			$row = array();
			$row[] = $no;
			$row[] = $realisasikpi->id_realisasi;
			$row[] = $realisasikpi->nama_karyawan;
		//	$row[] = $realisasikpi->nama_kategori;
			$row[] = $realisasikpi->nama_bulan;
			$row[] = $realisasikpi->nama_tahun;
		//	$row[] = $realisasikpi->id_supervisor;
			$row[] = $realisasikpi->skor_akhir;

			// if($realisasikpi->status =='4'){
			//    $row[] = '<center><i class="glyphicon glyphicon-ok"></i></center>';
			// }else{
			   $row[] = '<center><a class="btn btn-sm btn-primary" href="realisasikpi/edit/'.$realisasikpi->id.'/'.$realisasikpi->id_realisasi.'" title="Edit"><i class="glyphicon glyphicon-pencil"></i></a>
			   		</center>';

				//	   <a class="btn btn-sm btn-warning" href="realisasikpi/updateStatus/'.$realisasikpi->id.'" title="Update Selesai"><i class="glyphicon glyphicon-ok"></i></a>
			// }
		
			$data[] = $row;
		}

		$output = array(
						"draw" => $_POST['draw'],
						"recordsTotal" => $this->realisasikpi->count_all(),
						"recordsFiltered" => $this->realisasikpi->count_filtered(),
						"data" => $data,
				);
		//output to json format
		echo json_encode($output);
	}

	function add() { 
		$data['kodejadi']=$this->createidrealisasikpi();
		$data['dateofletter']=date('Y-m-d');
		$data['kpi']=$this->db->get_where('m_kpikaryawan',array('enableflag'=> '0', 'id_karyawan'=> $_SESSION['id_karyawan']))->result();
		$data['bulan']=$this->db->get_where('m_bulan',array('enableflag'=> '0'))->result();
		$data['tahun']=$this->db->get_where('m_tahun',array('enableflag'=> '0'))->result();
		$data['karyawan']=$this->db->get_where('m_karyawan',array('enableflag'=> '0'))->result();
		$data['kategori']=$this->db->get_where('m_kategori',array('enableflag'=> '0'))->result();
	//	$data['record']=$this->db->get_where('t_realisasi',array('enableflag'=> '0'))->result();
		$data['record']=  $this->db->get_where('t_realisasi',array('id_karyawan'=> $_SESSION['id_karyawan']))->row_array();
		$data['record2']=$this->db->get_where('m_classificationofletter',array('enableflag'=> '0','typeclassification'=> '2'))->result();

		$this->realisasikpi->deleteAllTemp();

		$this->load->view('v_officer/v_realisasikpi_add',$data);
	}

	function createidrealisasikpi()   {
		$nowMonthYear = date('my');
		$this->db->select('RIGHT(t_realisasi.id_realisasi,4) as kode', FALSE);
		$this->db->order_by('id_realisasi','DESC');    
		$this->db->limit(1);    
	  $query = $this->db->get('t_realisasi');      //cek dulu apakah ada sudah ada kode di tabel.    
	  if($query->num_rows() <> 0){      
	   //jika kode ternyata sudah ada.      
	  	$data = $query->row();      
	  	$kode = intval($data->kode) + 1;    
	  }
	  else{      
	   //jika kode belum ada      
	  	$kode = 1;    
	  }
	  $kodemax = str_pad($kode, 4, "0", STR_PAD_LEFT);    
	  $kodejadi = "RL".$kodemax; 
	  return $kodejadi;  
	}


	function save(){
		//$classificationofletterid=$this->input->post('classificationofletterid');

		$id_realisasi=$this->createidrealisasikpi();

		$data=array(
			'id_realisasi'=>$id_realisasi,
			'id_karyawan'=>$this->input->post('id_karyawan'),
			'id_kategori'=>$this->input->post('id_kategori'),
			'id_bulan'=>$this->input->post('id_bulan'),
			'id_tahun'=>$this->input->post('id_tahun'),
			'id_supervisor'=>$this->input->post('id_supervisor'),
			'skor_akhir'=>$this->input->post('skor_akhir'),
			'enableflag'=>'0',
			'userid' => $this->session->userdata("name")
		);

		$this->realisasikpi->save($data);

		//add disposisi
		$this->realisasikpi->saveKpi($id_realisasi);

		$this->realisasikpi->deleteAllTemp();

		redirect('c_officer/realisasikpi');
	}

	function edit(){
		$id= $this->uri->segment(4);
		$id_realisasi= $this->uri->segment(5);
		$id_karyawan = $_SESSION['id_karyawan'];
		$data['record']=  $this->db->get_where('t_realisasi',array('id'=> $id))->row_array();
		$data['kpi']=$this->db->get_where('m_kpikaryawan',array('enableflag'=> '0', 'id_karyawan'=> $_SESSION['id_karyawan']))->result();
		$data['bulan']=$this->db->get_where('m_bulan',array('enableflag'=> '0'))->result();
		$data['tahun']=$this->db->get_where('m_tahun',array('enableflag'=> '0'))->result();
		$data['karyawan']=$this->db->get_where('m_karyawan',array('enableflag'=> '0'))->result();
		$data['kategori']=$this->db->get_where('m_kategori',array('enableflag'=> '0'))->result();

		//add for disposisi
		$data['detail']=$this->realisasikpi->viewKpiDetail($id_realisasi)->result();

		$this->realisasikpi->deleteAllTemp();

		$this->load->view('v_officer/v_realisasikpi_edit',$data);
	}

	function update(){
		    $id=$this->input->post('id');
		    $id_realisasi=$this->input->post('id_realisasi');
			$id_karyawan=$this->input->post('id_karyawan');
			$id_kategori=$this->input->post('id_kategori');
			$id_bulan=$this->input->post('id_bulan');
			$id_tahun=$this->input->post('id_tahun');
			$id_supervisor=$this->input->post('id_supervisor');
			$skor_akhir=$this->input->post('skor_akhir');
			$enableflag=$this->input->post('enableflag');

		$this->realisasikpi->update($id,$id_realisasi,$id_karyawan,$id_kategori,$id_bulan,$id_tahun,$id_supervisor,$skor_akhir,$enableflag);

		//add disposisi
		$this->realisasikpi->saveKpi($id_realisasi);

		$this->realisasikpi->deleteAllTemp();

		redirect('c_officer/realisasikpi');
	}

	// function updateStatus($id){
	// 	$status='4';

	// 	$this->realisasikpi->updateStatus($id,$status);

	// 	echo "<script>
	// 		alert('Surat Keluar Berhasil di Update');
	// 		window.location.href='../../../c_transaction/realisasikpi';
	// 		</script>";	
	// }

	//add for disposisi
	function getKPI(){
	    if (isset($_GET['term'])){
	      $q = strtolower($_GET['term']);
	      $this->realisasikpi->getKPI($q);
	    }
	}

	function viewKPI(){
		$data['tmp']=$this->realisasikpi->viewKPI()->result();
		$this->load->view('v_officer/v_realisasikpi_temp',$data);
	}

	function delTemp(){
		$kode=$this->input->post('kode');
		$this->realisasikpi->delTemp($kode);
	}

	function addKpi(){
		$nama_kpi=$this->input->post('nama_kpi');
		$obj=$this->input->post('obj');
		$waktu=$this->input->post('waktu');
		$realisasi=$this->input->post('realisasi');
		$id_kpi=$this->realisasikpi->getIdkpi($nama_kpi,$obj,$waktu,$realisasi);

		$cek=$this->realisasikpi->cekTmpKpi($nama_kpi);

		if($cek->num_rows()<1){
			$info=array(
				'id_kpi'=>$id_kpi,
				'nama_kpi'=>$this->input->post('nama_kpi'),
				'obj'=>$this->input->post('obj'),
				'waktu'=>$this->input->post('waktu'),
				'realisasi'=>$this->input->post('realisasi'),
				'key_id'=>$this->session->userdata('key_id')
				);
			$this->realisasikpi->saveTemp($info);
		}
	}

	function delDetail(){
		$kode=$this->input->post('kode');
		$this->realisasikpi->delDetail($kode);
	}
}