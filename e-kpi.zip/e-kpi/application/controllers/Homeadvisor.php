<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Homeadvisor extends CI_Controller {

	function __construct(){
		parent::__construct();
		$this->load->model('m_master/m_homeadvisor','rebu');
	}

	public function index(){

		$data['periode']=$this->db->get_where('m_subparameter',array('enableflag'=> '0','id_parameter'=> 'PM0004'))->result();
		$data['project']=$this->db->get_where('m_subparameter',array('enableflag'=> '0','id_parameter'=> 'PM0005'))->result();
		$data['cluster']=$this->db->get_where('m_subparameter',array('enableflag'=> '0','id_parameter'=> 'PM0006'))->result();
		$data['team']=$this->db->get_where('m_subparameter',array('enableflag'=> '0','id_parameter'=> 'PM0007'))->result();
		$data['sourcesha']=$this->db->get_where('m_subparameter',array('enableflag'=> '0','id_parameter'=> 'PM0015'))->result();
		$data['sourcesmarcomm']=$this->db->get_where('m_subparameter',array('enableflag'=> '0','id_parameter'=> 'PM0016'))->result();
		$data['karyawan']=$this->db->get_where('m_karyawan',array('enableflag'=> '0','id_unit'=> 'U0007'))->result();
		$data['tidakprospek']=$this->db->get_where('m_subparameter',array('enableflag'=> '0','id_parameter'=> 'PM0010'))->result();
		$data['sosialmedia']=$this->db->get_where('m_subparameter',array('enableflag'=> '0','id_parameter'=> 'PM0011'))->result();
		$data['alasanpembatalan']=$this->db->get_where('m_subparameter',array('enableflag'=> '0','id_parameter'=> 'PM0012'))->result();
		$data['detailpembatalan']=$this->db->get_where('m_subparameter',array('enableflag'=> '0','id_parameter'=> 'PM0013'))->result();
		$data['masagaransi']=$this->db->get_where('m_subparameter',array('enableflag'=> '0','id_parameter'=> 'PM0014'))->result();
		
		$data['pic']=$this->db->get_where('m_pic',array('enableflag'=> '0'))->result();
		$this->load->view('v_homeadvisor',$data);
		
	}

	public function ajax_list()
	{
		$this->load->helper('url');

		$list = $this->rebu->get_datatables();
		$data = array();
		$no = $_POST['start'];
		foreach ($list as $rebu) {
			$no++;
			$row = array();
			$row[] = $no;
			$row[] = $rebu->nama_karyawan;
			$row[] = $rebu->nama_section;
			$row[] = $rebu->nama_jabatan;
			$row[] = '<center><a class="btn btn-sm btn-primary" href="rebu/edit/'.$rebu->id_karyawan.'" title="Edit"><i class="glyphicon glyphicon-pencil"></i></a>
			<a class="btn btn-sm btn-info" href="rebu/detail/'.$rebu->id_karyawan.'" title="Detail"><i class="glyphicon glyphicon-search"></i></a>
			<a class="btn btn-sm btn-danger" href="javascript:void(0)" title="Hapus" onclick="delete_kpi('."'".$rebu->id_karyawan."'".')"><i class="glyphicon glyphicon-trash"></i></a></center>';
			$data[] = $row;
		}

		$output = array(
						"draw" => $_POST['draw'],
						"recordsTotal" => $this->rebu->count_all(),
						"recordsFiltered" => $this->rebu->count_filtered(),
						"data" => $data,
				);
		//output to json format
		echo json_encode($output);
	}

	public function ajax_list_dashboard()
	{
		$this->load->helper('url');

		$list = $this->rebu->get_datatables();
		$data = array();
		$no = $_POST['start'];
		foreach ($list as $rebu) {
			$no++;
			$row = array();
			$row[] = $no;
			$row[] = $rebu->nama_departemen;
			$row[] = $rebu->nama_karyawan;
			$row[] = $rebu->nama_jabatan;
			$row[] = $rebu->nama_kpi;
			$row[] = $rebu->skor_akhir;
			
			//add html for action
			// $row[] = '<center><a class="btn btn-sm btn-primary" href="c_master/rebu/edit/'.$rebu->id_kpi.'" title="Edit"><i class="glyphicon glyphicon-pencil"></i></a></center>';
		
			$row[] = '<center><a class="btn btn-sm btn-primary" href="c_master/rebu/edit/'.$rebu->id_kpi.'" title="Edit"><i class="glyphicon glyphicon-pencil"></i></a>
			<a class="btn btn-sm btn-info" href="c_master/rebu/detail/'.$rebu->id_kpi.'" title="Detail"><i class="glyphicon glyphicon-search"></i></a></center>';
			$data[] = $row;
		}

		$output = array(
						"draw" => $_POST['draw'],
						"recordsTotal" => $this->rebu->count_all(),
						"recordsFiltered" => $this->rebu->count_filtered(),
						"data" => $data,
				);
		//output to json format 
		echo json_encode($output);
	}

	public function ajax_list_departement()
	{
		$this->load->helper('url');

		$list = $this->rebu->get_datatables();
		$data = array();
		$no = $_POST['start'];    
		foreach ($list as $rebu) {
			$no++;
			$row = array();
			$row[] = $no;
			$row[] = $rebu->nama_departemen;
			
		
			$row[] ='
			<div class="progress">
			<div class="progress-bar" role="progressbar" aria-valuenow="70" aria-valuemin="0" aria-valuemax="100" style="width:70%">
			  70%
			</div>
		  </div>';

			$row[] = '<center>
					<a class="btn btn-sm btn-info" href="c_departement/departement/detail/'.$rebu->id_departemen.'" title="Detail"><i class="glyphicon glyphicon-circle-arrow-right"></i></a>
					</center>';
			$data[] = $row;
		}

		$output = array(
						"draw" => $_POST['draw'],
						"recordsTotal" => $this->rebu->count_all(),
						"recordsFiltered" => $this->rebu->count_filtered(),
						"data" => $data,
				);
		//output to json format
		echo json_encode($output);
	}

	function add() { 
		//$data['tanggal_lahir']=date('Y-m-d');
		//$data['tanggal_masuk']=date('Y-m-d'); date format
		$data['unit']=$this->db->get_where('m_unit',array('enableflag'=> '0'))->result();
		$data['departemen']=$this->db->get_where('m_departemen',array('enableflag'=> '0'))->result();
		$data['section']=$this->db->get_where('m_section',array('enableflag'=> '0'))->result();
		$data['jabatan']=$this->db->get_where('m_jabatan',array('enableflag'=> '0'))->result();
		$data['pic']=$this->db->get_where('m_pic',array('enableflag'=> '0'))->result();
		
		$this->load->view('v_master/v_kpi_add',$data);
	}

	function save(){
		$infoHeader=array(
			'id_kpi'=>$this->input->post('id_kpi'),
			'id_unit'=>$this->input->post('id_unit'),
			'id_departemen'=>$this->input->post('id_departemen'),
			'id_section'=>$this->input->post('id_section'),  
			'id_jabatan'=>$this->input->post('id_jabatan'),
			'nama_kpi'=>$this->input->post('nama_kpi'),
			'perspective'=>$this->input->post('perspective'),
			'subkpi'=>$this->input->post('subkpi'),
			'parameter'=>$this->input->post('parameter'),
			'measurement'=>$this->input->post('measurement'),
			'sourcesdata'=>$this->input->post('sourcesdata'),
			'pic'=>$this->input->post('pic'),
			'enableflag'=>$this->input->post('enableflag'),
			'userid' => $this->session->userdata("name")
			);

		$this->rebu->save($infoHeader);

		redirect('c_master/rebu');
	}

	function edit(){
		$id= $this->uri->segment(4);
		$data['record']=  $this->db->get_where('m_kpi',array('id_kpi'=> $id))->row_array();
		$data['unit']=$this->db->get_where('m_unit',array('enableflag'=> '0'))->result();
		$data['departemen']=$this->db->get_where('m_departemen',array('enableflag'=> '0'))->result();
		$data['section']=$this->db->get_where('m_section',array('enableflag'=> '0'))->result();
		$data['jabatan']=$this->db->get_where('m_jabatan',array('enableflag'=> '0'))->result();
		$data['pic']=$this->db->get_where('m_pic',array('enableflag'=> '0'))->result();
		
		$this->load->view('v_master/v_kpi_edit',$data);
	}

	function detail(){
		$id= $this->uri->segment(4);
		$data['record']=  $this->db->get_where('m_kpi',array('id_kpi'=> $id))->row_array();
		$data['unit']=$this->db->get_where('m_unit',array('enableflag'=> '0'))->result();
		$data['departemen']=$this->db->get_where('m_departemen',array('enableflag'=> '0'))->result();
		$data['section']=$this->db->get_where('m_section',array('enableflag'=> '0'))->result();
		$data['jabatan']=$this->db->get_where('m_jabatan',array('enableflag'=> '0'))->result();
		$data['pic']=$this->db->get_where('m_pic',array('enableflag'=> '0'))->result();
		
		$this->load->view('v_master/v_kpi_detail',$data);
	}

	function update(){ 
		$id=$this->input->post('id');
		$id_kpi=$this->input->post('id_kpi'); 
		$id_unit=$this->input->post('id_unit');
		$id_departemen=$this->input->post('id_departemen');
		$id_section=$this->input->post('id_section');
		$id_jabatan=$this->input->post('id_jabatan');
		$nama_kpi=$this->input->post('nama_kpi');
		$perspective=$this->input->post('perspective');
		$subkpi=$this->input->post('subkpi');
		$parameter=$this->input->post('parameter');
		$measurement=$this->input->post('measurement');
		$sourcesdata=$this->input->post('sourcesdata');
		$pic=$this->input->post('pic');
		$enableflag=$this->input->post('enableflag');

		$this->rebu->update($id,$id_kpi,$id_unit,$id_departemen,$id_section,$id_jabatan,$nama_kpi,$perspective,$subkpi,
		$parameter,$measurement,$sourcesdata,$pic,$enableflag);

		redirect('c_master/rebu');
	}

	public function ajax_delete($id)
	{
		//delete file
		$rebu = $this->rebu->get_by_id($id);
		
		$this->rebu->delete_by_id($id);
		echo json_encode(array("status" => TRUE));
	}
	
}



