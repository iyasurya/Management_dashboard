<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Marketing extends CI_Controller {

	function __construct(){
		parent::__construct();
		$this->load->model('m_master/m_marketing','rebu');
	}

	public function index(){
		$this->load->view('v_marketing');
		
	}

	public function ajax_list()
	{
		$this->load->helper('url');

		$list = $this->rebu->get_datatables();
		$data = array();
		$no = $_POST['start'];
		foreach ($list as $rebu) {
			$no++;
			$row = array();
			$row[] = $no;
			if($rebu->attachement)
			$row[] = '<center><a href="'.base_url('upload/'.$rebu->attachement).'" target="_blank"><img src="'.base_url('upload/'.$rebu->attachement).'" class="img-responsive" width="50" height="50"/></a></center>';
		    else
			$row[] = '(No photo)';
			$row[] = $rebu->nama_karyawan;
			$row[] = $rebu->nama_jabatan;
			$row[] = $rebu->skor_akhir;
			if($rebu->skor_akhir == 3 || $rebu->skor_akhir == 4 || $rebu->skor_akhir == 5)
			$row[] = '<center>
			<a class="btn btn-sm btn-success" href="" title="Rock Star">
			<i class="glyphicon glyphicon-star"></i>
			<i class="glyphicon glyphicon-star"></i>
			<i class="glyphicon glyphicon-star"></i>
			<i class="glyphicon glyphicon-star"></i>
			<i class="glyphicon glyphicon-star"></i>
			</a></center>';
			else if($rebu->skor_akhir == 2)
			$row[] = '<center>
			<a class="btn btn-sm btn-warning" href="" title="Adequate">
			<i class="glyphicon glyphicon-star"></i>
			<i class="glyphicon glyphicon-star"></i>
			<i class="glyphicon glyphicon-star"></i>
			</a></center>';
			else
			$row[] = '<center>
			<a class="btn btn-sm btn-danger" href="" title="Need Helps">
			<i class="glyphicon glyphicon-star"></i>
			</a></center>';
			
			$data[] = $row;
		}

		$output = array(
						"draw" => $_POST['draw'],
						"recordsTotal" => $this->rebu->count_all(),
						"recordsFiltered" => $this->rebu->count_filtered(),
						"data" => $data,
				);
		//output to json format
		echo json_encode($output);
	}

	function detail(){
		$id= $this->uri->segment(4);
		$data['record']=  $this->db->get_where('m_kpi',array('id_kpi'=> $id))->row_array();
		$data['unit']=$this->db->get_where('m_unit',array('enableflag'=> '0'))->result();
		$data['departemen']=$this->db->get_where('m_departemen',array('enableflag'=> '0'))->result();
		$data['section']=$this->db->get_where('m_section',array('enableflag'=> '0'))->result();
		$data['jabatan']=$this->db->get_where('m_jabatan',array('enableflag'=> '0'))->result();
		$data['pic']=$this->db->get_where('m_pic',array('enableflag'=> '0'))->result();
		
		$this->load->view('v_master/v_kpi_detail',$data);
	}

	public function ajax_delete($id)
	{
		//delete file
		$rebu = $this->rebu->get_by_id($id);
		
		$this->rebu->delete_by_id($id);
		echo json_encode(array("status" => TRUE));
	}
	
}



