<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Outgoingletter extends CI_Controller {

	function __construct(){
		parent::__construct();
		$this->load->model('m_transaction/m_outgoingletter','outgoingletter');
	}

	public function index(){
		$this->load->view('v_transaction/v_outgoingletter');
	}

	public function ajax_list()
	{
		$this->load->helper('url');

		$list = $this->outgoingletter->get_datatables();
		$data = array();
		$no = $_POST['start'];
		foreach ($list as $outgoingletter) {
			$no++;
			$row = array();
			$row[] = $no;
			$row[] = $outgoingletter->referencenumber;			
			$row[] = $outgoingletter->classificationofletter;
			$row[] = $outgoingletter->dateofletter;
			$row[] = $outgoingletter->typeofletter;
			$row[] = $outgoingletter->title;
			$row[] = $outgoingletter->destinationofletter;

			if($outgoingletter->status =='4'){
			   $row[] = '<center><i class="glyphicon glyphicon-ok"></i></center>';
			}else{
			   $row[] = '<center><a class="btn btn-sm btn-primary" href="outgoingletter/edit/'.$outgoingletter->id.'/'.$outgoingletter->idoutgoingletter.'" title="Edit"><i class="glyphicon glyphicon-pencil"></i></a>
			   		<a class="btn btn-sm btn-warning" href="outgoingletter/updateStatus/'.$outgoingletter->id.'" title="Update Selesai"><i class="glyphicon glyphicon-ok"></i></a></center>';
			}
		
			$data[] = $row;
		}

		$output = array(
						"draw" => $_POST['draw'],
						"recordsTotal" => $this->outgoingletter->count_all(),
						"recordsFiltered" => $this->outgoingletter->count_filtered(),
						"data" => $data,
				);
		//output to json format
		echo json_encode($output);
	}

	function add() { 
		$data['dateofletter']=date('Y-m-d');
		$data['dateoftask']=date('Y-m-d');
		$data['record']=$this->db->get_where('m_typeofletter',array('enableflag'=> '0'))->result();
		$data['record2']=$this->db->get_where('m_classificationofletter',array('enableflag'=> '0','typeclassification'=> '2'))->result();

		$this->outgoingletter->deleteAllTemp();

		$this->load->view('v_transaction/v_outgoingletter_add',$data);
	}

	function createidoutgoingletter()   {
		$nowMonthYear = date('my');
		$this->db->select('RIGHT(t_outgoingletter.idoutgoingletter,10) as kode', FALSE);
		$this->db->order_by('idoutgoingletter','DESC');    
		$this->db->limit(1);    
	  $query = $this->db->get('t_outgoingletter');      //cek dulu apakah ada sudah ada kode di tabel.    
	  if($query->num_rows() <> 0){      
	   //jika kode ternyata sudah ada.      
	  	$data = $query->row();      
	  	$kode = intval($data->kode) + 1;    
	  }
	  else{      
	   //jika kode belum ada      
	  	$kode = 1;    
	  }
	  $kodemax = str_pad($kode, 10, "0", STR_PAD_LEFT);    
	  $kodejadi = "SK".$nowMonthYear.$kodemax; 
	  return $kodejadi;  
	}

	function createreferencenumber($classificationofletterid)   {
		$this->db->select('LEFT(t_outgoingletter.referencenumber,3) as kode', FALSE);
		$this->db->where('classificationofletterid',$classificationofletterid);
		$this->db->order_by('referencenumber','DESC');    
		$this->db->limit(1);    
	  $query = $this->db->get('t_outgoingletter');      //cek dulu apakah ada sudah ada kode di tabel.    
	  if($query->num_rows() <> 0){      
	   //jika kode ternyata sudah ada.      
	  	$data = $query->row();      
	  	$kode = intval($data->kode) + 1;    
	  }
	  else{      
	   //jika kode belum ada      
	  	$kode = 1;    
	  }
	  $kodemax = str_pad($kode, 3, "0", STR_PAD_LEFT);    
	  $kodejadi = $kodemax.'/-'.$classificationofletterid; 
	  return $kodejadi;  
	}

	function save(){
		$classificationofletterid=$this->input->post('classificationofletterid');

		$idoutgoingletter=$this->createidoutgoingletter();
		$referencenumber=$this->createreferencenumber($classificationofletterid);

		$data=array(
			'idoutgoingletter'=>$idoutgoingletter,
			'dateofletter'=>$this->input->post('dateofletter'),
			'referencenumber'=>$referencenumber,
			'typeofletterid'=>$this->input->post('typeofletterid'),
			'classificationofletterid'=>$this->input->post('classificationofletterid'),
			'title'=>$this->input->post('title'),
			'destinationofletter'=>$this->input->post('destinationofletter'),
			'time'=>$this->input->post('time'),
			'place'=>$this->input->post('place'),
			'dateoftask'=>$this->input->post('dateoftask'),
			'toletter'=>$this->input->post('toletter'),
			'sign'=>$this->input->post('sign'),
			'copyofletter'=>$this->input->post('copyofletter'),
			'description'=>$this->input->post('description'),
			'status'=>'0',
			'voidflag'=>'0',
			'userid' => $this->session->userdata("name")
		);

		$this->outgoingletter->save($data);

		//add disposisi
		$this->outgoingletter->saveDisposisi($idoutgoingletter);

		$this->outgoingletter->deleteAllTemp();

		redirect('c_transaction/outgoingletter');
	}

	function edit(){
		$id= $this->uri->segment(4);
		$idoutgoingletter= $this->uri->segment(5);
		$data['record']=  $this->db->get_where('t_outgoingletter',array('id'=> $id))->row_array();
		$data['record2']=$this->db->get_where('m_typeofletter',array('enableflag'=> '0'))->result();
		$data['record3']=$this->db->get_where('m_classificationofletter',array('enableflag'=> '0','typeclassification'=> '2'))->result();

		//add for disposisi
		$data['detail']=$this->outgoingletter->viewDisposisiDetail($idoutgoingletter)->result();

		$this->outgoingletter->deleteAllTemp();

		$this->load->view('v_transaction/v_outgoingletter_edit',$data);
	}

	function update(){
		$id=$this->input->post('id');
		$idoutgoingletter=$this->input->post('idoutgoingletter');

		$dateofletter=$this->input->post('dateofletter');
        $title=$this->input->post('title');
        $destinationofletter=$this->input->post('destinationofletter');
        $typeofletterid=$this->input->post('typeofletterid');
        $classificationofletterid=$this->input->post('classificationofletterid');
        $time=$this->input->post('time');
        $place=$this->input->post('place');
        $dateoftask=$this->input->post('dateoftask');
        $toletter=$this->input->post('toletter');
        $sign=$this->input->post('sign');
        $copyofletter=$this->input->post('copyofletter');
        $description=$this->input->post('description');
        $status=$this->input->post('status');
        $voidflag=$this->input->post('voidflag');

		$this->outgoingletter->update($id,$dateofletter,$title,$destinationofletter,$typeofletterid,$classificationofletterid,$time,$place,$dateoftask,$toletter,$sign,$copyofletter,$description,$status,$voidflag);

		//add disposisi
		$this->outgoingletter->saveDisposisi($idoutgoingletter);

		$this->outgoingletter->deleteAllTemp();

		redirect('c_transaction/outgoingletter');
	}

	function updateStatus($id){
		$status='4';

		$this->outgoingletter->updateStatus($id,$status);

		echo "<script>
			alert('Surat Keluar Berhasil di Update');
			window.location.href='../../../c_transaction/outgoingletter';
			</script>";	
	}

	//add for disposisi
	function getEmployee(){
	    if (isset($_GET['term'])){
	      $q = strtolower($_GET['term']);
	      $this->outgoingletter->getEmployee($q);
	    }
	}

	function viewDisposisi(){
		$data['tmp']=$this->outgoingletter->viewDisposisi()->result();
		$this->load->view('v_transaction/v_outgoingletter_temp',$data);
	}

	function delTemp(){
		$kode=$this->input->post('kode');
		$this->outgoingletter->delTemp($kode);
	}

	function addEmployee(){
		$employeename=$this->input->post('employeename');
		$idemployee=$this->outgoingletter->getIdemployee($employeename);

		$cek=$this->outgoingletter->cekTmpDisposisi($employeename);

		if($cek->num_rows()<1){
			$info=array(
				'employeeid'=>$idemployee,
				'employeename'=>$this->input->post('employeename'),
				'key_id'=>$this->session->userdata('key_id')
				);
			$this->outgoingletter->saveTemp($info);
		}
	}

	function delDetail(){
		$kode=$this->input->post('kode');
		$this->outgoingletter->delDetail($kode);
	}
}