<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Incomingletter extends CI_Controller {

	function __construct(){
		parent::__construct();
		$this->load->model('m_transaction/m_incomingletter','incomingletter');
	}

	public function index(){
		$this->load->view('v_transaction/v_incomingletter');
	}

	public function ajax_list()
	{
		$this->load->helper('url');

		$list = $this->incomingletter->get_datatables();
		$data = array();
		$no = $_POST['start'];
		foreach ($list as $incomingletter) {
			$no++;
			$row = array();
			$row[] = $no;
			if($incomingletter->attachement == ""){
				$row[] = $incomingletter->referencenumber;
			} else {
				$row[] = '<a href="../upload/'.$incomingletter->attachement.'" title="Tampil Lampiran" target="_blank">'.$incomingletter->referencenumber.'</a>';
			}
			
			$row[] = $incomingletter->classificationofletter;
			$row[] = $incomingletter->dateofletter;
			$row[] = $incomingletter->typeofletter;
			$row[] = $incomingletter->title;
			$row[] = $incomingletter->originofletter;

			if($incomingletter->status =='4'){
			   $row[] = '<center><i class="glyphicon glyphicon-ok"></i></center>';
			
			}else{
			   $row[] = '<center><a class="btn btn-sm btn-primary" href="incomingletter/edit/'.$incomingletter->id.'" title="Edit"><i class="glyphicon glyphicon-pencil"></i></a>
			   		<a class="btn btn-sm btn-warning" href="incomingletter/updateStatus/'.$incomingletter->id.'" title="Update Selesai"><i class="glyphicon glyphicon-ok"></i></a></center>';
			}
			//add html for action
			
		
			$data[] = $row;
		}

		$output = array(
						"draw" => $_POST['draw'],
						"recordsTotal" => $this->incomingletter->count_all(),
						"recordsFiltered" => $this->incomingletter->count_filtered(),
						"data" => $data,
				);
		//output to json format
		echo json_encode($output);
	}

	function add() { 
		$data['dateofletter']=date('Y-m-d');
		$data['record']=$this->db->get_where('m_typeofletter',array('enableflag'=> '0'))->result();
		$data['record2']=$this->db->get_where('m_classificationofletter',array('enableflag'=> '0','typeclassification'=> '2'))->result();
		$this->load->view('v_transaction/v_incomingletter_add',$data);
	}

	function createidincomingletter()   {
		$nowMonthYear = date('my');
		$this->db->select('RIGHT(t_incomingletter.idincomingletter,10) as kode', FALSE);
		$this->db->order_by('idincomingletter','DESC');    
		$this->db->limit(1);    
	  $query = $this->db->get('t_incomingletter');      //cek dulu apakah ada sudah ada kode di tabel.    
	  if($query->num_rows() <> 0){      
	   //jika kode ternyata sudah ada.      
	  	$data = $query->row();      
	  	$kode = intval($data->kode) + 1;    
	  }
	  else{      
	   //jika kode belum ada      
	  	$kode = 1;    
	  }
	  $kodemax = str_pad($kode, 10, "0", STR_PAD_LEFT);    
	  $kodejadi = "SM".$nowMonthYear.$kodemax; 
	  return $kodejadi;  
	}

	function createreferencenumber($classificationofletterid)   {
		$this->db->select('LEFT(t_incomingletter.referencenumber,3) as kode', FALSE);
		$this->db->where('classificationofletterid',$classificationofletterid);
		$this->db->order_by('referencenumber','DESC');    
		$this->db->limit(1);    
	  $query = $this->db->get('t_incomingletter');      //cek dulu apakah ada sudah ada kode di tabel.    
	  if($query->num_rows() <> 0){      
	   //jika kode ternyata sudah ada.      
	  	$data = $query->row();      
	  	$kode = intval($data->kode) + 1;    
	  }
	  else{      
	   //jika kode belum ada      
	  	$kode = 1;    
	  }
	  $kodemax = str_pad($kode, 3, "0", STR_PAD_LEFT);    
	  $kodejadi = $kodemax.'/-'.$classificationofletterid; 
	  return $kodejadi;  
	}

	function save(){
		    
		$config['upload_path'] = './upload/'; //path folder
	    $config['allowed_types'] = 'gif|jpg|png|jpeg|bmp|pdf|doc|docx'; //type yang dapat diakses bisa anda sesuaikan
	    $config['encrypt_name'] = TRUE; //nama yang terupload nantinya

	    $this->load->library('upload',$config);	

	    if(!empty($_FILES['attachement']['name'])){
	    	if(!$this->upload->do_upload('attachement')){
	    		$this->upload->display_errors();	
	    	}else{
	    		$classificationofletterid=$this->input->post('classificationofletterid');

				$idincomingletter=$this->createidincomingletter();
				$referencenumber=$this->createreferencenumber($classificationofletterid);

				$result = $this->upload->data();
				$data=array(
					'idincomingletter'=>$idincomingletter,
					'dateofletter'=>$this->input->post('dateofletter'),
					'referencenumber'=>$referencenumber,
					'typeofletterid'=>$this->input->post('typeofletterid'),
					'classificationofletterid'=>$this->input->post('classificationofletterid'),
					'title'=>$this->input->post('title'),
					'originofletter'=>$this->input->post('originofletter'),
					'description'=>$this->input->post('description'),
					'attachement'=>$result['file_name'],
					'status'=>'0',
					'voidflag'=>'0',
					'userid' => $this->session->userdata("name")
					);

				$this->incomingletter->save($data);

				echo "<script>
				alert('Surat Masuk Berhasil di Tambahkan');
				window.location.href='../../c_transaction/incomingletter';
				</script>";
				#redirect('c_transaction/incomingletter');
	    	}
		} else{
			$classificationofletterid=$this->input->post('classificationofletterid');

				$idincomingletter=$this->createidincomingletter();
				$referencenumber=$this->createreferencenumber($classificationofletterid);

				$result = $this->upload->data();
				$data=array(
					'idincomingletter'=>$idincomingletter,
					'dateofletter'=>$this->input->post('dateofletter'),
					'referencenumber'=>$referencenumber,
					'typeofletterid'=>$this->input->post('typeofletterid'),
					'classificationofletterid'=>$this->input->post('classificationofletterid'),
					'title'=>$this->input->post('title'),
					'originofletter'=>$this->input->post('originofletter'),
					'description'=>$this->input->post('description'),
					'attachement'=>'',
					'status'=>'0',
					'voidflag'=>'0',
					'userid' => $this->session->userdata("name")
					);

				$this->incomingletter->save($data);

				echo "<script>
				alert('Surat Masuk Berhasil di Tambahkan');
				window.location.href='../../c_transaction/incomingletter';
				</script>";
		}

    }

	function edit(){
		$id= $this->uri->segment(4);
		$data['record']=  $this->db->get_where('t_incomingletter',array('id'=> $id))->row_array();
		$data['record2']=$this->db->get_where('m_typeofletter',array('enableflag'=> '0'))->result();
		$data['record3']=$this->db->get_where('m_classificationofletter',array('enableflag'=> '0','typeclassification'=> '2'))->result();
		
		$data['disposisi']=$this->incomingletter->getDisposisi($id);

		$this->load->view('v_transaction/v_incomingletter_edit',$data);
	}

	function update(){
		
		$config['upload_path'] = './upload/'; //path folder
	    $config['allowed_types'] = 'gif|jpg|png|jpeg|bmp|pdf|doc|docx'; //type yang dapat diakses bisa anda sesuaikan
	    $config['encrypt_name'] = TRUE; //nama yang terupload nantinya

	    $this->load->library('upload',$config);	

	    if(!empty($_FILES['attachement']['name'])){
	    	if(!$this->upload->do_upload('attachement')){
	    		$this->upload->display_errors();	
	    	}else{
				$result = $this->upload->data();
				$attachementEdit=$this->input->post('attachement');

				$id=$this->input->post('id');
				$dateofletter=$this->input->post('dateofletter');
				$typeofletterid=$this->input->post('typeofletterid');
				$classificationofletterid=$this->input->post('classificationofletterid');
				$title=$this->input->post('title');
				$originofletter=$this->input->post('originofletter');
				$description=$this->input->post('description');

				if($attachementEdit == " "){
					$attachement=$this->input->post('attachementFix');
				}else{
					$attachement=$result['file_name'];
				}

				$status=$this->input->post('status');
				$voidflag=$this->input->post('voidflag');
				

				$this->incomingletter->update($id,$dateofletter,$typeofletterid,$classificationofletterid,$title,$originofletter,$description,$attachement,$status,$voidflag);

				echo "<script>
				alert('Surat Masuk Berhasil di Edit');
				window.location.href='../../c_transaction/incomingletter';
				</script>";
				#redirect('c_transaction/incomingletter');
	    	}
		}else{
			$result = $this->upload->data();
			
			$id=$this->input->post('id');
			$dateofletter=$this->input->post('dateofletter');
			$typeofletterid=$this->input->post('typeofletterid');
			$classificationofletterid=$this->input->post('classificationofletterid');
			$title=$this->input->post('title');
			$originofletter=$this->input->post('originofletter');
			$description=$this->input->post('description');
			$attachement=$this->input->post('attachementFix');
			$status=$this->input->post('status');
			$voidflag=$this->input->post('voidflag');


			$this->incomingletter->update($id,$dateofletter,$typeofletterid,$classificationofletterid,$title,$originofletter,$description,$attachement,$status,$voidflag);

			echo "<script>
			alert('Surat Masuk Berhasil di Edit');
			window.location.href='../../c_transaction/incomingletter';
			</script>";
				#redirect('c_transaction/incomingletter');
		}
	}

	function updateStatus($id){
		$status='4';

		$this->incomingletter->updateStatus($id,$status);

		echo "<script>
			alert('Surat Masuk Berhasil di Update');
			window.location.href='../../../c_transaction/incomingletter';
			</script>";	
	}
}