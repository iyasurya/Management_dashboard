<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Disposisi extends CI_Controller {

	function __construct(){
		parent::__construct();
		$this->load->model('m_transaction/m_disposisi','disposisi');
	}

	public function index(){
		$this->load->view('v_transaction/v_disposisi');
	}

	public function ajax_list()
	{
		$this->load->helper('url');

		$list = $this->disposisi->get_datatables();
		$data = array();
		$no = $_POST['start'];
		foreach ($list as $disposisi) {
			$no++;
			$row = array();
			$row[] = $no;
			if($disposisi->attachement == ""){
				$row[] = $disposisi->referencenumber;
			} else {
				$row[] = '<a href="../upload/'.$disposisi->attachement.'" title="Tampil Lampiran" target="_blank">'.$disposisi->referencenumber.'</a>';
			}
			
			$row[] = $disposisi->classificationofletter;
			$row[] = $disposisi->dateofletter;
			$row[] = $disposisi->typeofletter;
			$row[] = $disposisi->title;
			$row[] = $disposisi->originofletter;

			if($disposisi->status =='4' || $disposisi->status =='1'){
			   $row[] = '<center><i class="glyphicon glyphicon-ok"></i></center>';
			}else{
			   $row[] = '<center><a class="btn btn-sm btn-warning" href="disposisi/edit/'.$disposisi->idincomingletter.'" title="Disposisi"><i class="glyphicon glyphicon-hand-right"></i></a></center>';
			}
			//add html for action
			
		
			$data[] = $row;
		}

		$output = array(
						"draw" => $_POST['draw'],
						"recordsTotal" => $this->disposisi->count_all(),
						"recordsFiltered" => $this->disposisi->count_filtered(),
						"data" => $data,
				);
		//output to json format
		echo json_encode($output);
	}

	function edit(){
		$id= $this->uri->segment(4);
		$data['record']=  $this->db->get_where('t_incomingletter',array('idincomingletter'=> $id))->row_array();
		$data['typeofletter']= $this->disposisi->getTypeofletter($id);
		$data['classificationofletter']= $this->disposisi->getClassificationofletter($id);

		$this->disposisi->deleteAllTemp();
		
		$this->load->view('v_transaction/v_disposisi_edit',$data);
	}

	function save(){
		$idincomingletter=$this->input->post('idincomingletter');
		$status='1';

		$this->disposisi->saveDisposisi($idincomingletter);

		$this->disposisi->update($idincomingletter,$status);

		$this->disposisi->deleteAllTemp();

		redirect('c_transaction/incomingletter');		
	}

	function getEmployee(){
	    if (isset($_GET['term'])){
	      $q = strtolower($_GET['term']);
	      $this->disposisi->getEmployee($q);
	    }
	  }

	function addEmployee(){
		$employeename=$this->input->post('employeename');
		$idemployee=$this->disposisi->getIdemployee($employeename);

		$cek=$this->disposisi->cekTmpDisposisi($employeename);

		if($cek->num_rows()<1){
			$info=array(
				'employeeid'=>$idemployee,
				'employeename'=>$this->input->post('employeename'),
				'key_id'=>$this->session->userdata('key_id')
				);
			$this->disposisi->saveTemp($info);
		}
	}

	function viewDisposisi(){
		$data['tmp']=$this->disposisi->viewDisposisi()->result();
		$this->load->view('v_transaction/v_disposisi_temp',$data);
	}

	function delTemp(){
		$kode=$this->input->post('kode');
		$this->disposisi->delTemp($kode);
	}

	//add for dashboard
	public function ajax_list_disposisi()
	{
		$this->load->helper('url');

		$list = $this->disposisi->get_datatables_disposisi();
		$data = array();
		$no = $_POST['start'];
		foreach ($list as $disposisi) {
			$no++;
			$row = array();
			$row[] = $no;
			if($disposisi->attachement == ""){
				$row[] = $disposisi->referencenumber;
			} else {
				$row[] = '<a href="../upload/'.$disposisi->attachement.'" title="Tampil Lampiran" target="_blank">'.$disposisi->referencenumber.'</a>';
			}
			
			$row[] = $disposisi->classificationofletter;
			$row[] = $disposisi->dateofletter;
			$row[] = $disposisi->typeofletter;
			$row[] = $disposisi->title;
			$row[] = $disposisi->originofletter;

			if($disposisi->status =='4' || $disposisi->status =='1'){
			   $row[] = '<center><i class="glyphicon glyphicon-ok"></i></center>';
			}else{
			   $row[] = '<center><a class="btn btn-sm btn-warning" href="c_transaction/disposisi/edit/'.$disposisi->idincomingletter.'" title="Disposisi"><i class="glyphicon glyphicon-hand-right"></i></a></center>';
			}
			//add html for action
			
		
			$data[] = $row;
		}

		$output = array(
						"draw" => $_POST['draw'],
						"recordsTotal" => $this->disposisi->count_all_disposisi(),
						"recordsFiltered" => $this->disposisi->count_filtered_disposisi(),
						"data" => $data,
				);
		//output to json format
		echo json_encode($output);
	}
}