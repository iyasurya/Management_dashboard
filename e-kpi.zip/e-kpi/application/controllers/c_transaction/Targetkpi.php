<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Targetkpi extends CI_Controller {

	function __construct(){
		parent::__construct();
		$this->load->model('m_transaction/m_targetkpi','targetkpi');
	}

	public function index(){
		$this->load->view('v_transaction/v_targetkpi');
	}

	public function ajax_list()
	{
		$this->load->helper('url');

		$list = $this->targetkpi->get_datatables();
		$data = array();
		$no = $_POST['start'];
		foreach ($list as $targetkpi) {
			$no++;
			$row = array();
			$row[] = $no;
			$row[] = $targetkpi->id_target;
			$row[] = $targetkpi->nama_kpi;
			$row[] = $targetkpi->nama_bulan;
			$row[] = $targetkpi->nama_tahun;
			$row[] = $targetkpi->target_kpi;
			$row[] = $targetkpi->unit_pengukuran;
			$row[] = $targetkpi->bobot_kpi;

			
			$row[] = '<center><a class="btn btn-sm btn-primary" href="targetkpi/edit/'.$targetkpi->id.'" title="Edit"><i class="glyphicon glyphicon-pencil"></i></a></center>';
			
			//add html for action
			
		
			$data[] = $row;
		}

		$output = array(
						"draw" => $_POST['draw'],
						"recordsTotal" => $this->targetkpi->count_all(),
						"recordsFiltered" => $this->targetkpi->count_filtered(),
						"data" => $data,
				);
		//output to json format
		echo json_encode($output);
	}

	function add() { 
		$data['kodejadi']=$this->createidtargetkpi();
		$data['kpi']=$this->db->get_where('m_kpi',array('enableflag'=> '0'))->result();
		$data['bulan']=$this->db->get_where('m_bulan',array('enableflag'=> '0'))->result();
		$data['tahun']=$this->db->get_where('m_tahun',array('enableflag'=> '0'))->result();
		$data['record']=$this->db->get_where('m_typeofletter',array('enableflag'=> '0'))->result();
		$data['kode']=date('Y-m-d');
		$data['record2']=$this->db->get_where('m_classificationofletter',array('enableflag'=> '0','typeclassification'=> '2'))->result();

		$this->load->view('v_transaction/v_targetkpi_add',$data);
	}

	function createidtargetkpi()   {
		$nowMonthYear = date('my');
		$this->db->select('RIGHT(t_target.id_target,4) as kode', FALSE);
		$this->db->order_by('id_target','DESC');    
		$this->db->limit(1);    
	  $query = $this->db->get('t_target');      //cek dulu apakah ada sudah ada kode di tabel.    
	  if($query->num_rows() <> 0){      
	   //jika kode ternyata sudah ada.      
	  	$data = $query->row();      
	  	$kode = intval($data->kode) + 1;    
	  }
	  else{      
	   //jika kode belum ada      
	  	$kode = 1;    
	  }
	  $kodemax = str_pad($kode, 4, "0", STR_PAD_LEFT);    
	//  $kodejadi = "TG".$nowMonthYear.$kodemax; 
	  $kodejadi = "TG".$kodemax; 
	  return $kodejadi;  
	}

	function createreferencenumber($classificationofletterid)   {
		$this->db->select('LEFT(t_targetkpi.referencenumber,3) as kode', FALSE);
		$this->db->where('classificationofletterid',$classificationofletterid);
		$this->db->order_by('referencenumber','DESC');    
		$this->db->limit(1);    
	  $query = $this->db->get('t_targetkpi');      //cek dulu apakah ada sudah ada kode di tabel.    
	  if($query->num_rows() <> 0){      
	   //jika kode ternyata sudah ada.      
	  	$data = $query->row();      
	  	$kode = intval($data->kode) + 1;    
	  }
	  else{      
	   //jika kode belum ada      
	  	$kode = 1;    
	  }
	  $kodemax = str_pad($kode, 3, "0", STR_PAD_LEFT);    
	  $kodejadi = $kodemax.'/-'.$classificationofletterid; 
	  return $kodejadi;  
	}

	function save(){
		    
		//$config['upload_path'] = './upload/'; //path folder
	   // $config['allowed_types'] = 'gif|jpg|png|jpeg|bmp|pdf|doc|docx'; //type yang dapat diakses bisa anda sesuaikan
	    //$config['encrypt_name'] = TRUE; //nama yang terupload nantinya

	   // $this->load->library('upload',$config);	

	 
			  //  $classificationofletterid=$this->input->post('classificationofletterid');

				$id_target=$this->createidtargetkpi();
				//$referencenumber=$this->createreferencenumber($classificationofletterid);

				//$result = $this->upload->data();
				$data=array(
					'id_target'=>$id_target,
					'id_kpi'=>$this->input->post('id_kpi'),
					'id_bulan'=>$this->input->post('id_bulan'),
					'id_tahun'=>$this->input->post('id_tahun'),
					'target_kpi'=>$this->input->post('target_kpi'),
					'unit_pengukuran'=>$this->input->post('unit_pengukuran'),
					'bobot_kpi'=>$this->input->post('bobot_kpi'),
					'enableflag'=>'0',
					'userid' => $this->session->userdata("name")
					);

				$this->targetkpi->save($data);

				echo "<script>
				alert('Target KPI Berhasil di Tambahkan');
				window.location.href='../../c_transaction/targetkpi';
				</script>";
		

    }

	function edit(){
		$id= $this->uri->segment(4);
		$data['record']=  $this->db->get_where('t_target',array('id'=> $id))->row_array();
		$data['kpi']=$this->db->get_where('m_kpi',array('enableflag'=> '0'))->result();
		$data['bulan']=$this->db->get_where('m_bulan',array('enableflag'=> '0'))->result();
		$data['tahun']=$this->db->get_where('m_tahun',array('enableflag'=> '0'))->result();

		$this->load->view('v_transaction/v_targetkpi_edit',$data);
	}

	function update(){
		
			$id=$this->input->post('id');
			$id_target=$this->input->post('id_target');
			$id_bulan=$this->input->post('id_bulan');
			$id_tahun=$this->input->post('id_tahun');
			$target_kpi=$this->input->post('target_kpi');
			$unit_pengukuran=$this->input->post('unit_pengukuran');
			$bobot_kpi=$this->input->post('bobot_kpi');
			$enableflag=$this->input->post('enbaleflag');


			$this->targetkpi->update($id,$id_target,$id_bulan,$id_tahun,$target_kpi,$unit_pengukuran,$bobot_kpi,$enableflag);

			echo "<script>
			alert('Target Berhasil di Edit');
			window.location.href='../../c_transaction/targetkpi';
			</script>";
				#redirect('c_transaction/targetkpi');
		
	}

	function updateStatus($id){
		$status='4';

		$this->targetkpi->updateStatus($id,$status);

		echo "<script>
			alert('Surat Masuk Berhasil di Update');
			window.location.href='../../../c_transaction/targetkpi';
			</script>";	
	}
}