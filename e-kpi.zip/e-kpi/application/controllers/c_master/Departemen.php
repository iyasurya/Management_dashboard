<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Departemen extends CI_Controller {

	function __construct(){
		parent::__construct();
		$this->load->model('m_master/m_departemen','departemen');
	}

	public function index(){
		$this->load->view('v_master/v_departemen');
	}

	public function ajax_list()
	{
		$this->load->helper('url');

		$list = $this->departemen->get_datatables();
		$data = array();
		$no = $_POST['start'];
		foreach ($list as $departemen) {
			$no++;
			$row = array();
			$row[] = $no;
			$row[] = $departemen->id_departemen;
			$row[] = $departemen->nama_departemen;

			//add html for action
			$row[] = '<center><a class="btn btn-sm btn-primary" href="javascript:void(0)" title="Edit" onclick="edit_departemen('."'".$departemen->id_departemen."'".')"><i class="glyphicon glyphicon-pencil"></i></a>
				<a class="btn btn-sm btn-danger" href="javascript:void(0)" title="Hapus" onclick="delete_departemen('."'".$departemen->id_departemen."'".')"><i class="glyphicon glyphicon-trash"></i></a></center>';
		
			$data[] = $row;
		}

		$output = array(
						"draw" => $_POST['draw'],
						"recordsTotal" => $this->departemen->count_all(),
						"recordsFiltered" => $this->departemen->count_filtered(),
						"data" => $data,
				);
		//output to json format
		echo json_encode($output);
	}

	public function ajax_edit($id)
	{
		$data = $this->departemen->get_by_id($id);
		echo json_encode($data);
	}

	function buat_kode()   {
		$this->db->select('RIGHT(id_departemen,4) as kode', FALSE);
		$this->db->order_by('id_departemen','DESC');    
		$this->db->limit(1);    
	  $query = $this->db->get('m_departemen');      //cek dulu apakah ada sudah ada kode di tabel.    
	  if($query->num_rows() <> 0){      
	   //jika kode ternyata sudah ada.      
	  	$data = $query->row();      
	  	$kode = intval($data->kode) + 1;    
	  }
	  else{      
	   //jika kode belum ada      
	  	$kode = 1;    
	  }
	  $kodemax = str_pad($kode, 4, "0", STR_PAD_LEFT);    
	  $kodejadi = "D".$kodemax;    
	  return $kodejadi;  
	}

	public function ajax_add()
	{
		$this->_validate();
		$id_departemen=$this->buat_kode();

		$data = array(
				'id_departemen' => $id_departemen,
				'nama_departemen' => $this->input->post('nama_departemen'),
				'enableflag' => '0',
				'userid' => $this->session->userdata("name")
		);

		$insert = $this->departemen->save($data);

		echo json_encode(array("status" => TRUE));
	}

	public function ajax_update()
	{
		$this->_validate();

		$data = array(
				'nama_departemen' => $this->input->post('nama_departemen'),
			);

		$this->departemen->update(array('id_departemen' => $this->input->post('id_departemen')), $data);
		echo json_encode(array("status" => TRUE));
	}

	public function ajax_delete($id)
	{
		//delete file
		$departemen = $this->departemen->get_by_id($id);
		
		$this->departemen->delete_by_id($id);
		echo json_encode(array("status" => TRUE));
	}

	private function _validate()
	{
		$data = array();
		$data['error_string'] = array();
		$data['inputerror'] = array();
		$data['status'] = TRUE;

		if($this->input->post('nama_departemen') == '')
		{
			$data['inputerror'][] = 'nama_departemen';
			$data['error_string'][] = 'Nama Departemen Tidak Boleh Kosong';
			$data['status'] = FALSE;
		}
		if($data['status'] === FALSE)
		{
			echo json_encode($data);
			exit();
		}
	}
}