<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Kpikaryawan extends CI_Controller {

	function __construct(){
		parent::__construct();
		$this->load->model('m_master/m_kpikaryawan','kpikaryawan');
	}

	public function index(){
		$this->load->view('v_master/v_kpikaryawan');
	}

	public function ajax_list()
	{
		$this->load->helper('url');

		$list = $this->kpikaryawan->get_datatables();
		$data = array();
		$no = $_POST['start'];
		foreach ($list as $kpikaryawan) {
			$no++;
			$row = array();
			$row[] = $no;
			$row[] = $kpikaryawan->id_kpi;
			$row[] = $kpikaryawan->nama_karyawan;
			$row[] = $kpikaryawan->nama_kpi;
			$row[] = $kpikaryawan->bobot;
			$row[] = $kpikaryawan->nama_unit;
			$row[] = $kpikaryawan->nama_departemen;
			$row[] = $kpikaryawan->nama_section;
			$row[] = $kpikaryawan->nama_jabatan;
			$row[] = '<center><a class="btn btn-sm btn-primary" href="kpikaryawan/edit/'.$kpikaryawan->id.'" title="Edit"><i class="glyphicon glyphicon-pencil"></i></a>
			<a class="btn btn-sm btn-info" href="kpikaryawan/detail/'.$kpikaryawan->id.'" title="Detail"><i class="glyphicon glyphicon-search"></i></a>
			<a class="btn btn-sm btn-danger" href="javascript:void(0)" title="Hapus" onclick="delete_kpi('."'".$kpikaryawan->id_kpi."'".')"><i class="glyphicon glyphicon-trash"></i></a></center>';
			$data[] = $row;
		}

		$output = array(
						"draw" => $_POST['draw'],
						"recordsTotal" => $this->kpikaryawan->count_all(),
						"recordsFiltered" => $this->kpikaryawan->count_filtered(),
						"data" => $data,
				);
		//output to json format
		echo json_encode($output);
	}



	function add() { 
		//$data['tanggal_lahir']=date('Y-m-d');
		//$data['tanggal_masuk']=date('Y-m-d');
		$data['unit']=$this->db->get_where('m_unit',array('enableflag'=> '0'))->result();
		$data['departemen']=$this->db->get_where('m_departemen',array('enableflag'=> '0'))->result();
		$data['section']=$this->db->get_where('m_section',array('enableflag'=> '0'))->result();
		$data['jabatan']=$this->db->get_where('m_jabatan',array('enableflag'=> '0'))->result();
		$data['pic']=$this->db->get_where('m_pic',array('enableflag'=> '0'))->result();
		$data['kpikaryawan']=$this->db->get_where('m_kpi',array('enableflag'=> '0'))->result();
		$data['karyawan']=$this->db->get_where('m_karyawan',array('enableflag'=> '0'))->result();
		
		$this->load->view('v_master/v_kpikaryawan_add',$data);
	}

	function save(){
		$infoHeader=array(
			'id_kpi'=>$this->input->post('id_kpi'),
			'id_unit'=>$this->input->post('id_unit'),
			'id_departemen'=>$this->input->post('id_departemen'),
			'id_section'=>$this->input->post('id_section'),
			'id_jabatan'=>$this->input->post('id_jabatan'),
			'id_karyawan'=>$this->input->post('id_karyawan'),
			'nama_kpi'=>$this->input->post('nama_kpi'),
			'bobot'=>$this->input->post('bobot'),
			'perspective'=>$this->input->post('perspective'),
			'subkpi'=>$this->input->post('subkpi'),
			'parameter'=>$this->input->post('parameter'),
			'measurement'=>$this->input->post('measurement'),
			'sourcesdata'=>$this->input->post('sourcesdata'),
			'pic'=>$this->input->post('pic'),
			'enableflag'=>$this->input->post('enableflag'),
			'userid' => $this->session->userdata("name")
			);

		$this->kpikaryawan->save($infoHeader);

		redirect('c_master/kpikaryawan');
	}

	function edit(){
		$id= $this->uri->segment(4);
		$data['record']=  $this->db->get_where('m_kpikaryawan',array('id'=> $id))->row_array();
		$data['unit']=$this->db->get_where('m_unit',array('enableflag'=> '0'))->result();
		$data['departemen']=$this->db->get_where('m_departemen',array('enableflag'=> '0'))->result();
		$data['section']=$this->db->get_where('m_section',array('enableflag'=> '0'))->result();
		$data['jabatan']=$this->db->get_where('m_jabatan',array('enableflag'=> '0'))->result();
		$data['pic']=$this->db->get_where('m_pic',array('enableflag'=> '0'))->result();
		$data['karyawan']=$this->db->get_where('m_karyawan',array('enableflag'=> '0'))->result();
		$data['kpikaryawan']=$this->db->get_where('m_kpi',array('enableflag'=> '0'))->result();
		
		$this->load->view('v_master/v_kpikaryawan_edit',$data);
	}

	function detail(){
		$id= $this->uri->segment(4);
		$data['record']=  $this->db->get_where('m_kpikaryawan',array('id_kpi'=> $id))->row_array();
		$data['unit']=$this->db->get_where('m_unit',array('enableflag'=> '0'))->result();
		$data['departemen']=$this->db->get_where('m_departemen',array('enableflag'=> '0'))->result();
		$data['section']=$this->db->get_where('m_section',array('enableflag'=> '0'))->result();
		$data['jabatan']=$this->db->get_where('m_jabatan',array('enableflag'=> '0'))->result();
		$data['pic']=$this->db->get_where('m_pic',array('enableflag'=> '0'))->result();
		
		$this->load->view('v_master/v_kpikaryawan_detail',$data);
	}

	function update(){
		$id=$this->input->post('id');
		$id_kpi=$this->input->post('id_kpi');
		$id_unit=$this->input->post('id_unit');
		$id_departemen=$this->input->post('id_departemen');
		$id_section=$this->input->post('id_section');
		$id_jabatan=$this->input->post('id_jabatan');
		$id_karyawan=$this->input->post('id_karyawan');
		$nama_kpi=$this->input->post('nama_kpi');
		$bobot=$this->input->post('bobot');
		$perspective=$this->input->post('perspective');
		$subkpi=$this->input->post('subkpi');
		$parameter=$this->input->post('parameter');
		$measurement=$this->input->post('measurement');
		$sourcesdata=$this->input->post('sourcesdata');
		$pic=$this->input->post('pic');
		$enableflag=$this->input->post('enableflag');

		$this->kpikaryawan->update($id,$id_kpi,$id_unit,$id_departemen,$id_section,$id_jabatan,$id_karyawan,$nama_kpi,$bobot,$perspective,$subkpi,
		$parameter,$measurement,$sourcesdata,$pic,$enableflag);

		redirect('c_master/kpikaryawan');
	}

	public function ajax_delete($id)
	{
		//delete file
		$kpikaryawan = $this->kpikaryawan->get_by_id($id);
		
		$this->kpikaryawan->delete_by_id($id);
		echo json_encode(array("status" => TRUE));
	}
}