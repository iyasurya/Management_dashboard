<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Bulan extends CI_Controller {

	function __construct(){
		parent::__construct();
		$this->load->model('m_master/m_bulan','bulan');
	}

	public function index(){
		$this->load->view('v_master/v_bulan');
	}

	public function ajax_list()
	{
		$this->load->helper('url');

		$list = $this->bulan->get_datatables();
		$data = array();
		$no = $_POST['start'];
		foreach ($list as $bulan) {
			$no++;
			$row = array();
			$row[] = $no;
			$row[] = $bulan->id_bulan;
			$row[] = $bulan->nama_bulan;

			//add html for action
			$row[] = '<center><a class="btn btn-sm btn-primary" href="javascript:void(0)" title="Edit" onclick="edit_bulan('."'".$bulan->id_bulan."'".')"><i class="glyphicon glyphicon-pencil"></i></a>
				<a class="btn btn-sm btn-danger" href="javascript:void(0)" title="Hapus" onclick="delete_bulan('."'".$bulan->id_bulan."'".')"><i class="glyphicon glyphicon-trash"></i></a></center>';
		
			$data[] = $row;
		}

		$output = array(
						"draw" => $_POST['draw'],
						"recordsTotal" => $this->bulan->count_all(),
						"recordsFiltered" => $this->bulan->count_filtered(),
						"data" => $data,
				);
		//output to json format
		echo json_encode($output);
	}

	public function ajax_edit($id)
	{
		$data = $this->bulan->get_by_id($id);
		echo json_encode($data);
	}

	function buat_kode()   {
		$this->db->select('RIGHT(id_bulan,4) as kode', FALSE);
		$this->db->order_by('id_bulan','DESC');    
		$this->db->limit(1);    
	  $query = $this->db->get('m_bulan');      //cek dulu apakah ada sudah ada kode di tabel.    
	  if($query->num_rows() <> 0){      
	   //jika kode ternyata sudah ada.      
	  	$data = $query->row();      
	  	$kode = intval($data->kode) + 1;    
	  }
	  else{      
	   //jika kode belum ada      
	  	$kode = 1;    
	  }
	  $kodemax = str_pad($kode, 4, "0", STR_PAD_LEFT);    
	  $kodejadi = "B".$kodemax;    
	  return $kodejadi;  
	}

	public function ajax_add()
	{
		$this->_validate();
		$id_bulan=$this->buat_kode();

		$data = array(
				'id_bulan' => $id_bulan,
				'nama_bulan' => $this->input->post('nama_bulan'),
				'enableflag' => '0',
				'userid' => $this->session->userdata("name")
		);

		$insert = $this->bulan->save($data);

		echo json_encode(array("status" => TRUE));
	}

	public function ajax_update()
	{
		$this->_validate();

		$data = array(
				'nama_bulan' => $this->input->post('nama_bulan'),
			);

		$this->bulan->update(array('id_bulan' => $this->input->post('id_bulan')), $data);
		echo json_encode(array("status" => TRUE));
	}

	public function ajax_delete($id)
	{
		//delete file
		$bulan = $this->bulan->get_by_id($id);
		
		$this->bulan->delete_by_id($id);
		echo json_encode(array("status" => TRUE));
	}

	private function _validate()
	{
		$data = array();
		$data['error_string'] = array();
		$data['inputerror'] = array();
		$data['status'] = TRUE;

		if($this->input->post('nama_bulan') == '')
		{
			$data['inputerror'][] = 'nama_bulan';
			$data['error_string'][] = 'Nama Bulan Tidak Boleh Kosong';
			$data['status'] = FALSE;
		}
		if($data['status'] === FALSE)
		{
			echo json_encode($data);
			exit();
		}
	}
}