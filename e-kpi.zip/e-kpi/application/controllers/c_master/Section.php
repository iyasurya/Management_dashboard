<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Section extends CI_Controller {

	function __construct(){
		parent::__construct();
		$this->load->model('m_master/m_section','section');
	}

	public function index(){
		$this->load->view('v_master/v_section');
	}

	public function ajax_list()
	{
		$this->load->helper('url');

		$list = $this->section->get_datatables();
		$data = array();
		$no = $_POST['start'];
		foreach ($list as $section) {
			$no++;
			$row = array();
			$row[] = $no;
			$row[] = $section->id_section;
			$row[] = $section->nama_section;

			//add html for action
			$row[] = '<center><a class="btn btn-sm btn-primary" href="javascript:void(0)" title="Edit" onclick="edit_section('."'".$section->id_section."'".')"><i class="glyphicon glyphicon-pencil"></i></a>
				<a class="btn btn-sm btn-danger" href="javascript:void(0)" title="Hapus" onclick="delete_section('."'".$section->id_section."'".')"><i class="glyphicon glyphicon-trash"></i></a></center>';
		
			$data[] = $row;
		}

		$output = array(
						"draw" => $_POST['draw'],
						"recordsTotal" => $this->section->count_all(),
						"recordsFiltered" => $this->section->count_filtered(),
						"data" => $data,
				);
		//output to json format
		echo json_encode($output);
	}

	public function ajax_edit($id)
	{
		$data = $this->section->get_by_id($id);
		echo json_encode($data);
	}

	function buat_kode()   {
		$this->db->select('RIGHT(id_section,4) as kode', FALSE);
		$this->db->order_by('id_section','DESC');    
		$this->db->limit(1);    
	  $query = $this->db->get('m_section');      //cek dulu apakah ada sudah ada kode di tabel.    
	  if($query->num_rows() <> 0){      
	   //jika kode ternyata sudah ada.      
	  	$data = $query->row();      
	  	$kode = intval($data->kode) + 1;    
	  }
	  else{      
	   //jika kode belum ada      
	  	$kode = 1;    
	  }
	  $kodemax = str_pad($kode, 4, "0", STR_PAD_LEFT);    
	  $kodejadi = "S".$kodemax;    
	  return $kodejadi;  
	}

	public function ajax_add()
	{
		$this->_validate();
		$id_section=$this->buat_kode();

		$data = array(
				'id_section' => $id_section,
				'nama_section' => $this->input->post('nama_section'),
				'enableflag' => '0',
				'userid' => $this->session->userdata("name")
		);

		$insert = $this->section->save($data);

		echo json_encode(array("status" => TRUE));
	}

	public function ajax_update()
	{
		$this->_validate();

		$data = array(
				'nama_section' => $this->input->post('nama_section'),
			);

		$this->section->update(array('id_section' => $this->input->post('id_section')), $data);
		echo json_encode(array("status" => TRUE));
	}

	public function ajax_delete($id)
	{
		//delete file
		$section = $this->section->get_by_id($id);
		
		$this->section->delete_by_id($id);
		echo json_encode(array("status" => TRUE));
	}

	private function _validate()
	{
		$data = array();
		$data['error_string'] = array();
		$data['inputerror'] = array();
		$data['status'] = TRUE;

		if($this->input->post('nama_section') == '')
		{
			$data['inputerror'][] = 'nama_section';
			$data['error_string'][] = 'Nama Section Tidak Boleh Kosong';
			$data['status'] = FALSE;
		}
		if($data['status'] === FALSE)
		{
			echo json_encode($data);
			exit();
		}
	}
}