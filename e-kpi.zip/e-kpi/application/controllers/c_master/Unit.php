<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Unit extends CI_Controller {

	function __construct(){
		parent::__construct();
		$this->load->model('m_master/m_unit','unit');
	}

	public function index(){
		$this->load->view('v_master/v_unit');
	}

	public function ajax_list()
	{
		$this->load->helper('url');

		$list = $this->unit->get_datatables();
		$data = array();
		$no = $_POST['start'];
		foreach ($list as $unit) {
			$no++;
			$row = array();
			$row[] = $no;
			$row[] = $unit->id_unit;
			$row[] = $unit->abbreviation;
			$row[] = $unit->nama_unit;

			//add html for action
			$row[] = '<center><a class="btn btn-sm btn-primary" href="javascript:void(0)" title="Edit" onclick="edit_unit('."'".$unit->id_unit."'".')"><i class="glyphicon glyphicon-pencil"></i></a>
				<a class="btn btn-sm btn-danger" href="javascript:void(0)" title="Hapus" onclick="delete_unit('."'".$unit->id_unit."'".')"><i class="glyphicon glyphicon-trash"></i></a></center>';
		
			$data[] = $row;
		}

		$output = array(
						"draw" => $_POST['draw'],
						"recordsTotal" => $this->unit->count_all(),
						"recordsFiltered" => $this->unit->count_filtered(),
						"data" => $data,
				);
		//output to json format
		echo json_encode($output);
	}

	public function ajax_edit($id)
	{
		$data = $this->unit->get_by_id($id);
		echo json_encode($data);
	}

	function buat_kode()   {
		$this->db->select('RIGHT(id_unit,4) as kode', FALSE);
		$this->db->order_by('id_unit','DESC');    
		$this->db->limit(1);    
	  $query = $this->db->get('m_unit');      //cek dulu apakah ada sudah ada kode di tabel.    
	  if($query->num_rows() <> 0){      
	   //jika kode ternyata sudah ada.      
	  	$data = $query->row();      
	  	$kode = intval($data->kode) + 1;    
	  }
	  else{      
	   //jika kode belum ada      
	  	$kode = 1;    
	  }
	  $kodemax = str_pad($kode, 4, "0", STR_PAD_LEFT);    
	  $kodejadi = "U".$kodemax;    
	  return $kodejadi;  
	}

	public function ajax_add()
	{
		$this->_validate();
		$id_unit=$this->buat_kode();

		$data = array(
				'id_unit' => $id_unit,
				'abbreviation' => $this->input->post('abbreviation'),
				'nama_unit' => $this->input->post('nama_unit'),
				'enableflag' => '0',
				'userid' => $this->session->userdata("name")
		);

		$insert = $this->unit->save($data);

		echo json_encode(array("status" => TRUE));
	}

	public function ajax_update()
	{
		$this->_validate();

		$data = array(
				'nama_unit' => $this->input->post('nama_unit'),
			);

		$this->unit->update(array('id_unit' => $this->input->post('id_unit')), $data);
		echo json_encode(array("status" => TRUE));
	}

	public function ajax_delete($id)
	{
		//delete file
		$unit = $this->unit->get_by_id($id);
		
		$this->unit->delete_by_id($id);
		echo json_encode(array("status" => TRUE));
	}

	private function _validate()
	{
		$data = array();
		$data['error_string'] = array();
		$data['inputerror'] = array();
		$data['status'] = TRUE;

		if($this->input->post('abbreviation') == '')
		{
			$data['inputerror'][] = 'abbreviation';
			$data['error_string'][] = 'Abbreviation Tidak Boleh Kosong';
			$data['status'] = FALSE;
		}
		if($this->input->post('nama_unit') == '')
		{
			$data['inputerror'][] = 'nama_unit';
			$data['error_string'][] = 'Nama Unit Tidak Boleh Kosong';
			$data['status'] = FALSE;
		}
		if($data['status'] === FALSE)
		{
			echo json_encode($data);
			exit();
		}
	}
}