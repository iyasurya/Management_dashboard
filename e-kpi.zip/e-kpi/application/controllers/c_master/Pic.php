<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class PIC extends CI_Controller {

	function __construct(){
		parent::__construct();
		$this->load->model('m_master/m_pic','pic');
	}

	public function index(){
		$this->load->view('v_master/v_pic');
	}

	public function ajax_list()
	{
		$this->load->helper('url');

		$list = $this->pic->get_datatables();
		$data = array();
		$no = $_POST['start'];
		foreach ($list as $pic) {
			$no++;
			$row = array();
			$row[] = $no;
			$row[] = $pic->id_pic;
			$row[] = $pic->id_karyawan;
			$row[] = $pic->nama_pic;
			
			//add html for action
			//$row[] = '<center><a class="btn btn-sm btn-primary" href="pic/edit/'.$pic->id_pic.'" title="Edit"><i class="glyphicon glyphicon-pencil"></i></a></center>';
			$row[] = '<center><a class="btn btn-sm btn-primary" href="pic/edit/'.$pic->id_pic.'" title="Edit"><i class="glyphicon glyphicon-pencil"></i></a>
			<a class="btn btn-sm btn-info" href="pic/detail/'.$pic->id_pic.'" title="Detail"><i class="glyphicon glyphicon-search"></i></a>
			<a class="btn btn-sm btn-danger" href="javascript:void(0)" title="Hapus" onclick="delete_pic('."'".$pic->id_pic."'".')"><i class="glyphicon glyphicon-trash"></i></a></center>';
			
			$data[] = $row;
		}

		$output = array(
						"draw" => $_POST['draw'],
						"recordsTotal" => $this->pic->count_all(),
						"recordsFiltered" => $this->pic->count_filtered(),
						"data" => $data,
				);
		//output to json format
		echo json_encode($output);
	}

	function add() { 
		//$data['tanggal_lahir']=date('Y-m-d');
		//$data['tanggal_masuk']=date('Y-m-d');
		//$data['departemen']=$this->db->get_where('m_departemen',array('enableflag'=> '0'))->result();
		//$data['jabatan']=$this->db->get_where('m_jabatan',array('enableflag'=> '0'))->result();
		$data['pic']=$this->db->get_where('m_karyawan',array('enableflag'=> '0'))->result();
		
		$this->load->view('v_master/v_pic_add',$data);
	}

	function save(){
		$infoHeader=array(
			'id_pic'=>$this->input->post('id_pic'),
			'id_karyawan' => $this->input->post('id_karyawan'),
			'nama_pic' => $this->input->post('nama_pic'),
			'enableflag'=>$this->input->post('enableflag'),
			'userid' => $this->session->userdata("name")
			);

		$this->pic->save($infoHeader);

		redirect('c_master/pic');
	}

	function edit(){
		$id= $this->uri->segment(4);
		$data['record']=  $this->db->get_where('m_pic',array('id_pic'=> $id))->row_array();
		//$data['departemen']=$this->db->get_where('m_departemen',array('enableflag'=> '0'))->result();
		//$data['jabatan']=$this->db->get_where('m_jabatan',array('enableflag'=> '0'))->result();
		$data['pic']=$this->db->get_where('m_karyawan',array('enableflag'=> '0'))->result();
		
		$this->load->view('v_master/v_pic_edit',$data);
	}

	function detail(){
		$id= $this->uri->segment(4);
		$data['record']=  $this->db->get_where('m_pic',array('id_pic'=> $id))->row_array();
		//$data['departemen']=$this->db->get_where('m_departemen',array('enableflag'=> '0'))->result();
		//$data['jabatan']=$this->db->get_where('m_jabatan',array('enableflag'=> '0'))->result();
		$data['pic']=$this->db->get_where('m_karyawan',array('enableflag'=> '0'))->result();
		
		$this->load->view('v_master/v_pic_detail',$data);
	}

	function update(){
		$id=$this->input->post('id');
		$id_pic=$this->input->post('id_pic');
		$id_karyawan=$this->input->post('id_karyawan');
		$nama_pic=$this->input->post('nama_pic');
		$enableflag=$this->input->post('enableflag');

		$this->pic->update($id,$id_pic,$id_karyawan,$nama_pic,$enableflag);

		redirect('c_master/pic');
	}

	public function ajax_delete($id)
	{
		//delete file
		$pic = $this->pic->get_by_id($id);
		
		$this->pic->delete_by_id($id);
		echo json_encode(array("status" => TRUE));
	}
}