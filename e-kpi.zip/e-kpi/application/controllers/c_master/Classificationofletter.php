<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Classificationofletter extends CI_Controller {

	function __construct(){
		parent::__construct();
		$this->load->model('m_master/m_classificationofletter','classificationofletter');
	}

	public function index(){
		$data['classificationofletterid']=$this->db->get_where('m_classificationofletter',array('typeclassification'=> '1'))->result();
		$this->load->view('v_master/v_classificationofletter',$data);
	}

	public function ajax_list()
	{
		$this->load->helper('url');

		$list = $this->classificationofletter->get_datatables();
		$data = array();
		$no = $_POST['start'];
		foreach ($list as $classificationofletter) {
			$no++;
			$row = array();
			$row[] = $no;
			$row[] = $classificationofletter->idclassificationofletter;
			$row[] = $classificationofletter->classificationofletter;
			$row[] = $classificationofletter->typeclassification;

			//add html for action
			$row[] = '<center><a class="btn btn-sm btn-primary" href="javascript:void(0)" title="Edit" onclick="edit_classificationofletter('."'".$classificationofletter->id."'".')"><i class="glyphicon glyphicon-pencil"></i></a>
				<a class="btn btn-sm btn-danger" href="javascript:void(0)" title="Hapus" onclick="delete_classificationofletter('."'".$classificationofletter->id."'".')"><i class="glyphicon glyphicon-trash"></i></a></center>';
		
			$data[] = $row;
		}

		$output = array(
						"draw" => $_POST['draw'],
						"recordsTotal" => $this->classificationofletter->count_all(),
						"recordsFiltered" => $this->classificationofletter->count_filtered(),
						"data" => $data,
				);
		//output to json format
		echo json_encode($output);
	}

	public function ajax_add()
	{
		$this->_validate();
		
		$data = array(
				'idclassificationofletter' => $this->input->post('idclassificationofletter'),
				'classificationofletter' => $this->input->post('classificationofletter'),
				'typeclassification' =>$this->input->post('typeclassification'),
				'classificationofletterid' =>$this->input->post('classificationofletterid'),
				'enableflag' =>'0',
				'userid' => $this->session->userdata("name")
		);

		$insert = $this->classificationofletter->save($data);

		echo json_encode(array("status" => TRUE));
	}

	public function ajax_edit($id)
	{
		$data = $this->classificationofletter->get_by_id($id);
		echo json_encode($data);
	}

	public function ajax_update()
	{
		$this->_validate();

		$data = array(
				'idclassificationofletter' => $this->input->post('idclassificationofletter'),
				'classificationofletter' => $this->input->post('classificationofletter'),
				'typeclassification' =>$this->input->post('typeclassification'),
				'classificationofletterid' =>$this->input->post('classificationofletterid'),
				'enableflag' =>'0',
				'userid' => $this->session->userdata("name")
			);

		$this->classificationofletter->update(array('id' => $this->input->post('id')), $data);
		echo json_encode(array("status" => TRUE));
	}

	public function ajax_delete($id)
	{
		//delete file
		$classificationofletter = $this->classificationofletter->get_by_id($id);
		
		$this->classificationofletter->delete_by_id($id);
		echo json_encode(array("status" => TRUE));
	}

	private function _validate()
	{
		$data = array();
		$data['error_string'] = array();
		$data['inputerror'] = array();
		$data['status'] = TRUE;

		if($this->input->post('classificationofletter') == '')
		{
			$data['inputerror'][] = 'classificationofletter';
			$data['error_string'][] = 'Klasifikasi Surat Tidak Boleh Kosong';
			$data['status'] = FALSE;
		}
		if($this->input->post('idclassificationofletter') == '')
		{
			$data['inputerror'][] = 'idclassificationofletter';
			$data['error_string'][] = 'ID Klasifikasi Surat Tidak Boleh Kosong';
			$data['status'] = FALSE;
		}
		if($data['status'] === FALSE)
		{
			echo json_encode($data);
			exit();
		}
	}
}