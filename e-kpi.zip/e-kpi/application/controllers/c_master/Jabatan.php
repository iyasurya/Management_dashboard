<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Jabatan extends CI_Controller {

	function __construct(){
		parent::__construct();
		$this->load->model('m_master/m_jabatan','jabatan');
	}

	public function index(){
		$this->load->view('v_master/v_jabatan');
	}

	public function ajax_list()
	{
		$this->load->helper('url');

		$list = $this->jabatan->get_datatables();
		$data = array();
		$no = $_POST['start'];
		foreach ($list as $jabatan) {
			$no++;
			$row = array();
			$row[] = $no;
			$row[] = $jabatan->id_jabatan;
			$row[] = $jabatan->nama_jabatan;

			//add html for action
			$row[] = '<center><a class="btn btn-sm btn-primary" href="javascript:void(0)" title="Edit" onclick="edit_jabatan('."'".$jabatan->id_jabatan."'".')"><i class="glyphicon glyphicon-pencil"></i></a>
				<a class="btn btn-sm btn-danger" href="javascript:void(0)" title="Hapus" onclick="delete_jabatan('."'".$jabatan->id_jabatan."'".')"><i class="glyphicon glyphicon-trash"></i></a></center>';
		
			$data[] = $row;
		}

		$output = array(
						"draw" => $_POST['draw'],
						"recordsTotal" => $this->jabatan->count_all(),
						"recordsFiltered" => $this->jabatan->count_filtered(),
						"data" => $data,
				);
		//output to json format
		echo json_encode($output);
	}

	public function ajax_edit($id)
	{
		$data = $this->jabatan->get_by_id($id);
		echo json_encode($data);
	}

	function buat_kode()   {
		$this->db->select('RIGHT(id_jabatan,4) as kode', FALSE);
		$this->db->order_by('id_jabatan','DESC');    
		$this->db->limit(1);    
	  $query = $this->db->get('m_jabatan');      //cek dulu apakah ada sudah ada kode di tabel.    
	  if($query->num_rows() <> 0){      
	   //jika kode ternyata sudah ada.      
	  	$data = $query->row();      
	  	$kode = intval($data->kode) + 1;    
	  }
	  else{      
	   //jika kode belum ada      
	  	$kode = 1;    
	  }
	  $kodemax = str_pad($kode, 4, "0", STR_PAD_LEFT);    
	  $kodejadi = "J".$kodemax;    
	  return $kodejadi;  
	}

	public function ajax_add()
	{
		$this->_validate();
		$id_jabatan=$this->buat_kode();

		$data = array(
				'id_jabatan' => $id_jabatan,
				'nama_jabatan' => $this->input->post('nama_jabatan'),
				'enableflag' => '0',
				'userid' => $this->session->userdata("name")
		);

		$insert = $this->jabatan->save($data);

		echo json_encode(array("status" => TRUE));
	}

	public function ajax_update()
	{
		$this->_validate();

		$data = array(
				'nama_jabatan' => $this->input->post('nama_jabatan'),
			);

		$this->jabatan->update(array('id_jabatan' => $this->input->post('id_jabatan')), $data);
		echo json_encode(array("status" => TRUE));
	}

	public function ajax_delete($id)
	{
		//delete file
		$jabatan = $this->jabatan->get_by_id($id);
		
		$this->jabatan->delete_by_id($id);
		echo json_encode(array("status" => TRUE));
	}

	private function _validate()
	{
		$data = array();
		$data['error_string'] = array();
		$data['inputerror'] = array();
		$data['status'] = TRUE;

		if($this->input->post('nama_jabatan') == '')
		{
			$data['inputerror'][] = 'nama_jabatan';
			$data['error_string'][] = 'Nama Jabatan Tidak Boleh Kosong';
			$data['status'] = FALSE;
		}
		if($data['status'] === FALSE)
		{
			echo json_encode($data);
			exit();
		}
	}
}