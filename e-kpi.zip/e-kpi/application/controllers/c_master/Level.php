<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Level extends CI_Controller {

	function __construct(){
		parent::__construct();
		$this->load->model('m_master/m_level','level');
	}

	public function index(){
		$this->load->view('v_master/v_level');
	}

	public function ajax_list()
	{
		$this->load->helper('url');

		$list = $this->level->get_datatables();
		$data = array();
		$no = $_POST['start'];
		foreach ($list as $level) {
			$no++;
			$row = array();
			$row[] = $no;
			$row[] = $level->id_level;
			$row[] = $level->nama_level;

			//add html for action
			$row[] = '<center><a class="btn btn-sm btn-primary" href="javascript:void(0)" title="Edit" onclick="edit_level('."'".$level->id_level."'".')"><i class="glyphicon glyphicon-pencil"></i></a>
				<a class="btn btn-sm btn-danger" href="javascript:void(0)" title="Hapus" onclick="delete_level('."'".$level->id_level."'".')"><i class="glyphicon glyphicon-trash"></i></a></center>';
		
			$data[] = $row;
		}

		$output = array(
						"draw" => $_POST['draw'],
						"recordsTotal" => $this->level->count_all(),
						"recordsFiltered" => $this->level->count_filtered(),
						"data" => $data,
				);
		//output to json format
		echo json_encode($output);
	}

	public function ajax_edit($id)
	{
		$data = $this->level->get_by_id($id);
		echo json_encode($data);
	}

	function buat_kode()   {
		$this->db->select('RIGHT(id_level,4) as kode', FALSE);
		$this->db->order_by('id_level','DESC');    
		$this->db->limit(1);    
	  $query = $this->db->get('m_level');      //cek dulu apakah ada sudah ada kode di tabel.    
	  if($query->num_rows() <> 0){      
	   //jika kode ternyata sudah ada.      
	  	$data = $query->row();      
	  	$kode = intval($data->kode) + 1;    
	  }
	  else{      
	   //jika kode belum ada      
	  	$kode = 1;    
	  }
	  $kodemax = str_pad($kode, 4, "0", STR_PAD_LEFT);    
	  $kodejadi = "L".$kodemax;    
	  return $kodejadi;  
	}

	public function ajax_add()
	{
		$this->_validate();
		$id_level=$this->buat_kode();

		$data = array(
				'id_level' => $id_level,
				'nama_level' => $this->input->post('nama_level'),
				'enableflag' => '0',
				'userid' => $this->session->userdata("name")
		);

		$insert = $this->level->save($data);

		echo json_encode(array("status" => TRUE));
	}

	public function ajax_update()
	{
		$this->_validate();

		$data = array(
				'nama_level' => $this->input->post('nama_level'),
			);

		$this->level->update(array('id_level' => $this->input->post('id_level')), $data);
		echo json_encode(array("status" => TRUE));
	}

	public function ajax_delete($id)
	{
		//delete file
		$level = $this->level->get_by_id($id);
		
		$this->level->delete_by_id($id);
		echo json_encode(array("status" => TRUE));
	}

	private function _validate()
	{
		$data = array();
		$data['error_string'] = array();
		$data['inputerror'] = array();
		$data['status'] = TRUE;

		
		if($this->input->post('nama_level') == '')
		{
			$data['inputerror'][] = 'nama_level';
			$data['error_string'][] = 'Nama Level Tidak Boleh Kosong';
			$data['status'] = FALSE;
		}
		if($data['status'] === FALSE)
		{
			echo json_encode($data);
			exit();
		}
	}
}