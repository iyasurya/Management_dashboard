<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Masterkpi extends CI_Controller {

	function __construct(){
		parent::__construct();
		$this->load->model('m_master/m_masterkpi','masterkpi');
	}

	public function index(){
		$this->load->view('v_master/v_masterkpi');
	}

	public function ajax_list()
	{
		$this->load->helper('url');

		$list = $this->masterkpi->get_datatables();
		$data = array();
		$no = $_POST['start'];
		foreach ($list as $masterkpi) {
			$no++;
			$row = array();
			$row[] = $no;
			$row[] = $masterkpi->perspective;
			$row[] = $masterkpi->idkpi;
			$row[] = $masterkpi->kpiname;
			$row[] = $masterkpi->subkpi;
			$row[] = $masterkpi->parameter;
			$row[] = $masterkpi->measurement;
			$row[] = $masterkpi->sourcesdata;
			$row[] = $masterkpi->pic;
			
			//add html for action
			//$row[] = '<center><a class="btn btn-sm btn-primary" href="masterkpi/edit/'.$masterkpi->idkpi.'" title="Edit"><i class="glyphicon glyphicon-pencil"></i></a></center>';
			
			$row[] = '<center><a class="btn btn-sm btn-primary" href="javascript:void(0)" title="Edit" onclick="edit_masterkpi('."'".$masterkpi->id."'".')"><i class="glyphicon glyphicon-pencil"></i></a>
				<a class="btn btn-sm btn-danger" href="javascript:void(0)" title="Hapus" onclick="delete_masterkpi('."'".$masterkpi->id."'".')"><i class="glyphicon glyphicon-trash"></i></a></center>';
		
			$data[] = $row;
		}

		$output = array(
						"draw" => $_POST['draw'],
						"recordsTotal" => $this->masterkpi->count_all(),
						"recordsFiltered" => $this->masterkpi->count_filtered(),
						"data" => $data,
				);
		//output to json format
		echo json_encode($output);
	}

	function add() { 
		
		$this->load->view('v_master/v_masterkpi_add');
	}

	function save(){
		$infoHeader=array(
			'perspective'=>$this->input->post('perspective'),
			'idkpi'=>$this->input->post('idkpi'),
			'kpiname'=>$this->input->post('kpiname'),
			'subkpi'=>$this->input->post('subkpi'),
			'parameter'=>$this->input->post('parameter'),
			'measurement'=>$this->input->post('measurement'),
			'sourcesdata'=>$this->input->post('sourcesdata'),
			'pic'=>$this->input->post('pic'),
			'enableflag'=>$this->input->post('enableflag'),
			'userid' => $this->session->userdata("name")
			);

		$this->masterkpi->save($infoHeader);

		redirect('c_master/masterkpi');
	}

	function edit(){
		$id= $this->uri->segment(4);
		$data['record']=  $this->db->get_where('m_kpi',array('idkpi'=> $id))->row_array();
		
		$this->load->view('v_master/v_master_edit',$data);
	}

	function update(){
		$id=$this->input->post('id');
		$perspective=$this->input->post('perspective');
		$idkpi=$this->input->post('idkpi');
		$kpiname=$this->input->post('kpiname');
		$subkpi=$this->input->post('subkpi');
		$parameter=$this->input->post('parameter');
		$measurement=$this->input->post('measurement');
		$sourcesdata=$this->input->post('sourcesdata');
		$pic=$this->input->post('pic');
		$enableflag=$this->input->post('enableflag');

		$this->masterkpi->update($id,$perspective,$idkpi,$kpiname,$subkpi,$parameter,$measurement,$sourcesdata,$pic,$enableflag);

		redirect('c_master/masterkpi');
	}
}