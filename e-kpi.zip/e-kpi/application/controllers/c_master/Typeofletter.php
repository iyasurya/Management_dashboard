<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Typeofletter extends CI_Controller {

	function __construct(){
		parent::__construct();
		$this->load->model('m_master/m_typeofletter','typeofletter');
	}

	public function index(){
		$this->load->view('v_master/v_typeofletter');
	}

	public function ajax_list()
	{
		$this->load->helper('url');

		$list = $this->typeofletter->get_datatables();
		$data = array();
		$no = $_POST['start'];
		foreach ($list as $typeofletter) {
			$no++;
			$row = array();
			$row[] = $no;
			$row[] = $typeofletter->idtypeofletter;
			$row[] = $typeofletter->typeofletter;

			//add html for action
			$row[] = '<center><a class="btn btn-sm btn-primary" href="javascript:void(0)" title="Edit" onclick="edit_typeofletter('."'".$typeofletter->idtypeofletter."'".')"><i class="glyphicon glyphicon-pencil"></i></a>
				<a class="btn btn-sm btn-danger" href="javascript:void(0)" title="Hapus" onclick="delete_typeoflatter('."'".$typeofletter->idtypeofletter."'".')"><i class="glyphicon glyphicon-trash"></i></a></center>';
		
			$data[] = $row;
		}

		$output = array(
						"draw" => $_POST['draw'],
						"recordsTotal" => $this->typeofletter->count_all(),
						"recordsFiltered" => $this->typeofletter->count_filtered(),
						"data" => $data,
				);
		//output to json format
		echo json_encode($output);
	}

	public function ajax_edit($id)
	{
		$data = $this->typeofletter->get_by_id($id);
		echo json_encode($data);
	}

	function buat_kode()   {
		$this->db->select('RIGHT(idtypeofletter,4) as kode', FALSE);
		$this->db->order_by('idtypeofletter','DESC');    
		$this->db->limit(1);    
	  $query = $this->db->get('m_typeofletter');      //cek dulu apakah ada sudah ada kode di tabel.    
	  if($query->num_rows() <> 0){      
	   //jika kode ternyata sudah ada.      
	  	$data = $query->row();      
	  	$kode = intval($data->kode) + 1;    
	  }
	  else{      
	   //jika kode belum ada      
	  	$kode = 1;    
	  }
	  $kodemax = str_pad($kode, 4, "0", STR_PAD_LEFT);    
	  $kodejadi = "T".$kodemax;    
	  return $kodejadi;  
	}

	public function ajax_add()
	{
		$this->_validate();
		$idtypeofletter=$this->buat_kode();

		$data = array(
				'idtypeofletter' => $idtypeofletter,
				'typeofletter' => $this->input->post('typeofletter'),
				'enableflag' => '0',
				'userid' => $this->session->userdata("name")
		);

		$insert = $this->typeofletter->save($data);

		echo json_encode(array("status" => TRUE));
	}

	public function ajax_update()
	{
		$this->_validate();

		$data = array(
				'typeofletter' => $this->input->post('typeofletter'),
			);

		$this->typeofletter->update(array('idtypeofletter' => $this->input->post('idtypeofletter')), $data);
		echo json_encode(array("status" => TRUE));
	}

	public function ajax_delete($id)
	{
		//delete file
		$typeofletter = $this->typeofletter->get_by_id($id);
		
		$this->typeofletter->delete_by_id($id);
		echo json_encode(array("status" => TRUE));
	}

	private function _validate()
	{
		$data = array();
		$data['error_string'] = array();
		$data['inputerror'] = array();
		$data['status'] = TRUE;

		if($this->input->post('typeofletter') == '')
		{
			$data['inputerror'][] = 'typeofletter';
			$data['error_string'][] = 'Jenis Surat Tidak Boleh Kosong';
			$data['status'] = FALSE;
		}
		if($data['status'] === FALSE)
		{
			echo json_encode($data);
			exit();
		}
	}
}