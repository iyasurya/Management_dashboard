<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller {

	function __construct(){
		parent::__construct();
		$this->load->model('m_master/m_user','user');
	}

	public function index(){
		$this->load->view('v_master/v_user');
	}

	public function ajax_list()
	{
		$this->load->helper('url');

		$list = $this->user->get_datatables();
		$data = array();
		$no = $_POST['start'];
		foreach ($list as $user) {
			$no++;
			$row = array();
			$row[] = $no;
			$row[] = $user->id_user;
			$row[] = $user->id_karyawan;
			$row[] = $user->name;
			$row[] = $user->username;
			$row[] = $user->jobdescription;
			if ($user->menu == 'superadmin') 
			$row[] = 'Super Admin';
			else if ($user->menu == 'admin') 
			$row[] = 'Admin';
			else if ($user->menu == 'bod') 
			$row[] = 'BOD';
			else if ($user->menu == 'unithead') 
			$row[] = 'Unit Head';
			else if ($user->menu == 'depthead') 
			$row[] = 'Dept. Head';
			else if ($user->menu == 'sectionhead') 
			$row[] = 'Section Head';
			else if ($user->menu == 'officer') 
			$row[] = 'Officer';
			else
			$row[] = $user->menu;
			if($user->attachement)
				$row[] = '<a href="'.base_url('upload/'.$user->attachement).'" target="_blank"><img src="'.base_url('upload/'.$user->attachement).'" class="img-responsive" width="32" height="80"/></a>';
			else
				$row[] = '(No photo)';
			
			//add html for action
			//$row[] = '<center><a class="btn btn-sm btn-primary" href="user/edit/'.$user->id_user.'" title="Edit"><i class="glyphicon glyphicon-pencil"></i></a></center>';
			$row[] = '<center><a class="btn btn-sm btn-primary" href="user/edit/'.$user->id_user.'" title="Edit"><i class="glyphicon glyphicon-pencil"></i></a>
			<a class="btn btn-sm btn-info" href="user/detail/'.$user->id_user.'" title="Detail"><i class="glyphicon glyphicon-search"></i></a>
			<a class="btn btn-sm btn-danger" href="javascript:void(0)" title="Hapus" onclick="delete_user('."'".$user->id_user."'".')"><i class="glyphicon glyphicon-trash"></i></a></center>';
			
			$data[] = $row;
		}

		$output = array(
						"draw" => $_POST['draw'],
						"recordsTotal" => $this->user->count_all(),
						"recordsFiltered" => $this->user->count_filtered(),
						"data" => $data,
				);
		//output to json format
		echo json_encode($output);
	}

	function add() { 
		$data['pic']=$this->db->get_where('m_karyawan',array('enableflag'=> '0'))->result();
		$data['unit']=$this->db->get_where('m_unit',array('enableflag'=> '0'))->result();
		
		$this->load->view('v_master/v_user_add',$data);
	}



	function save(){
		    
		$config['upload_path'] = './upload/'; //path folder
		$config['allowed_types'] = 'gif|jpg|png|jpeg'; //type yang dapat diakses bisa anda sesuaikan
	    //$config['allowed_types'] = 'gif|jpg|png|jpeg|bmp|pdf|doc|docx'; //type yang dapat diakses bisa anda sesuaikan
	    $config['encrypt_name'] = TRUE; //nama yang terupload nantinya
		//$config['max_size']             = 100; //set max size allowed in Kilobyte
        //$config['max_width']            = 1000; // set max width image allowed
        //$config['max_height']           = 1000; // set max height allowed
        //$config['file_name']            = round(microtime(true) * 1000); //just milisecond timestamp fot unique name

	    $this->load->library('upload',$config);	

	    if(!empty($_FILES['attachement']['name'])){
	    	if(!$this->upload->do_upload('attachement')){
	    		$this->upload->display_errors();	
	    	}else{
				$id_user=$this->createiduser();

				$result = $this->upload->data();
				$data=array(
					'id_user'=>$id_user,
					'id_karyawan' => $this->input->post('id_karyawan'),
					'name' => $this->input->post('name'),
					'username' => $this->input->post('username'),
					//'password' => $this->input->post('password'),
					'password' => password_hash($this->input->post('password'), PASSWORD_DEFAULT),
					'jobdescription' => $this->input->post('jobdescription'),
					'menu' => $this->input->post('menu'),
					'key_id' => $this->input->post('key_id'),
					'attachement'=>$result['file_name'],
					'enableflag'=>$this->input->post('enableflag'),
					'userid' => $this->session->userdata("name")
					);

				$this->user->save($data);

				echo "<script>
				alert('User Berhasil di Tambahkan');
				window.location.href='../../c_master/user';
				</script>";
				#redirect('c_transaction/incomingletter');
	    	}
		} else{

			$id_user=$this->createiduser();

				$result = $this->upload->data();
				$data=array(
					'id_user'=>$id_user,
					'id_karyawan'=>$this->input->post('id_karyawan'),
					'name'=>$this->input->post('name'),
					'username'=>$this->input->post('username'),
					'password' => password_hash($this->input->post('password'), PASSWORD_DEFAULT),
					'jobdescription' => $this->input->post('jobdescription'),
					'menu' => $this->input->post('menu'),
					'key_id' => $this->input->post('key_id'),
					'attachement'=>'',
					'enableflag'=>'0',
					'userid' => $this->session->userdata("name")
					);

				$this->user->save($data);

				echo "<script>
				alert('User Berhasil di Tambahkan');
				window.location.href='../../c_master/user';
				</script>";
		}

    }

	function createiduser()   {
		$nowMonthYear = date('my');
		$this->db->select('RIGHT(m_user.id_user,4) as kode', FALSE);
		$this->db->order_by('id_user','DESC');    
		$this->db->limit(1);    
	  $query = $this->db->get('m_user');      //cek dulu apakah ada sudah ada kode di tabel.    
	  if($query->num_rows() <> 0){      
	   //jika kode ternyata sudah ada.      
	  	$data = $query->row();      
	  	$kode = intval($data->kode) + 1;    
	  }
	  else{      
	   //jika kode belum ada      
	  	$kode = 1;    
	  }
	  $kodemax = str_pad($kode, 4, "0", STR_PAD_LEFT);    
	  $kodejadi = "US".$kodemax; 
	  return $kodejadi;  
	}



	function edit(){
		$id= $this->uri->segment(4);
		$data['record']=  $this->db->get_where('m_user',array('id_user'=> $id))->row_array();
		$data['pic']=$this->db->get_where('m_karyawan',array('enableflag'=> '0'))->result();
		$data['unit']=$this->db->get_where('m_unit',array('enableflag'=> '0'))->result();
		
		$this->load->view('v_master/v_user_edit',$data);
	}

	function detail(){
		$id= $this->uri->segment(4);
		$data['record']=  $this->db->get_where('m_user',array('id_user'=> $id))->row_array();
		$data['pic']=$this->db->get_where('m_karyawan',array('enableflag'=> '0'))->result();
		$data['unit']=$this->db->get_where('m_unit',array('enableflag'=> '0'))->result();

		$this->load->view('v_master/v_user_detail',$data);
	}

	function update(){
		
		$config['upload_path'] = './upload/'; //path folder
		$config['allowed_types'] = 'gif|jpg|png|jpeg'; //type yang dapat diakses bisa anda sesuaikan
	   // $config['allowed_types'] = 'gif|jpg|png|jpeg|bmp|pdf|doc|docx'; //type yang dapat diakses bisa anda sesuaikan
	    $config['encrypt_name'] = TRUE; //nama yang terupload nantinya
		//$config['max_size']             = 100; //set max size allowed in Kilobyte
        // $config['max_width']            = 1000; // set max width image allowed
        // $config['max_height']           = 1000; // set max height allowed
        //$config['file_name']            = round(microtime(true) * 1000); //just milisecond timestamp fot unique name

	    $this->load->library('upload',$config);	

	    if(!empty($_FILES['attachement']['name'])){
	    	if(!$this->upload->do_upload('attachement')){
	    		$this->upload->display_errors();	
	    	}else{
				$result = $this->upload->data();
				$attachementEdit=$this->input->post('attachement');

				$id=$this->input->post('id');
				$id_user=$this->input->post('id_user');
				$id_karyawan=$this->input->post('id_karyawan');
				$name=$this->input->post('name');
				$username=$this->input->post('username');
				$password=$this->input->post('password');
				//$password= password_hash($this->input->post('password'), PASSWORD_DEFAULT);
				$jobdescription=$this->input->post('jobdescription');
				$menu=$this->input->post('menu');
				$key_id=$this->input->post('key_id');

				if($attachementEdit == " "){
					$attachement=$this->input->post('attachementFix');
				}else{
					$attachement=$result['file_name'];
				}

				$enableflag=$this->input->post('enableflag');
				

				$this->user->update($id,$id_user,$id_karyawan,$name,$username,$password,$jobdescription,$menu,$key_id,$attachement,$enableflag);

				echo "<script>
				alert('User Berhasil di Edit');
				window.location.href='../../c_master/user';
				</script>";
				#redirect('c_master/user');
	    	}
		}else{
			$result = $this->upload->data();
			
			$id=$this->input->post('id');
			$id_user=$this->input->post('id_user');
			$id_karyawan=$this->input->post('id_karyawan');
			$name=$this->input->post('name');
			$username=$this->input->post('username');
			$password=$this->input->post('password');
			//$password= password_hash($this->input->post('password'), PASSWORD_DEFAULT);
			$jobdescription=$this->input->post('jobdescription');
			$menu=$this->input->post('menu');
			$key_id=$this->input->post('key_id');
			$attachement=$this->input->post('attachement');
			$enableflag=$this->input->post('enableflag');


			$this->user->update($id,$id_user,$id_karyawan,$name,$username,$password,$jobdescription,$menu,$key_id,$attachement,$enableflag);

			echo "<script>
			alert('User Berhasil di Edit');
			window.location.href='../../c_master/user';
			</script>";
				#redirect('c_master/user');
		}
	}

	
	public function ajax_delete($id)
	{
		//delete file
		$user = $this->user->get_by_id($id);
		if(file_exists('upload/'.$user->attachement) && $user->attachement)
			unlink('upload/'.$user->attachement);
		
		$this->user->delete_by_id($id);
		echo json_encode(array("status" => TRUE));
	}
}