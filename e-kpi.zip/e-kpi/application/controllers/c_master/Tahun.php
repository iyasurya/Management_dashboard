<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Tahun extends CI_Controller {

	function __construct(){
		parent::__construct();
		$this->load->model('m_master/m_tahun','tahun');
	}

	public function index(){
		$this->load->view('v_master/v_tahun');
	}

	public function ajax_list()
	{
		$this->load->helper('url');

		$list = $this->tahun->get_datatables();
		$data = array();
		$no = $_POST['start'];
		foreach ($list as $tahun) {
			$no++;
			$row = array();
			$row[] = $no;
			$row[] = $tahun->id_tahun;
			$row[] = $tahun->nama_tahun;

			//add html for action
			$row[] = '<center><a class="btn btn-sm btn-primary" href="javascript:void(0)" title="Edit" onclick="edit_tahun('."'".$tahun->id_tahun."'".')"><i class="glyphicon glyphicon-pencil"></i></a>
				<a class="btn btn-sm btn-danger" href="javascript:void(0)" title="Hapus" onclick="delete_tahun('."'".$tahun->id_tahun."'".')"><i class="glyphicon glyphicon-trash"></i></a></center>';
		
			$data[] = $row;
		}

		$output = array(
						"draw" => $_POST['draw'],
						"recordsTotal" => $this->tahun->count_all(),
						"recordsFiltered" => $this->tahun->count_filtered(),
						"data" => $data,
				);
		//output to json format
		echo json_encode($output);
	}

	public function ajax_edit($id)
	{
		$data = $this->tahun->get_by_id($id);
		echo json_encode($data);
	}

	function buat_kode()   {
		$this->db->select('RIGHT(id_tahun,4) as kode', FALSE);
		$this->db->order_by('id_tahun','DESC');    
		$this->db->limit(1);    
	  $query = $this->db->get('m_tahun');      //cek dulu apakah ada sudah ada kode di tabel.    
	  if($query->num_rows() <> 0){      
	   //jika kode ternyata sudah ada.      
	  	$data = $query->row();      
	  	$kode = intval($data->kode) + 1;    
	  }
	  else{      
	   //jika kode belum ada      
	  	$kode = 1;    
	  }
	  $kodemax = str_pad($kode, 4, "0", STR_PAD_LEFT);    
	  $kodejadi = "T".$kodemax;    
	  return $kodejadi;  
	}

	public function ajax_add()
	{
		$this->_validate();
		$id_tahun=$this->buat_kode();

		$data = array(
				'id_tahun' => $id_tahun,
				'nama_tahun' => $this->input->post('nama_tahun'),
				'enableflag' => '0',
				'userid' => $this->session->userdata("name")
		);

		$insert = $this->tahun->save($data);

		echo json_encode(array("status" => TRUE));
	}

	public function ajax_update()
	{
		$this->_validate();

		$data = array(
				'nama_tahun' => $this->input->post('nama_tahun'),
			);

		$this->tahun->update(array('id_tahun' => $this->input->post('id_tahun')), $data);
		echo json_encode(array("status" => TRUE));
	}

	public function ajax_delete($id)
	{
		//delete file
		$tahun = $this->tahun->get_by_id($id);
		
		$this->tahun->delete_by_id($id);
		echo json_encode(array("status" => TRUE));
	}

	private function _validate()
	{
		$data = array();
		$data['error_string'] = array();
		$data['inputerror'] = array();
		$data['status'] = TRUE;

		if($this->input->post('nama_tahun') == '')
		{
			$data['inputerror'][] = 'nama_tahun';
			$data['error_string'][] = 'Nama Tahun Tidak Boleh Kosong';
			$data['status'] = FALSE;
		}
		if($data['status'] === FALSE)
		{
			echo json_encode($data);
			exit();
		}
	}
}