<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Chartprospectofnewcustomer extends CI_Controller {

	function __construct(){
		parent::__construct();
		$this->load->model('m_master/m_karyawan','karyawan');
	}

	public function index(){
		$this->load->view('v_master/v_chartprospectofnewcustomer');
	}

	public function ajax_list()
	{
		$this->load->helper('url');

		$list = $this->karyawan->get_datatables();
		$data = array();
		$no = $_POST['start'];
		foreach ($list as $karyawan) {
			$no++;
			$row = array();
			$row[] = $no;
			$row[] = $karyawan->id_karyawan;
			$row[] = $karyawan->nama_karyawan;
			$row[] = $karyawan->nama_unit;
			$row[] = $karyawan->nama_departemen;
			$row[] = $karyawan->nama_section;
			$row[] = $karyawan->nama_jabatan;
			$row[] = '<center><a class="btn btn-sm btn-primary" href="karyawan/edit/'.$karyawan->id_karyawan.'" title="Edit"><i class="glyphicon glyphicon-pencil"></i></a>
			<a class="btn btn-sm btn-info" href="karyawan/detail/'.$karyawan->id_karyawan.'" title="Detail"><i class="glyphicon glyphicon-search"></i></a>
			<a class="btn btn-sm btn-danger" href="javascript:void(0)" title="Hapus" onclick="delete_karyawan('."'".$karyawan->id_karyawan."'".')"><i class="glyphicon glyphicon-trash"></i></a></center>';
			
			$data[] = $row;
		}

		$output = array(
						"draw" => $_POST['draw'],
						"recordsTotal" => $this->karyawan->count_all(),
						"recordsFiltered" => $this->karyawan->count_filtered(),
						"data" => $data,
				);
		//output to json format
		echo json_encode($output);
	}

	function add() { 
		$data['tanggal_lahir']=date('Y-m-d');
		$data['tanggal_masuk']=date('Y-m-d');
		$data['unit']=$this->db->get_where('m_unit',array('enableflag'=> '0'))->result();
		$data['section']=$this->db->get_where('m_section',array('enableflag'=> '0'))->result();
		$data['departemen']=$this->db->get_where('m_departemen',array('enableflag'=> '0'))->result();
		$data['jabatan']=$this->db->get_where('m_jabatan',array('enableflag'=> '0'))->result();
		$data['jeniskelamin']=$this->db->get_where('m_subparameter',array('enableflag'=> '0','id_parameter'=>'PM0001'))->result();
		
		$this->load->view('v_master/v_karyawan_add',$data);
	}

	function save(){
		$infoHeader=array(
			'id_karyawan'=>$this->input->post('id_karyawan'),
			'id_unit'=>$this->input->post('id_unit'),
			'id_departemen'=>$this->input->post('id_departemen'),
			'id_section'=>$this->input->post('id_section'),
			'id_jabatan'=>$this->input->post('id_jabatan'),
			'nik'=>$this->input->post('nik'),
			'nama_karyawan'=>$this->input->post('nama_karyawan'),
			'alamat_karyawan'=>$this->input->post('alamat_karyawan'),
			'jenis_kelamin'=>$this->input->post('jenis_kelamin'),
			'tanggal_lahir'=>$this->input->post('tanggal_lahir'),
			'tanggal_masuk'=>$this->input->post('tanggal_masuk'),
			'no_hp'=>$this->input->post('no_hp'),
			'email'=>$this->input->post('email'),
			'enableflag'=>$this->input->post('enableflag'),
			'userid' => $this->session->userdata("name")
			);

		$this->karyawan->save($infoHeader);

		redirect('c_master/karyawan');
	}

	function edit(){
		$id= $this->uri->segment(4);
		$data['record']=  $this->db->get_where('m_karyawan',array('id_karyawan'=> $id))->row_array();
		$data['unit']=$this->db->get_where('m_unit',array('enableflag'=> '0'))->result();
		$data['departemen']=$this->db->get_where('m_departemen',array('enableflag'=> '0'))->result();
		$data['section']=$this->db->get_where('m_section',array('enableflag'=> '0'))->result();
		$data['jabatan']=$this->db->get_where('m_jabatan',array('enableflag'=> '0'))->result();
		$data['jeniskelamin']=$this->db->get_where('m_subparameter',array('enableflag'=> '0','id_parameter'=>'PM0001'))->result();
		
		$this->load->view('v_master/v_karyawan_edit',$data);
	}

	function detail(){
		$id= $this->uri->segment(4);
		$data['record']=  $this->db->get_where('m_karyawan',array('id_karyawan'=> $id))->row_array();
		$data['unit']=$this->db->get_where('m_unit',array('enableflag'=> '0'))->result();
		$data['departemen']=$this->db->get_where('m_departemen',array('enableflag'=> '0'))->result();
		$data['section']=$this->db->get_where('m_section',array('enableflag'=> '0'))->result();
		$data['jabatan']=$this->db->get_where('m_jabatan',array('enableflag'=> '0'))->result();
		$data['jeniskelamin']=$this->db->get_where('m_subparameter',array('enableflag'=> '0','id_parameter'=>'PM0001'))->result();
		
		$this->load->view('v_master/v_karyawan_detail',$data);
	}

	function update(){
		$id=$this->input->post('id');
		$id_karyawan=$this->input->post('id_karyawan');
		$id_unit=$this->input->post('id_unit');
		$id_departemen=$this->input->post('id_departemen');
		$id_section=$this->input->post('id_section');
		$id_jabatan=$this->input->post('id_jabatan');
		$nik=$this->input->post('nik');
		$nama_karyawan=$this->input->post('nama_karyawan');
		$alamat_karyawan=$this->input->post('alamat_karyawan');
		$jenis_kelamin=$this->input->post('jenis_kelamin');
		$tanggal_lahir=$this->input->post('tanggal_lahir');
		$tanggal_masuk=$this->input->post('tanggal_masuk');
		$no_hp=$this->input->post('no_hp');
		$email=$this->input->post('email');
		$enableflag=$this->input->post('enableflag');

		$this->karyawan->update($id,$id_karyawan,$id_unit,$id_section,$id_departemen,$id_jabatan,$nik,$nama_karyawan,$alamat_karyawan,$jenis_kelamin,$tanggal_lahir,$tanggal_masuk,$no_hp,$email,$enableflag);

		redirect('c_master/karyawan');
	}

	public function ajax_delete($id)
	{
		//delete file
		$karyawan = $this->karyawan->get_by_id($id);
		
		$this->karyawan->delete_by_id($id);
		echo json_encode(array("status" => TRUE));
	}
}