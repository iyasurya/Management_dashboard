<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Employee extends CI_Controller {

	function __construct(){
		parent::__construct();
		$this->load->model('m_master/m_employee','employee');
	}

	public function index(){
		$this->load->view('v_master/v_employee');
	}

	public function ajax_list()
	{
		$this->load->helper('url');

		$list = $this->employee->get_datatables();
		$data = array();
		$no = $_POST['start'];
		foreach ($list as $employee) {
			$no++;
			$row = array();
			$row[] = $no;
			$row[] = $employee->idemployee;
			$row[] = $employee->employeename;
			$row[] = $employee->email;
			
			//add html for action
			$row[] = '<center><a class="btn btn-sm btn-primary" href="employee/edit/'.$employee->idemployee.'" title="Edit"><i class="glyphicon glyphicon-pencil"></i></a></center>';
		
			$data[] = $row;
		}

		$output = array(
						"draw" => $_POST['draw'],
						"recordsTotal" => $this->employee->count_all(),
						"recordsFiltered" => $this->employee->count_filtered(),
						"data" => $data,
				);
		//output to json format
		echo json_encode($output);
	}

	function add() { 
		
		$this->load->view('v_master/v_employee_add');
	}

	function save(){
		$infoHeader=array(
			'idemployee'=>$this->input->post('idemployee'),
			'employeename'=>$this->input->post('employeename'),
			'email'=>$this->input->post('email'),
			'enableflag'=>$this->input->post('enableflag'),
			'userid' => $this->session->userdata("name")
			);

		$this->employee->save($infoHeader);

		redirect('c_master/employee');
	}

	function edit(){
		$id= $this->uri->segment(4);
		$data['record']=  $this->db->get_where('m_employee',array('idemployee'=> $id))->row_array();
		
		$this->load->view('v_master/v_employee_edit',$data);
	}

	function update(){
		$id=$this->input->post('id');
		$idemployee=$this->input->post('idemployee');
		$employeename=$this->input->post('employeename');
		$email=$this->input->post('email');
		$enableflag=$this->input->post('enableflag');

		$this->employee->update($id,$idemployee,$employeename,$email,$enableflag);

		redirect('c_master/employee');
	}
}