<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboardrebu extends CI_Controller {

	function __construct(){
		parent::__construct();
		$this->load->model('m_login','login');
		
		if($this->session->userdata('status') != "login"){
			redirect(base_url("auth"));
		}

		$this->load->model('m_login');
	}

	public function index(){
		$data['t_incomingletter']		= $this->login->viewIncomingletter()->num_rows();
		$data['t_outgoingletter']		= $this->login->viewOutgoingletter()->num_rows();
		$data['t_disposisi']			= $this->login->viewDisposisi()->num_rows();
		//$data['rawatjalan_umum']	= $this->m_login->tampil_rawatjalan_umum($kd_poli)->num_rows();
		//$data['rawatjalan_bpjs']	= $this->m_login->tampil_rawatjalan_bpjs($kd_poli)->num_rows();
		//$data['rawatjalan_lain']	= $this->m_login->tampil_rawatjalan_lain($kd_poli)->num_rows();
		$data['kategori']=$this->db->get_where('m_subparameter',array('enableflag'=> '0','id_parameter'=>'PM0003'))->result();
		$data['periode']=$this->db->get_where('m_subparameter',array('enableflag'=> '0','id_parameter'=>'PM0004'))->result();
		$data['project']=$this->db->get_where('m_subparameter',array('enableflag'=> '0','id_parameter'=>'PM0005'))->result();
		$data['team']=$this->db->get_where('m_subparameter',array('enableflag'=> '0','id_parameter'=>'PM0007'))->result();
		

		$this->load->view('dashboard_rebu/v_dashboard',$data);
	}

	public function ajax_list()
	{
		$kd_poli=$this->session->userdata("kd_poli");
		$this->load->helper('url');

		$list = $this->login->get_datatables($kd_poli);
		$data = array();
		$no = $_POST['start'];
		foreach ($list as $login) {
			$no++;
			$row = array();
			$row[] = $no;
			$row[] = $login->no_rawat;
			$row[] = $login->no_rkm_medis;
			$row[] = $login->nm_pasien;
			$row[] = $login->png_jawab;
			$row[] = $login->stts_daftar;
			$row[] = $login->jam_reg;

			if($kd_poli == 'IGDK'){
				$row[] = '<center><a class="btn btn-sm btn-success" href="dashboard/editIGD/'.$login->no_rawat.'/'.$login->no_rkm_medis.'/'.$login->kd_pj.'/'.$login->kd_poli.'" title="Edit"><i class="glyphicon glyphicon-pencil"></i></a></center>';
			
			}else{
				$row[] = '<center><a class="btn btn-sm btn-success" href="dashboard/edit/'.$login->no_rawat.'/'.$login->no_rkm_medis.'/'.$login->kd_pj.'/'.$login->kd_poli.'" title="Edit"><i class="glyphicon glyphicon-pencil"></i></a></center>';
			}
			
			
			$data[] = $row;
		}

		$output = array(
			"draw" => $_POST['draw'],
			"recordsTotal" => $this->login->count_all(),
			"recordsFiltered" => $this->login->count_filtered(),
			"data" => $data,
			);
		//output to json format
		echo json_encode($output);
	}

}
