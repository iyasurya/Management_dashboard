<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Auth extends CI_Controller {

	function __construct(){
		parent::__construct();		
		$this->load->model('m_login');
 
	}

	public function index()
	{
		$this->load->view('v_login');
	}

	function aksi_login(){
		$username = $this->input->post('username');
		$password = $this->input->post('password');
		
		$cek = $this->m_login->cek_login("m_user",$username,$password);
		if($cek->num_rows() == 1){
			$x = $cek->row_array();
 
			// foreach ($cek->result() as $data) {
			// 	$data_session = array(
			// 	'username' => $data->userna section
			// 	'name' => $data->name,
			// 	'key_id' => $data->key_id,
			// 	'jobdescription' => $data->jobdescription,
			// 	'menu' => $data->menu,
			// 	'status' => "login"
			// 	);

			// 	$this->session->set_userdata($data_session); 
			// 	redirect(base_url("dashboard"));				
 			// }
			
				if($x['menu']=='admin'){ //admin
						foreach ($cek->result() as $data) {
							$data_session = array(
							'username' => $data->username,
							'id_unit' => $data->id_unit,
							'id_departemen' => $data->id_departemen,
							'id_section' => $data->id_section,
							'id_jabatan' => $data->id_jabatan,
							'id_karyawan' => $data->id_karyawan,
							'name' => $data->name,
							'key_id' => $data->key_id,
							'jobdescription' => $data->jobdescription,
							'menu' => $data->menu,
							'attachement' => $data->attachement,
							'status' => "login"
							);

							$this->session->set_userdata($data_session); 
							redirect(base_url("dashboard"));				
						}

				}else if($x['menu']=='rebu'){ //REBU
						foreach ($cek->result() as $data) {
							$data_session = array(
							'username' => $data->username,
							'id_unit' => $data->id_unit,
							'id_departemen' => $data->id_departemen,
							'id_section' => $data->id_section,
							'id_jabatan' => $data->id_jabatan,
							'id_karyawan' => $data->id_karyawan,
							'name' => $data->name,
							'key_id' => $data->key_id,
							'jobdescription' => $data->jobdescription,
							'menu' => $data->menu,
							'attachement' => $data->attachement,
							'status' => "login"
							);

							$this->session->set_userdata($data_session); 
							redirect(base_url("c_unit/dashboardrebu"));				
						}

				}else if($x['menu']=='head'){ //Head
						foreach ($cek->result() as $data) {
							$data_session = array(
							'username' => $data->username,
							'id_unit' => $data->id_unit,
							'id_departemen' => $data->id_departemen,
							'id_section' => $data->id_section,
							'id_jabatan' => $data->id_jabatan,
							'id_karyawan' => $data->id_karyawan,
							'name' => $data->name,
							'key_id' => $data->key_id,
							'jobdescription' => $data->jobdescription,
							'menu' => $data->menu,
							'attachement' => $data->attachement,
							'status' => "login"
							);
							$this->session->set_userdata($data_session); 
							redirect(base_url("c_head/berandahead"));				
						}
				}else if($x['menu']=='sectionhead'){ //Head
					foreach ($cek->result() as $data) {
						$data_session = array(
						'username' => $data->username,
						'id_unit' => $data->id_unit,
						'id_departemen' => $data->id_departemen,
						'id_section' => $data->id_section,
						'id_jabatan' => $data->id_jabatan,
						'id_karyawan' => $data->id_karyawan,
						'name' => $data->name,
						'key_id' => $data->key_id,
						'jobdescription' => $data->jobdescription,
						'menu' => $data->menu,
						'attachement' => $data->attachement,
						'status' => "login"
						);
						$this->session->set_userdata($data_session); 
						redirect(base_url("c_section/berandasectionhead"));				
					}
				}else if($x['menu']=='officer'){ //Head
					foreach ($cek->result() as $data) {
						$data_session = array(
						'username' => $data->username,
						'id_unit' => $data->id_unit,
						'id_departemen' => $data->id_departemen,
						'id_section' => $data->id_section,
						'id_jabatan' => $data->id_jabatan,
						'id_karyawan' => $data->id_karyawan,
						'name' => $data->name,
						'key_id' => $data->key_id,
						'jobdescription' => $data->jobdescription,
						'menu' => $data->menu,
						'attachement' => $data->attachement,
						'status' => "login"
						);
						$this->session->set_userdata($data_session); 
						redirect(base_url("c_officer/berandaofficer"));				
					}
			}
		
			
 
		}else{
			$this->session->set_flashdata('message', 'Nama Pengguna atau Kata Sandi Salah !!');
			redirect();
		}
	}
 
	function logout(){
		$this->session->sess_destroy();
		redirect(base_url('auth'));
	}
}