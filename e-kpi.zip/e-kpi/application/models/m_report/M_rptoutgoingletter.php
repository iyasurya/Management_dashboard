<?php 

class M_rptoutgoingletter extends CI_Model{

	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}

}	

?>