<?php 

class M_realisasikpi extends CI_Model{

	var $table = 't_realisasi';
	var $column_order = array('id_realisasi','id_karyawan','id_kategori',null); //set column field database for datatable orderable
	var $column_search = array('id_realisasi','id_karyawan','id_kategori'); //set column field database for datatable searchable just firstname , lastname , address are searchable
	var $order = array('id_realisasi' => 'desc'); // default order 	 	

	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}

	private function _get_datatables_query($term='')
	{
		$karyawan = $_SESSION['id_karyawan'];

		$this->db->select('a.*,b.nama_karyawan,c.nama_kategori,e.nama_bulan,d.nama_tahun');
		$this->db->from('t_realisasi as a');
		$this->db->join('m_karyawan as b', 'b.id_karyawan = a.id_karyawan','left');
		$this->db->join('m_kategori as c', 'c.id_kategori = a.id_kategori','left');
		$this->db->join('m_tahun as d', 'd.id_tahun = a.id_tahun','left');
		$this->db->join('m_bulan as e', 'e.id_bulan = a.id_bulan','left');
		$this->db->where('a.enableflag','0');
		$this->db->where('a.id_karyawan',$karyawan);
		$this->db->where("(b.nama_karyawan LIKE '%".$term."%' OR c.nama_kategori LIKE '%".$term."%')", NULL, FALSE);
		
		if(isset($_POST['order'])) // here order processing
		{
			$this->db->order_by($this->column_order[$_POST['order']['0']['column']], $_POST['order']['0']['dir']);
		} 
		else if(isset($this->order))
		{
			$order = $this->order;
			$this->db->order_by(key($order), $order[key($order)]);
		}
	}

	function get_datatables()
	{
		$term = $_REQUEST['search']['value']; 
		$this->_get_datatables_query($term);
		if($_POST['length'] != -1)
		$this->db->limit($_POST['length'], $_POST['start']);
		$query = $this->db->get();
		return $query->result();
	}

	function count_filtered()
	{
		$this->_get_datatables_query();
		$query = $this->db->get();
		return $query->num_rows();
	}

	public function count_all()
	{
		$this->db->from($this->table);
		return $this->db->count_all_results();
	}

	public function get_by_id($id)
	{
		$this->db->from($this->table);
		$this->db->where('id',$id);
		$query = $this->db->get();

		return $query->row();
	}

	public function save($data)
	{
		$this->db->insert($this->table, $data);
		return $this->db->insert_id();
	}

	function update($id,$id_realisasi,$id_karyawan,$id_kategori,$id_bulan,$id_tahun,$id_supervisor,$skor_akhir,$enableflag){
		
		$id=$id;
		$infoHeader=array(
			'id_realisasi'=>$id_realisasi,
			'id_karyawan'=>$id_karyawan,
			'id_kategori'=>$id_kategori,
			'id_bulan'=>$id_bulan,
			'id_tahun'=>$id_tahun,
			'id_supervisor'=>$id_supervisor,
			'skor_akhir'=>$skor_akhir,
			'enableflag'=>$enableflag,
			'userid' => $this->session->userdata("name")
			);

		$this->db->where('id',$id);
		$this->db->update('t_realisasi',$infoHeader);
	}

	function updateStatus($id,$status){
		
		$id=$id;

		$infoHeader=array(
			'status'=>$status,
			'userid' => $this->session->userdata("name")
		);

		$this->db->where('id',$id);
		$this->db->update('t_realisasi',$infoHeader);
	}

	//add save disposisi
	function deleteAllTemp(){
		$key_id=$this->session->userdata('key_id');
		$this->db->where("key_id",$key_id);
		$this->db->delete("t_realisasitemp");
	}

	function saveKpi($id_realisasi){
		$a=$id_realisasi;
		$tmp=$this->viewKPI()->result();
		foreach($tmp as $row){
			$infoDet=array(
				'id_realisasi'=>$a,
				'id_kpi'=>$row->id_kpi,
				'nama_kpi'=>$row->nama_kpi,
				'obj'=>$row->obj,
				'waktu'=>$row->waktu,
				'realisasi'=>$row->realisasi,
				'userid' => $this->session->userdata("name")
				);
			$this->saveTransactionKpi($infoDet);
		}
	}

	function saveTransactionKpi($infoDet){
		$this->db->insert("t_detailrealisasi",$infoDet);
	}

	function viewKPI(){
		$this->db->where("key_id",$this->session->userdata('key_id'));
		return $this->db->get("t_realisasitemp");
	}

	function getIdkpi($nama_kpi){
		$query = $this->db->select('id_kpi as id_kpi')->from('m_kpi')->where('nama_kpi', $nama_kpi)->get();
		return $query->row()->id_kpi;
	}

	function cekTmpKpi($nama_kpi){
		$this->db->where("nama_kpi",$nama_kpi);
		$this->db->where("key_id",$this->session->userdata('key_id'));
		return $this->db->get("t_realisasitemp");
	}

	function saveTemp($info){
		$this->db->insert("t_realisasitemp",$info);
	}

	function delTemp($kode){
		$this->db->where("kode",$kode);
		$this->db->delete("t_realisasitemp");
	}

	function getKPI($q){
	    $this->db->select('nama_kpi');
	    $this->db->like('nama_kpi', $q);	    
	    $this->db->where('enableflag', '0');
	    $query = $this->db->get('m_kpi');
	    if($query->num_rows() > 0){
	      foreach ($query->result_array() as $row){
	        $row_set[] = htmlentities(stripslashes($row['nama_kpi'])); //build an array
	      }
	      echo json_encode($row_set); //format the array into json data
	    }
	 }

	 function viewKpiDetail($id_realisasi){
		$this->db->where("id_realisasi",$id_realisasi);
		return $this->db->get("t_detailrealisasi");
	}

	function delDetail($kode){
		$this->db->where("id",$kode);
		$this->db->delete("t_detailrealisasi");
	}
}	

?>