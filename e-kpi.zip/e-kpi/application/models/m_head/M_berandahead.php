<?php 

class M_berandahead extends CI_Model{

	var $table = 'm_karyawan';
	var $column_order = array('id_karyawan','nama_karyawan',null); //set column field database for datatable orderable
	var $column_search = array('id_karyawan','nama_karyawan'); //set column field database for datatable searchable just firstname , lastname , address are searchable
	var $order = array('id_karyawan' => 'asc'); // default order 	

	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}

	private function _get_datatables_query($term='')
	{

		$this->db->select('a.*,b.nama_unit,c.nama_departemen,d.nama_section,e.nama_jabatan,f.id_kpi,f.nama_kpi,h.skor_akhir,i.attachement,(j.realisasi*k.bobot)/100 as nilai');
		$this->db->from('m_karyawan as a');
		$this->db->join('m_unit as b', 'b.id_unit = a.id_unit','left');
		$this->db->join('m_departemen as c', 'c.id_departemen = a.id_departemen','left');
		$this->db->join('m_section as d', 'd.id_section = a.id_section','left');
		$this->db->join('m_jabatan as e', 'e.id_jabatan = a.id_jabatan','left');
		$this->db->join('m_kpi as f', 'f.id_unit = b.id_unit','left');
		$this->db->join('t_target as g', 'g.id_kpi = f.id_kpi','left');
		$this->db->join('t_realisasi as h', 'h.id_karyawan = a.id_karyawan','left');
		$this->db->join('m_user as i', 'i.id_karyawan = a.id_karyawan','left');
		$this->db->join('t_detailrealisasi as j', 'j.id_realisasi = h.id_realisasi','left');
		$this->db->join('m_kpikaryawan as k', 'k.id_karyawan = h.id_karyawan and k.id_kpi = j.id_kpi','left');
		$this->db->where('a.enableflag','0');
		$this->db->where('b.id_unit',$_SESSION['id_unit']);
		$this->db->where('a.id_departemen',$_SESSION['id_departemen']);
		$this->db->where("(a.nama_karyawan LIKE '%".$term."%' OR a.id_karyawan LIKE '%".$term."%')", NULL, FALSE);
		$this->db->group_by('a.id_karyawan');
		$this->db->order_by('c.nama_departemen');
		
		
		if(isset($_POST['order'])) // here order processing
		{
			$this->db->order_by($this->column_order[$_POST['order']['0']['column']], $_POST['order']['0']['dir']);
		} 
		else if(isset($this->order))
		{
			$order = $this->order;
			$this->db->order_by(key($order), $order[key($order)]);
		}
	}

	function get_datatables()
	{
		$term = $_REQUEST['search']['value']; 
		$this->_get_datatables_query($term);
		if($_POST['length'] != -1)
		$this->db->limit($_POST['length'], $_POST['start']);
		$query = $this->db->get();
		return $query->result();
	}

	function count_filtered()
	{
		$this->_get_datatables_query();
		$query = $this->db->get();
		return $query->num_rows();
	}

	public function count_all()
	{
		$this->db->from($this->table);
		return $this->db->count_all_results();
	}

	public function get_by_id($id)
	{
		$this->db->from($this->table);
		$this->db->where('id_karyawan',$id);
		$query = $this->db->get();

		return $query->row();
	}

	public function save($data)
	{
		$this->db->insert($this->table, $data);
		return $this->db->insert_id();
	}

	function update($id,$id_karyawan,$id_departemen,$id_jabatan,$nama_karyawan,$perspective,$subkaryawan,
					$parameter,$measurement,$sourcesdata,$pic,$enableflag){
		
		$id=$id;
		$infoHeader=array(
			'id_karyawan'=>$id_karyawan,
			'id_departemen'=>$id_departemen,
			'id_jabatan'=>$id_jabatan,
			'nama_karyawan'=>$nama_karyawan,
			'perspective'=>$perspective,
			'subkaryawan'=>$subkaryawan,
			'parameter'=>$parameter,
			'measurement'=>$measurement,
			'sourcesdata'=>$sourcesdata,
			'pic'=>$pic,
			'enableflag'=>$enableflag,
			'userid' => $this->session->userdata("name")
			);

		$this->db->where('id',$id);
		$this->db->update('m_karyawan',$infoHeader);
	}

	public function delete_by_id($id)
	{
		$this->db->where('id_karyawan', $id);
		$this->db->delete($this->table);
	} 

	public function viewRealisasi($bFrom,$bTo,$tFrom,$tTo,$periode){
		//	var_dump($bFrom,$bTo,$tFrom,$tTo,$periode);
	
			$this->db->select('a.*,(a.obj+a.waktu)/2 as avg,(a.realisasi*c.bobot)/100 as nilai,d.nama_bulan');
			$this->db->from('t_detailrealisasi as a');
			$this->db->join('t_realisasi as b', 'b.id_realisasi = a.id_realisasi','left');
			$this->db->join('m_kpikaryawan as c', 'c.id_karyawan = b.id_karyawan and c.id_kpi = a.id_kpi','left');
			$this->db->join('m_bulan as d', 'd.id_bulan = b.id_bulan','left');
			$this->db->where('a.enableflag','0');
			$this->db->where('b.id_karyawan', $_SESSION['id_karyawan']);
			$this->db->where('b.id_bulan >=', $bFrom);
			$this->db->where('b.id_bulan <=',$bTo);
			$this->db->where('b.id_tahun >=', $tFrom);
			$this->db->where('b.id_tahun <=',$tTo);
			//$this->db->group_by('a.id_kpi');
			$this->db->order_by('a.id_realisasi');
			$this->db->order_by('a.id');
			$query = $this->db->get();
			return $query->result();
		}
		public function viewKPI($bFrom,$bTo,$tFrom,$tTo,$periode){
			//var_dump($bFrom,$bTo,$tFrom,$tTo,$periode);
			$this->db->select('a.*,(a.obj+a.waktu)/2 as avg,(a.realisasi*c.bobot)/100 as nilai,d.nama_bulan');
			$this->db->from('t_detailrealisasi as a');
			$this->db->join('t_realisasi as b', 'b.id_realisasi = a.id_realisasi','left');
			$this->db->join('m_kpikaryawan as c', 'c.id_karyawan = b.id_karyawan and c.id_kpi = a.id_kpi','left');
			$this->db->join('m_bulan as d', 'd.id_bulan = b.id_bulan','left');
			$this->db->where('a.enableflag','0');
			$this->db->where('b.id_karyawan', $_SESSION['id_karyawan']);
			$this->db->where('b.id_bulan >=', $bFrom);
			$this->db->where('b.id_bulan <=',$bTo);
			$this->db->where('b.id_tahun >=', $tFrom);
			$this->db->where('b.id_tahun <=',$tTo);
			//$this->db->group_by('a.id_kpi');
			$this->db->order_by('a.id_realisasi');
			$this->db->order_by('a.id');
			
			$query = $this->db->get();
			return $query->result();
			}

		public function viewDepartement(){
			$this->db->select('a.nama_departemen');
			$this->db->from('m_departemen as a');
			$this->db->where('a.enableflag','0');
			$this->db->where('a.id_departemen', $_SESSION['id_departemen']);
			
			$query = $this->db->get();
			return $query->result();
			}
	
		public function viewNilaiKPI1(){
				return $this->db->get('t_detailrealisasi');
			}
		

		public function viewNilaiKPI2(){
			return $this->db->get('t_detailrealisasi');
		}

		public function viewNilaiKPI3(){
			return $this->db->get('t_detailrealisasi');
		}

		public function viewNilaiKPI4(){
			return $this->db->get('t_detailrealisasi');
		}

		public function viewNilaiKPI5(){
			return $this->db->get('t_detailrealisasi');
		}
}	

?>