<?php 

class M_bobotkpi extends CI_Model{

	var $table = 't_target';
	var $column_order = array('id_target','title','target_kpi',null); //set column field database for datatable orderable
	var $column_search = array('id_target','title','target_kpi'); //set column field database for datatable searchable just firstname , lastname , address are searchable
	var $order = array('id_target' => 'desc'); // default order 	

	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}

	private function _get_datatables_query($term='')
	{

		// $this->db->select('a.*,b.classificationofletter,c.typeofletter');
		// $this->db->from('t_bobotkpi as a');
		// $this->db->join('m_classificationofletter as b', 'b.idclassificationofletter = a.classificationofletterid','left');
		// $this->db->join('m_typeofletter as c', 'c.idtypeofletter = a.typeofletterid','left');
		// $this->db->where('a.voidflag','0');
		// $this->db->where("(a.title LIKE '%".$term."%' OR b.classificationofletter LIKE '%".$term."%' OR a.dateofletter LIKE '%".$term."%' OR a.originofletter LIKE '%".$term."%' OR c.typeofletter LIKE '%".$term."%' OR a.referencenumber LIKE '%".$term."%')", NULL, FALSE);
		
		$this->db->select('a.*,b.nama_kpi,c.nama_bulan,d.nama_tahun');
		$this->db->from('t_target as a');
		$this->db->join('m_kpi as b', 'b.id_kpi = a.id_kpi','left');
		$this->db->join('m_bulan as c', 'c.id_bulan = a.id_bulan','left');
		$this->db->join('m_tahun as d', 'd.id_tahun = a.id_tahun','left');
		$this->db->where('a.enableflag','0');
		$this->db->where("(a.target_kpi LIKE '%".$term."%' OR b.nama_kpi 
		LIKE '%".$term."%' OR a.target_kpi LIKE '%".$term."%' )", NULL, FALSE);
		if(isset($_POST['order'])) // here order processing
		{
			$this->db->order_by($this->column_order[$_POST['order']['0']['column']], $_POST['order']['0']['dir']);
		} 
		else if(isset($this->order))
		{
			$order = $this->order;
			$this->db->order_by(key($order), $order[key($order)]);
		}
	}

	function get_datatables()
	{
		$term = $_REQUEST['search']['value']; 
		$this->_get_datatables_query($term);
		if($_POST['length'] != -1)
		$this->db->limit($_POST['length'], $_POST['start']);
		$query = $this->db->get();
		return $query->result();
	}

	function count_filtered()
	{
		$this->_get_datatables_query();
		$query = $this->db->get();
		return $query->num_rows();
	}

	public function count_all()
	{
		$this->db->from($this->table);
		return $this->db->count_all_results();
	}

	public function get_by_id($id)
	{
		$this->db->from($this->table);
		$this->db->where('idemployee',$id);
		$query = $this->db->get();

		return $query->row();
	}

	public function save($data)
	{
		$this->db->insert($this->table, $data);
		return $this->db->insert_id();
	}

	function update($id,$id_target,$id_bulan,$id_tahun,$target_kpi,$unit_pengukuran,$bobot_kpi,$enableflag){
		
		$id=$id;
		$infoHeader=array(
			'id_target'=>$id_target,
			'id_bulan'=>$id_bulan,
			'id_tahun'=>$id_tahun,
			'target_kpi'=>$target_kpi,
			'unit_pengukuran'=>$unit_pengukuran,
			'bobot_kpi'=>$bobot_kpi,
			'enableflag'=>$enableflag,
			'userid' => $this->session->userdata("name")
		);

		$this->db->where('id',$id);
		$this->db->update('t_target',$infoHeader);
	}

	function updateStatus($id,$status){
		
		$id=$id;

		$infoHeader=array(
			'status'=>$status,
			'userid' => $this->session->userdata("name")
		);

		$this->db->where('id',$id);
		$this->db->update('t_target',$infoHeader);
	}

	function getDisposisi($id){
		return $this->db->query("
			select a.*
			from t_bobotkpidisposisi a
			left join t_bobotkpi b on b.idbobotkpi=a.bobotkpiid
			where b.id = '$id'")->result();
	}
}	

?>