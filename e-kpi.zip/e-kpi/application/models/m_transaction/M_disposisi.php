<?php 

class M_disposisi extends CI_Model{

	var $table = 't_incomingletter';
	var $column_order = array('idincomingletter','title','referencenumber',null); //set column field database for datatable orderable
	var $column_search = array('idincomingletter','title','referencenumber'); //set column field database for datatable searchable just firstname , lastname , address are searchable
	var $order = array('idincomingletter' => 'desc'); // default order 	

	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}

	private function _get_datatables_query($term='')
	{

		$this->db->select('a.*,b.classificationofletter,c.typeofletter');
		$this->db->from('t_incomingletter as a');
		$this->db->join('m_classificationofletter as b', 'b.idclassificationofletter = a.classificationofletterid','left');
		$this->db->join('m_typeofletter as c', 'c.idtypeofletter = a.typeofletterid','left');
		$this->db->where('a.voidflag','0');
		$this->db->where("(a.title LIKE '%".$term."%' OR b.classificationofletter LIKE '%".$term."%' OR a.dateofletter LIKE '%".$term."%' OR a.originofletter LIKE '%".$term."%' OR c.typeofletter LIKE '%".$term."%' OR a.referencenumber LIKE '%".$term."%')", NULL, FALSE);
		
		if(isset($_POST['order'])) // here order processing
		{
			$this->db->order_by($this->column_order[$_POST['order']['0']['column']], $_POST['order']['0']['dir']);
		} 
		else if(isset($this->order))
		{
			$order = $this->order;
			$this->db->order_by(key($order), $order[key($order)]);
		}
	}

	function get_datatables()
	{
		$term = $_REQUEST['search']['value']; 
		$this->_get_datatables_query($term);
		if($_POST['length'] != -1)
		$this->db->limit($_POST['length'], $_POST['start']);
		$query = $this->db->get();
		return $query->result();
	}

	function count_filtered()
	{
		$this->_get_datatables_query();
		$query = $this->db->get();
		return $query->num_rows();
	}

	public function count_all()
	{
		$this->db->from($this->table);
		return $this->db->count_all_results();
	}

	public function get_by_id($id)
	{
		$this->db->from($this->table);
		$this->db->where('idemployee',$id);
		$query = $this->db->get();

		return $query->row();
	}

	function update($idincomingletter,$status){
		
		$id=$idincomingletter;

		$infoHeader=array(
			'status'=>$status,
			'userid' => $this->session->userdata("name")
		);

		$this->db->where('idincomingletter',$id);
		$this->db->update('t_incomingletter',$infoHeader);
	}

	function saveDisposisi($idincomingletter){
		$a=$idincomingletter;
		$tmp=$this->viewDisposisi()->result();
		foreach($tmp as $row){
			$infoDet=array(
				'incomingletterid'=>$a,
				'employeeid'=>$row->employeeid,
				'employeename'=>$row->employeename,
				'status'=>'0',
				'userid' => $this->session->userdata("name")
				);
			$this->saveTransactionDisposisi($infoDet);
		}
	}

	function saveTransactionDisposisi($infoDet){
		$this->db->insert("t_incomingletterdisposisi",$infoDet);
	}

	function getTypeofletter($id){
		$query = $this->db->select('b.typeofletter as typeofletter')->from('t_incomingletter a')->join('m_typeofletter b','b.idtypeofletter = a.typeofletterid','left')->where('a.idincomingletter', $id)->get();
		return $query->row()->typeofletter;
	}

	function getClassificationofletter($id){
		$query = $this->db->select('b.classificationofletter as classificationofletter')->from('t_incomingletter a')->join('m_classificationofletter b','b.idclassificationofletter = a.classificationofletterid','left')->where('a.idincomingletter', $id)->get();
		return $query->row()->classificationofletter;
	}

	function getEmployee($q){
	    $this->db->select('employeename');
	    $this->db->like('employeename', $q);	    
	    $this->db->where('enableflag', '0');
	    $query = $this->db->get('m_employee');
	    if($query->num_rows() > 0){
	      foreach ($query->result_array() as $row){
	        $row_set[] = htmlentities(stripslashes($row['employeename'])); //build an array
	      }
	      echo json_encode($row_set); //format the array into json data
	    }
	  }

	 function deleteAllTemp(){
		$key_id=$this->session->userdata('key_id');
		$this->db->where("key_id",$key_id);
		$this->db->delete("t_incomingletterdistemp");
	}

	function getIdemployee($employeename){
		$query = $this->db->select('idemployee as idemployee')->from('m_employee')->where('employeename', $employeename)->get();
		return $query->row()->idemployee;
	}

	function cekTmpDisposisi($employeename){
		$this->db->where("employeename",$employeename);
		$this->db->where("key_id",$this->session->userdata('key_id'));
		return $this->db->get("t_incomingletterdistemp");
	}

	function saveTemp($info){
		$this->db->insert("t_incomingletterdistemp",$info);
	}

	function viewDisposisi(){
		$this->db->where("key_id",$this->session->userdata('key_id'));
		return $this->db->get("t_incomingletterdistemp");
	}

	function delTemp($kode){
		$this->db->where("kode",$kode);
		$this->db->delete("t_incomingletterdistemp");
	}

	//add for dashboard
	private function _get_datatables_query_dashboard($term='')
	{

		$this->db->select('a.*,b.classificationofletter,c.typeofletter');
		$this->db->from('t_incomingletter as a');
		$this->db->join('m_classificationofletter as b', 'b.idclassificationofletter = a.classificationofletterid','left');
		$this->db->join('m_typeofletter as c', 'c.idtypeofletter = a.typeofletterid','left');
		$this->db->where('a.voidflag','0');
		$this->db->where('a.status','0');
		$this->db->where("(a.title LIKE '%".$term."%' OR b.classificationofletter LIKE '%".$term."%' OR a.dateofletter LIKE '%".$term."%' OR a.originofletter LIKE '%".$term."%' OR c.typeofletter LIKE '%".$term."%' OR a.referencenumber LIKE '%".$term."%')", NULL, FALSE);
		
		if(isset($_POST['order'])) // here order processing
		{
			$this->db->order_by($this->column_order[$_POST['order']['0']['column']], $_POST['order']['0']['dir']);
		} 
		else if(isset($this->order))
		{
			$order = $this->order;
			$this->db->order_by(key($order), $order[key($order)]);
		}
	}

	function get_datatables_disposisi()
	{
		$term = $_REQUEST['search']['value']; 
		$this->_get_datatables_query_dashboard($term);
		if($_POST['length'] != -1)
		$this->db->limit($_POST['length'], $_POST['start']);
		$query = $this->db->get();
		return $query->result();
	}

	function count_filtered_disposisi()
	{
		$this->_get_datatables_query_dashboard();
		$query = $this->db->get();
		return $query->num_rows();
	}

	public function count_all_disposisi()
	{
		$this->db->from($this->table);
		$this->db->where('status','0');
		return $this->db->count_all_results();
	}
}	

?>