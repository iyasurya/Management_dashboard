<?php 

class M_realisasikpi extends CI_Model{

	var $table = 't_realisasi';
	var $column_order = array('id_realisasi','skor_akhir',null); //set column field database for datatable orderable
	var $column_search = array('id_realisasi','skor_akhir'); //set column field database for datatable searchable just firstname , lastname , address are searchable
	var $order = array('id_realisasi' => 'desc'); // default order 	

	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}

	private function _get_datatables_query($term='')
	{

		// $this->db->select('a.*,b.classificationofletter,c.typeofletter');
		// $this->db->from('t_realisasikpi as a');
		// $this->db->join('m_classificationofletter as b', 'b.idclassificationofletter = a.classificationofletterid','left');
		// $this->db->join('m_typeofletter as c', 'c.idtypeofletter = a.typeofletterid','left');
		// $this->db->where('a.voidflag','0');
		// $this->db->where("(a.title LIKE '%".$term."%' OR b.classificationofletter LIKE '%".$term."%' OR a.dateofletter LIKE '%".$term."%' OR a.originofletter LIKE '%".$term."%' OR c.typeofletter LIKE '%".$term."%' OR a.referencenumber LIKE '%".$term."%')", NULL, FALSE);
		
		$this->db->select('a.*,b.nama_karyawan,c.nama_bulan,d.nama_tahun,e.nama_kategori');
		$this->db->from('t_realisasi as a');
		$this->db->join('m_karyawan as b', 'b.id_karyawan = a.id_karyawan','left');
		$this->db->join('m_bulan as c', 'c.id_bulan = a.id_bulan','left');
		$this->db->join('m_tahun as d', 'd.id_tahun = a.id_tahun','left');
		$this->db->join('m_kategori as e', 'e.id_kategori = a.id_kategori','left');
		$this->db->where('a.enableflag','0');
		$this->db->where("(a.skor_akhir LIKE '%".$term."%' OR b.nama_karyawan 
		LIKE '%".$term."%' OR a.skor_akhir LIKE '%".$term."%' )", NULL, FALSE);
		if(isset($_POST['order'])) // here order processing
		{
			$this->db->order_by($this->column_order[$_POST['order']['0']['column']], $_POST['order']['0']['dir']);
		} 
		else if(isset($this->order))
		{
			$order = $this->order;
			$this->db->order_by(key($order), $order[key($order)]);
		}
	}

	function get_datatables()
	{
		$term = $_REQUEST['search']['value']; 
		$this->_get_datatables_query($term);
		if($_POST['length'] != -1)
		$this->db->limit($_POST['length'], $_POST['start']);
		$query = $this->db->get();
		return $query->result();
	}

	function count_filtered()
	{
		$this->_get_datatables_query();
		$query = $this->db->get();
		return $query->num_rows();
	}

	public function count_all()
	{
		$this->db->from($this->table);
		return $this->db->count_all_results();
	}

	public function get_by_id($id)
	{
		$this->db->from($this->table);
		$this->db->where('id_realisasi',$id);
		$query = $this->db->get();

		return $query->row();
	}

	public function save($data)
	{
		$this->db->insert($this->table, $data);
		return $this->db->insert_id();
	}

	function saveDisposisi($id_realisasi){
		$a=$id_realisasi;
		$tmp=$this->viewKpi()->result();
		foreach($tmp as $row){
			$infoDet=array(
				'id_realisasi'=>$a,
				'id_kpi'=>$row->id_kpi,
				'nama_kpi'=>$row->nama_kpi,
				'status'=>'0',
				'userid' => $this->session->userdata("name")
				);
			$this->saveTransactionDisposisi($infoDet);
		}
	}

	function saveTransactionDisposisi($infoDet){
		$this->db->insert("t_incomingletterdisposisi",$infoDet);
	}

	function update($id,$id_realisasi,$id_karyawan,$id_kategori,$id_bulan,$id_tahun,$id_supervisor,$skor_akhir,$enableflag){
		
		$id=$id;
		$infoHeader=array(
			'id_realisasi'=>$id_realisasi,
			'id_karyawan'=>$id_karyawan,
			'id_kategori'=>$id_kategori,
			'id_bulan'=>$id_bulan,
			'id_tahun'=>$id_tahun,
			'id_supervisor'=>$id_supervisor,
			'skor_akhir'=>$skor_akhir,
			'enableflag'=>$enableflag,
			'userid' => $this->session->userdata("name")
		);

		$this->db->where('id',$id);
		$this->db->update('t_realisasi',$infoHeader);
	}

	function updateStatus($id,$status){
		
		$id=$id;

		$infoHeader=array(
			'status'=>$status,
			'userid' => $this->session->userdata("name")
		);

		$this->db->where('id',$id);
		$this->db->update('t_realisasi',$infoHeader);
	}

	// function getDisposisi($id){
	// 	return $this->db->query("
	// 		select a.*
	// 		from t_realisasikpidisposisi a
	// 		left join t_realisasikpi b on b.idrealisasikpi=a.realisasikpiid
	// 		where b.id = '$id'")->result();
	// }

	function getKpi($q){
	    $this->db->select('nama_kpi');
	    $this->db->like('nama_kpi', $q);	    
	    $this->db->where('enableflag', '0');
	    $query = $this->db->get('m_kpi');
	    if($query->num_rows() > 0){
	      foreach ($query->result_array() as $row){
	        $row_set[] = htmlentities(stripslashes($row['nama_kpi'])); //build an array
	      }
	      echo json_encode($row_set); //format the array into json data
	    }
	  }

	  function deleteAllTemp(){
		$key_id=$this->session->userdata('key_id');
		$this->db->where("key_id",$key_id);
		$this->db->delete("t_realisasitemp");
	}

	function getIdkpi($nama_kpi){
		$query = $this->db->select('id_kpi as id_kpi')->from('m_kpi')->where('nama_kpi', $nama_kpi)->get();
		return $query->row()->id_kpi;
	}

	function cekTmpKpi($nama_kpi){
		$this->db->where("nama_kpi",$nama_kpi);
		$this->db->where("key_id",$this->session->userdata('key_id'));
		return $this->db->get("t_realisasitemp");
	}

	function saveTemp($info){
		$this->db->insert("t_realisasitemp",$info);
	}

	function viewKpi(){
		$this->db->where("key_id",$this->session->userdata('key_id'));
		return $this->db->get("t_realisasitemp");
	}

	function delTemp($kode){
		$this->db->where("kode",$kode);
		$this->db->delete("t_realisasitemp");
	}

}	

?>