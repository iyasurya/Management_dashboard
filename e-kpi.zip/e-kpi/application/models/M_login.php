<?php 

class M_login extends CI_Model{	

	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}

	function cek_login($table,$username,$password){
		$this->db->select('m_user.username as username,m_user.name as name,m_user.attachement,m_user.id_karyawan, 
		    m_user.id_unit,m_user.id_departemen,m_user.id_section,m_user.id_jabatan,
			m_user.jobdescription as jobdescription,m_user.key_id as key_id,m_user.menu as menu');
		$this->db->where('m_user.username', $username);
		$this->db->where('m_user.password', md5($password));
		$this->db->where('m_user.enableflag', '0');
		return $this->db->get($table);
	}

	// public function viewIncomingletter(){
	// 	return $this->db->get('t_incomingletter');
	// }

	// public function viewOutgoingletter(){
	// 	return $this->db->get('t_outgoingletter');
	// }

	// public function viewDisposisi(){
	// 	$this->db->where('status', '0');
	// 	return $this->db->get('t_incomingletter');
	// }

	public function viewLsu(){
		$this->db->where('id_unit', 'U0005');
		return $this->db->get('m_karyawan');
	}

	public function viewPmu(){
		$this->db->where('id_unit', 'U0006');
		return $this->db->get('m_karyawan');
	}
	
	public function viewRebu(){
		$this->db->where('id_unit', 'U0007');
		return $this->db->get('m_karyawan');
	}

	public function viewTcbu(){
		$this->db->where('id_unit', 'U0008');
		return $this->db->get('m_karyawan');
	}

	public function viewCsu(){
		$this->db->where('id_unit', 'U0004');
		return $this->db->get('m_karyawan');
	}
}	

?>