<?php 

class M_marketing extends CI_Model{

	var $table = 'm_karyawan';
	var $column_order = array('id_karyawan','nama_karyawan','nama_section','nama_jabatan',null); //set column field database for datatable orderable
	var $column_search = array('id_karyawan','nama_karyawan','nama_section','nama_jabatan'); //set column field database for datatable searchable just firstname , lastname , address are searchable
	var $order = array('id_karyawan' => 'asc'); // default order 	

	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}

	private function _get_datatables_query($term='')
	{

		$this->db->select('a.*,b.nama_unit,c.nama_departemen,d.nama_section,e.nama_jabatan,f.id_kpi,f.nama_kpi,h.skor_akhir,i.attachement');
		$this->db->from('m_karyawan as a');
		$this->db->join('m_unit as b', 'b.id_unit = a.id_unit','left');
		$this->db->join('m_departemen as c', 'c.id_departemen = a.id_departemen','left');
		$this->db->join('m_section as d', 'd.id_section = a.id_section','left');
		$this->db->join('m_jabatan as e', 'e.id_jabatan = a.id_jabatan','left');
		$this->db->join('m_kpi as f', 'f.id_unit = b.id_unit','left');
		$this->db->join('t_target as g', 'g.id_kpi = f.id_kpi','left');
		$this->db->join('t_realisasi as h', 'h.id_karyawan = a.id_karyawan','left');
		$this->db->join('m_user as i', 'i.id_karyawan = a.id_karyawan','left');
		$this->db->where('a.enableflag','0');
		$this->db->where('b.id_unit','U0007');
		$this->db->where('a.id_departemen','D0016');
		$this->db->where("(a.nama_karyawan LIKE '%".$term."%' OR a.id_karyawan LIKE '%".$term."%')", NULL, FALSE);
		$this->db->group_by('a.id_karyawan');
		$this->db->order_by('c.nama_departemen');
		//$this->db->order_by('d.nama_section');

		$i = 0;
	
		foreach ($this->column_search as $item) // loop column 
		{
			if($_POST['search']['value']) // if datatable send POST for search
			{
				
				if($i===0) // first loop
				{
					$this->db->group_start(); // open bracket. query Where with OR clause better with bracket. because maybe can combine with other WHERE with AND.
					$this->db->like($item, $_POST['search']['value']);
				}
				else
				{
					$this->db->or_like($item, $_POST['search']['value']);
				}

				if(count($this->column_search) - 1 == $i) //last loop
					$this->db->group_end(); //close bracket
			}
			$i++;
		}
		
		if(isset($_POST['order'])) // here order processing
		{
			$this->db->order_by($this->column_order[$_POST['order']['0']['column']], $_POST['order']['0']['dir']);
		} 
		else if(isset($this->order))
		{
			$order = $this->order;
			$this->db->order_by(key($order), $order[key($order)]);
		}
	}

	function get_datatables()
	{
		$term = $_REQUEST['search']['value']; 
		$this->_get_datatables_query($term);
		if($_POST['length'] != -1)
		$this->db->limit($_POST['length'], $_POST['start']);
		$query = $this->db->get();
		return $query->result();
	}

	function count_filtered()
	{
		$this->_get_datatables_query();
		$query = $this->db->get();
		return $query->num_rows();
	}

	public function count_all()
	{
		$this->db->from($this->table);
		return $this->db->count_all_results();
	}

	public function get_by_id($id)
	{
		$this->db->from($this->table);
		$this->db->where('id_level',$id);
		$query = $this->db->get();

		return $query->row();
	}

	public function save($data)
	{
		$this->db->insert($this->table, $data);
		return $this->db->insert_id();
	}

	public function update($where, $data)
	{
		$this->db->update($this->table, $data, $where);
		return $this->db->affected_rows();
	}

	public function delete_by_id($id)
	{
		$this->db->where('id_level', $id);
		$this->db->delete($this->table);
	} 
}	

?>