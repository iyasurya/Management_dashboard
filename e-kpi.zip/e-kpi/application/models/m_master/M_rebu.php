<?php 

class M_rebu extends CI_Model{

	var $table = 'm_karyawan';
	var $column_order = array('id_karyawan','nama_karyawan',null); //set column field database for datatable orderable
	var $column_search = array('id_karyawan','nama_karyawan'); //set column field database for datatable searchable just firstname , lastname , address are searchable
	var $order = array('id_karyawan' => 'asc'); // default order 	

	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}

	private function _get_datatables_query($term='')
	{

		$this->db->select('a.*,b.nama_unit,c.nama_departemen,d.nama_section,e.nama_jabatan,f.id_kpi,f.nama_kpi,h.skor_akhir');
		$this->db->from('m_karyawan as a');
		$this->db->join('m_unit as b', 'b.id_unit = a.id_unit','left');
		$this->db->join('m_departemen as c', 'c.id_departemen = a.id_departemen','left');
		$this->db->join('m_section as d', 'd.id_section = a.id_section','left');
		$this->db->join('m_jabatan as e', 'e.id_jabatan = a.id_jabatan','left');
		$this->db->join('m_kpi as f', 'f.id_unit = b.id_unit','left');
		$this->db->join('t_target as g', 'g.id_kpi = f.id_kpi','left');
		$this->db->join('t_realisasi as h', 'h.id_karyawan = a.id_karyawan','left');
		$this->db->where('a.enableflag','0');
		$this->db->where('b.id_unit','U0007');
		$this->db->where("(a.nama_karyawan LIKE '%".$term."%' OR a.id_karyawan LIKE '%".$term."%')", NULL, FALSE);
		$this->db->group_by('a.id_karyawan');
		$this->db->order_by('c.nama_departemen');
		
		
		if(isset($_POST['order'])) // here order processing
		{
			$this->db->order_by($this->column_order[$_POST['order']['0']['column']], $_POST['order']['0']['dir']);
		} 
		else if(isset($this->order))
		{
			$order = $this->order;
			$this->db->order_by(key($order), $order[key($order)]);
		}
	}

	function get_datatables()
	{
		$term = $_REQUEST['search']['value']; 
		$this->_get_datatables_query($term);
		if($_POST['length'] != -1)
		$this->db->limit($_POST['length'], $_POST['start']);
		$query = $this->db->get();
		return $query->result();
	}

	function count_filtered()
	{
		$this->_get_datatables_query();
		$query = $this->db->get();
		return $query->num_rows();
	}

	public function count_all()
	{
		$this->db->from($this->table);
		return $this->db->count_all_results();
	}

	public function get_by_id($id)
	{
		$this->db->from($this->table);
		$this->db->where('id_karyawan',$id);
		$query = $this->db->get();

		return $query->row();
	}

	public function save($data)
	{
		$this->db->insert($this->table, $data);
		return $this->db->insert_id();
	}

	function update($id,$id_karyawan,$id_departemen,$id_jabatan,$nama_karyawan,$perspective,$subkaryawan,
					$parameter,$measurement,$sourcesdata,$pic,$enableflag){
		
		$id=$id;
		$infoHeader=array(
			'id_karyawan'=>$id_karyawan,
			'id_departemen'=>$id_departemen,
			'id_jabatan'=>$id_jabatan,
			'nama_karyawan'=>$nama_karyawan,
			'perspective'=>$perspective,
			'subkaryawan'=>$subkaryawan,
			'parameter'=>$parameter,
			'measurement'=>$measurement,
			'sourcesdata'=>$sourcesdata,
			'pic'=>$pic,
			'enableflag'=>$enableflag,
			'userid' => $this->session->userdata("name")
			);

		$this->db->where('id',$id);
		$this->db->update('m_karyawan',$infoHeader);
	}

	public function delete_by_id($id)
	{
		$this->db->where('id_karyawan', $id);
		$this->db->delete($this->table);
	} 

	public function viewHomeadvisor(){
		$this->db->where('id_departemen', 'D0002');
		return $this->db->get('m_karyawan');
	} 
	public function viewMarcomm(){
		$this->db->where('id_departemen', 'D0002');
		return $this->db->get('m_karyawan');
	} 

	public function viewCare(){
		$this->db->where('id_departemen', 'D0002');
		return $this->db->get('m_karyawan');
	} 

	public function viewEstate(){
		$this->db->where('id_departemen', 'D0025');
		return $this->db->get('m_karyawan');
	}
}	

?>