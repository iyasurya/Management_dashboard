<?php 

class M_berandaofficer extends CI_Model{

	var $table = 't_detailrealisasi';
	var $column_order = array('id_realisasi',null); //set column field database for datatable orderable
	var $column_search = array('id_realisasi'); //set column field database for datatable searchable just firstname , lastname , address are searchable
	var $order = array('id_realisasi' => 'asc'); // default order 	

	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}

	public function viewRealisasi($bFrom,$bTo,$tFrom,$tTo,$periode){
	//	var_dump($bFrom,$bTo,$tFrom,$tTo,$periode);

		$this->db->select('a.*,(a.obj+a.waktu)/2 as avg,(a.realisasi*c.bobot)/100 as nilai,d.nama_bulan');
		$this->db->from('t_detailrealisasi as a');
		$this->db->join('t_realisasi as b', 'b.id_realisasi = a.id_realisasi','left');
		$this->db->join('m_kpikaryawan as c', 'c.id_karyawan = b.id_karyawan and c.id_kpi = a.id_kpi','left');
		$this->db->join('m_bulan as d', 'd.id_bulan = b.id_bulan','left');
		$this->db->where('a.enableflag','0');
		$this->db->where('b.id_karyawan', $_SESSION['id_karyawan']);
		$this->db->where('b.id_bulan >=', $bFrom);
		$this->db->where('b.id_bulan <=',$bTo);
		$this->db->where('b.id_tahun >=', $tFrom);
		$this->db->where('b.id_tahun <=',$tTo);
		//$this->db->group_by('a.id_kpi');
		$this->db->order_by('a.id_realisasi');
		$this->db->order_by('a.id');
		$query = $this->db->get();
		return $query->result();
	}
	public function viewKPI($bFrom,$bTo,$tFrom,$tTo,$periode){
		//var_dump($bFrom,$bTo,$tFrom,$tTo,$periode);
		$this->db->select('a.*,(a.obj+a.waktu)/2 as avg,(a.realisasi*c.bobot)/100 as nilai,d.nama_bulan');
		$this->db->from('t_detailrealisasi as a');
		$this->db->join('t_realisasi as b', 'b.id_realisasi = a.id_realisasi','left');
		$this->db->join('m_kpikaryawan as c', 'c.id_karyawan = b.id_karyawan and c.id_kpi = a.id_kpi','left');
		$this->db->join('m_bulan as d', 'd.id_bulan = b.id_bulan','left');
		$this->db->where('a.enableflag','0');
		$this->db->where('b.id_karyawan', $_SESSION['id_karyawan']);
		$this->db->where('b.id_bulan >=', $bFrom);
		$this->db->where('b.id_bulan <=',$bTo);
		$this->db->where('b.id_tahun >=', $tFrom);
		$this->db->where('b.id_tahun <=',$tTo);
		//$this->db->group_by('a.id_kpi');
		$this->db->order_by('a.id_realisasi');
		$this->db->order_by('a.id');
		
		$query = $this->db->get();
		return $query->result();
		}
}	

?>